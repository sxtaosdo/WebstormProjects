/**
 * Created by cheilchina on 2016/12/8.
 */
var canvas, stage, exportRoot;
var _isloaded = false;
var currentPage = 0;

//initMain(0);
function load(_callback) {

    canvas = document.getElementById("canvas");
    images = images || {};

    var loader = new createjs.LoadQueue(false);
    loader.addEventListener("fileload", handleFileLoad);
    loader.addEventListener("complete", handleComplete);
    loader.loadManifest(lib.properties.manifest);

    function handleFileLoad(evt) {
        console.log(11);
        if (evt.item.type == "image") {
            images[evt.item.id] = evt.result;
        }
    }

    function handleComplete(evt) {
        var queue = evt.target;
        var ssMetadata = lib.ssMetadata;
        for (i = 0; i < ssMetadata.length; i++) {
            ss[ssMetadata[i].name] = new createjs.SpriteSheet({
                "images": [queue.getResult(ssMetadata[i].name)],
                "frames": ssMetadata[i].frames
            })
        }
        exportRoot = new lib.ssd();
        //
        //console.log('1111111111',exportRoot.main);
        stage = new createjs.Stage(canvas);
        stage.addChild(exportRoot);

        //exportRoot.main.stop();
        createjs.Ticker.setFPS(lib.properties.fps);
        createjs.Ticker.addEventListener("tick", stage);

        _callback();
       // exportRoot.stage.addEventListener("added", onAdded);
    }
}
function initMain(_pam1, _pam2) {
    load(function () {
        initMain2(_pam1, _pam2);
    })
}

function initMain2(page, step) {
    currentPage = page;
    console.log(currentPage)
    if (step) {
        exportRoot.main.gotoAndStop(page);
        var mc = exportRoot.main["page" + page];
        mc.gotoAndStop(mc.totalFrames - 1);
    } else {
        this["step" + page]();
    }
}

function onResize() {
    $('.canvasBox').css({"height": $(window).height()});
    if (exportRoot.main["page" + currentPage].mz) {
        exportRoot.main["page" + currentPage].mz.y = $(window).height() - 50;
    }
    exportRoot.main.fmMc.y = $(window).height() - 320;
}

function onAdded() {
    // this["step" + currentPage]();


    $(window).on("resize", onResize).resize();
}

function step0() {
    exportRoot.main.page0.btn1.addEventListener("click", showRule);
    exportRoot.main.page0.btn2.addEventListener("click", step1);
    exportRoot.main.fmMc.visible = false;
}

function showRule() {
    console.log("showRule");
    exportRoot.main.gotoAndStop(6);
    exportRoot.main.page0.btn1.removeEventListener("click", showRule);
    exportRoot.main.page0.btn2.removeEventListener("click", step1);
    exportRoot.main.page6.btn.addEventListener("click", function () {
        if (exportRoot.main.page6.currentFrame == 0) {
            step1();
        } else {
            initMain2(currentPage);
        }
    })
}

function step1() {
    exportRoot.main.fmMc.visible = true;
    console.log("step1");
    exportRoot.main.gotoAndStop(1);
    exportRoot.main.page1.btn.addEventListener("click", step1_play);
}

function step1_play() {
    exportRoot.main.page1.gotoAndPlay(1);
    // createjs.Tween.get(this).wait(1000).call(function (){
    //     step2();
    // })
    exportRoot.main.page1.btn1.addEventListener("click", function () {
        exportRoot.main.page1.completeMc.gotoAndStop(1);
    })
    NetData.getHelp(function (pam) {
        console.log('getHelp callback', pam);
        if (pam == 'success') {
            console.log(点击了start)
        } else {
            alert('请检查网络！');
        }
    })
}

function step2() {
    exportRoot.main.gotoAndStop(2);
    createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(2);
        exportRoot.main.page2.gotoAndStop(0);
    })
    exportRoot.main.page2.gotoAndStop(0);
    exportRoot.main.page2.btn.addEventListener("click", step2_1)
}

function step2_1() {
    console.log("in step2_1")
    exportRoot.main.page2.gotoAndStop(1);
    $(window).swipe({
        swipeUp: function (event, direction, distance, duration, fingerCount) {
            NetData.helpFriend(function (pam) {
                console.log('getHelp callback', pam);
                if (pam == 'success') {
                    console.log(帮助充公)
                } else {
                    alert('请检查网络！');
                }
            })
            step2_2();
        },
    });
}

function step2_2(evt) {
    exportRoot.main.page2.gotoAndPlay(2);
    exportRoot.main.page2.btn1.addEventListener("click", function () {
        // console.log("step2_2");
        exportRoot.main.page2.completeMc.gotoAndStop(1);
    });
}

function step3() {
    exportRoot.main.gotoAndStop(3);
    createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(3);
        exportRoot.main.page3.gotoAndStop(0);
    })
    exportRoot.main.page3.gotoAndStop(0);
    exportRoot.main.page3.btn.addEventListener("click", step3_1)
}

function step3_1(evt) {
    exportRoot.main.page3.gotoAndStop(1);
    $(window).swipe({
        swipeUp: function (event, direction, distance, duration, fingerCount) {
            step3_2();
        },
    });
}

function step3_2() {
    exportRoot.main.page3.gotoAndPlay(2)
    exportRoot.main.page3.btn1.addEventListener("click", function () {
        exportRoot.main.page3.completeMc.gotoAndStop(1);
    });
}

function step4() {
    exportRoot.main.gotoAndStop(4);
    createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(4);
        exportRoot.main.page4.gotoAndStop(0);
    })
    exportRoot.main.page4.gotoAndStop(0);
    exportRoot.main.page4.btn.addEventListener("click", step4_1)
}

function step4_1(evt) {
    exportRoot.main.page4.gotoAndStop(1);
    $(window).swipe({
        swipeUp: function (event, direction, distance, duration, fingerCount) {
            step4_2();
        },
    });
    // $(window).swipe({
    //     swipeStatus: function (event, phase, direction, distance, duration, fingerCount) {
    //         $(this).text("你用" + fingerCount + "个手指以" + duration + "秒的速度向" + direction + "滑动了" + distance + "像素 " + "你在" + phase + "中");
    //     },
    // })
}

function step4_2() {
    exportRoot.main.page4.gotoAndPlay(2)
    exportRoot.main.page4.btn1.addEventListener("click", function () {
        exportRoot.main.page4.completeMc.gotoAndStop(1);
    });
}

function step5() {
    exportRoot.main.page5.gotoAndStop(1);
    createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(5);
        exportRoot.main.page5.gotoAndStop(0);
    })
    exportRoot.main.page5.btn1.addEventListener("click", function () {
        showAward(2);
        NetData.startlottery(function (_prizeid) {
            if (_prizeid == "4") {
                showAward(4);
            } else {
                showAward(_prizeid);
            }
        });
    })
}

function step6() {
   createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(6);
   })
}


function step7() {
    exportRoot.main.page7.shareMc.visible = false;
    createjs.Tween.get(this).wait(100).call(function () {
        exportRoot.main.gotoAndStop(7);
        exportRoot.main.page7.shareMc.visible = false;
        exportRoot.main.page7.btn.addEventListener("click", function () {
            exportRoot.main.page7.shareMc.visible = true;
            if (userInfo.supporterNum == 1) {
                exportRoot.main.page7.gotoAndStop(0)
            } else {
                exportRoot.main.page7.gotoAndStop(1);
            }
        })
    })
}

function showAward(key) {//2 or 3
    exportRoot.main.page5.gotoAndStop(key - 1);
    exportRoot.main.page5["btn" + key].addEventListener("click", function (evt) {
        var index = exportRoot.main.page5.currentFrame + 1;
        switch (index) {
            case 2:

                break;
            case 3:
                break;
        }
        console.log(index);
    })
}
