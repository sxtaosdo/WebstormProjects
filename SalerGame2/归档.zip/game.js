(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib._2房子1 = function() {
	this.initialize(img._2房子1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,70,120);


(lib._2房子2 = function() {
	this.initialize(img._2房子2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,142,147);


(lib._2梯子 = function() {
	this.initialize(img._2梯子);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,52,69);


(lib._2爆炸 = function() {
	this.initialize(img._2爆炸);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,54,46);


(lib._2爆炸后 = function() {
	this.initialize(img._2爆炸后);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,49);


(lib._2碎片1 = function() {
	this.initialize(img._2碎片1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,13,20);


(lib._2碎片2 = function() {
	this.initialize(img._2碎片2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,16,11);


(lib._2碎片3 = function() {
	this.initialize(img._2碎片3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,17);


(lib._2碎片4 = function() {
	this.initialize(img._2碎片4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,22,19);


(lib._2碎片5 = function() {
	this.initialize(img._2碎片5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,20,11);


(lib._2碎片6 = function() {
	this.initialize(img._2碎片6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,12,15);


(lib._2背景 = function() {
	this.initialize(img._2背景);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1029);


(lib._2道路1 = function() {
	this.initialize(img._2道路1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,312,169);


(lib._2道路2 = function() {
	this.initialize(img._2道路2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,199,467);


(lib._2道路3 = function() {
	this.initialize(img._2道路3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,257,172);


(lib._2问号 = function() {
	this.initialize(img._2问号);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,21,27);


(lib._2障碍2 = function() {
	this.initialize(img._2障碍2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,36,51);


(lib._2飞碟 = function() {
	this.initialize(img._2飞碟);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,51);


(lib.bg1 = function() {
	this.initialize(img.bg1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1098);


(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1029);


(lib.bg4 = function() {
	this.initialize(img.bg4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1029);


(lib.h头像框 = function() {
	this.initialize(img.h头像框);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,121,160);


(lib.h头像框星 = function() {
	this.initialize(img.h头像框星);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,25,27);


(lib.L地 = function() {
	this.initialize(img.L地);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,276,11);


(lib.m炸弹 = function() {
	this.initialize(img.m炸弹);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,37);


(lib.m跑1 = function() {
	this.initialize(img.m跑1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m跑2 = function() {
	this.initialize(img.m跑2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m跑3 = function() {
	this.initialize(img.m跑3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m跑4 = function() {
	this.initialize(img.m跑4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m跑5 = function() {
	this.initialize(img.m跑5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m转1 = function() {
	this.initialize(img.m转1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.m转2 = function() {
	this.initialize(img.m转2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,144);


(lib.p1m呆毛 = function() {
	this.initialize(img.p1m呆毛);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,103);


(lib.p1m嘴 = function() {
	this.initialize(img.p1m嘴);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,127,56);


(lib.p1m身 = function() {
	this.initialize(img.p1m身);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,242,271);


(lib.p1txt = function() {
	this.initialize(img.p1txt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,348,402);


(lib.p1房子 = function() {
	this.initialize(img.p1房子);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,274);


(lib.p1飞船 = function() {
	this.initialize(img.p1飞船);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,47);


(lib.p2房1 = function() {
	this.initialize(img.p2房1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,133,143);


(lib.p2房2 = function() {
	this.initialize(img.p2房2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,168,183);


(lib.p2房3 = function() {
	this.initialize(img.p2房3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,88,215);


(lib.p2房3旗子 = function() {
	this.initialize(img.p2房3旗子);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,164,171);


(lib.p2洞 = function() {
	this.initialize(img.p2洞);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,38);


(lib.p2路1 = function() {
	this.initialize(img.p2路1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,236);


(lib.p2路2 = function() {
	this.initialize(img.p2路2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,380,232);


(lib.p2路3 = function() {
	this.initialize(img.p2路3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,428,234);


(lib.p2问号 = function() {
	this.initialize(img.p2问号);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,110);


(lib.p4_房1 = function() {
	this.initialize(img.p4_房1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,89,118);


(lib.p4_房2 = function() {
	this.initialize(img.p4_房2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,115,201);


(lib.p4_房3 = function() {
	this.initialize(img.p4_房3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,107);


(lib.p4_房4 = function() {
	this.initialize(img.p4_房4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,69,126);


(lib.p4_房4问 = function() {
	this.initialize(img.p4_房4问);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,114,112);


(lib.p4_潜水艇 = function() {
	this.initialize(img.p4_潜水艇);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,92,92);


(lib.p4路1 = function() {
	this.initialize(img.p4路1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,379,257);


(lib.p4路2 = function() {
	this.initialize(img.p4路2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,237,266);


(lib.p4路2洞 = function() {
	this.initialize(img.p4路2洞);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,55,47);


(lib.p4路3 = function() {
	this.initialize(img.p4路3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,321,157);


(lib.p4路3问 = function() {
	this.initialize(img.p4路3问);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,21,27);


(lib.p4路4 = function() {
	this.initialize(img.p4路4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,563,638);


(lib.p4路4完成 = function() {
	this.initialize(img.p4路4完成);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,135,91);


(lib.qrcode = function() {
	this.initialize(img.qrcode);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,424,423);


(lib.人手1 = function() {
	this.initialize(img.人手1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,35,24);


(lib.人手2 = function() {
	this.initialize(img.人手2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,40,20);


(lib.人腿1 = function() {
	this.initialize(img.人腿1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,39,35);


(lib.人腿2 = function() {
	this.initialize(img.人腿2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,40,32);


(lib.人身 = function() {
	this.initialize(img.人身);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,51,91);


(lib.人转手1 = function() {
	this.initialize(img.人转手1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,33,39);


(lib.人转手2 = function() {
	this.initialize(img.人转手2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,22);


(lib.人转腿1 = function() {
	this.initialize(img.人转腿1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,36,24);


(lib.人转腿2 = function() {
	this.initialize(img.人转腿2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,37,29);


(lib.人转身 = function() {
	this.initialize(img.人转身);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,92);


(lib.叉子 = function() {
	this.initialize(img.叉子);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,282,282);


(lib.固定金币 = function() {
	this.initialize(img.固定金币);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,45);


(lib.图层190 = function() {
	this.initialize(img.图层190);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1029);


(lib.录入头像游戏更精彩 = function() {
	this.initialize(img.录入头像游戏更精彩);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,192,18);


(lib.拍照 = function() {
	this.initialize(img.拍照);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,128);


(lib.教程字1 = function() {
	this.initialize(img.教程字1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,118,18);


(lib.教程字2 = function() {
	this.initialize(img.教程字2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,117,19);


(lib.椭圆2拷贝3 = function() {
	this.initialize(img.椭圆2拷贝3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,608,608);


(lib.答题背景 = function() {
	this.initialize(img.答题背景);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,507,324);


(lib.答题道道 = function() {
	this.initialize(img.答题道道);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,140,12);


(lib.答题金币1 = function() {
	this.initialize(img.答题金币1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,57);


(lib.答题金币2 = function() {
	this.initialize(img.答题金币2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,68,64);


(lib.结算二维码 = function() {
	this.initialize(img.结算二维码);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,241,309);


(lib.结算人头1 = function() {
	this.initialize(img.结算人头1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,38);


(lib.结算人头2 = function() {
	this.initialize(img.结算人头2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,36);


(lib.结算人手 = function() {
	this.initialize(img.结算人手);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,11,34);


(lib.结算人身 = function() {
	this.initialize(img.结算人身);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,53,75);


(lib.结算再玩一次 = function() {
	this.initialize(img.结算再玩一次);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,223,73);


(lib.结算奖金总额 = function() {
	this.initialize(img.结算奖金总额);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,414,68);


(lib.结算字1 = function() {
	this.initialize(img.结算字1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,163,53);


(lib.结算怪物1 = function() {
	this.initialize(img.结算怪物1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,119);


(lib.结算怪物2 = function() {
	this.initialize(img.结算怪物2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,119);


(lib.结算怪物3 = function() {
	this.initialize(img.结算怪物3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,119);


(lib.结算怪物4 = function() {
	this.initialize(img.结算怪物4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,119);


(lib.结算房子 = function() {
	this.initialize(img.结算房子);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,363,195);


(lib.结算背景 = function() {
	this.initialize(img.结算背景);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1029);


(lib.继续 = function() {
	this.initialize(img.继续);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,128);


(lib.跳过 = function() {
	this.initialize(img.跳过);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,127);


(lib.错怪兽 = function() {
	this.initialize(img.错怪兽);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,100,180);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.错怪兽_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.错怪兽();
	this.instance.parent = this;
	this.instance.setTransform(-50,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ao+EzIAMxxIGVAAIChJFIFdClIB7gOIBcBvIAKCjIg6AvIhLH3Qn1AloJBEg");
	this.shape.setTransform(3.4,-81.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.错怪兽_1, new cjs.Rectangle(-54.4,-180,115.6,181.3), null);


(lib.错叉子 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.叉子();
	this.instance.parent = this;
	this.instance.setTransform(-141,-141);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.错叉子, new cjs.Rectangle(-141,-141,282,282), null);


(lib.答题金币2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.答题金币1();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-28.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.答题金币2_1, new cjs.Rectangle(-22.5,-28.5,45,57), null);


(lib.答题金币1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.答题金币2();
	this.instance.parent = this;
	this.instance.setTransform(-34,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.答题金币1_1, new cjs.Rectangle(-34,-32,68,64), null);


(lib.答题固定金币 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.moneyText = new cjs.Text("", "30px 'Microsoft YaHei'", "#FFF100");
	this.moneyText.name = "moneyText";
	this.moneyText.textAlign = "center";
	this.moneyText.lineHeight = 42;
	this.moneyText.lineWidth = 79;
	this.moneyText.parent = this;
	this.moneyText.setTransform(0.5,25.5);
	this.moneyText.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,0,4);

	this.instance = new lib.固定金币();
	this.instance.parent = this;
	this.instance.setTransform(-21.5,-22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.moneyText}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.答题固定金币, new cjs.Rectangle(-45.9,-27.5,96,103), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.答题道道();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,140,12), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mouseChildren=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAaGzIm2g8QgEgBAVhZQAWhagFgBQgEgBAnhRQAnhRgFgBQgEAAA8hRQA9hRgFgBQgEAABWhEQBWhFgEAAQgEgBA7grQA8gqgEgBQgEAABegqQBfgrgEAAQgEgBBNgVQBFgTAEgDIAJPMg");
	this.shape.setTransform(41.4,48.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,82.8,97.3), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mouseChildren=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("At/CKIAAkTIb/AAIAAETg");
	this.shape.setTransform(89.6,13.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,179.3,27.6), null);


(lib.碎片3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片3();
	this.instance.parent = this;
	this.instance.setTransform(-5,-8.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.碎片3, new cjs.Rectangle(-5,-8.5,10,17), null);


(lib.m炸弹_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.m炸弹();
	this.instance.parent = this;
	this.instance.setTransform(-9.5,-18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFF00","rgba(255,204,0,0)"],[0,1],0,0,0,0,0,8.4).s().p("Ag6A7QgZgYABgjQgBghAZgZQAZgYAhAAQAiAAAZAYQAYAZAAAhQAAAjgYAYQgZAZgigBQghABgZgZg");
	this.shape.setTransform(0.1,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-18.8,19,37.4);


(lib._2碎片6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片6();
	this.instance.parent = this;
	this.instance.setTransform(-6,-7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2碎片6_1, new cjs.Rectangle(-6,-7.5,12,15), null);


(lib._2碎片5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片5();
	this.instance.parent = this;
	this.instance.setTransform(-10,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2碎片5_1, new cjs.Rectangle(-10,-5.5,20,11), null);


(lib._2碎片4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片4();
	this.instance.parent = this;
	this.instance.setTransform(-11,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2碎片4_1, new cjs.Rectangle(-11,-9.5,22,19), null);


(lib._2碎片2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片2();
	this.instance.parent = this;
	this.instance.setTransform(-8,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2碎片2_1, new cjs.Rectangle(-8,-5.5,16,11), null);


(lib._2碎片1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2碎片1();
	this.instance.parent = this;
	this.instance.setTransform(-6.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2碎片1_1, new cjs.Rectangle(-6.5,-10,13,20), null);


(lib._2爆炸_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2爆炸();
	this.instance.parent = this;
	this.instance.setTransform(-27,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2爆炸_1, new cjs.Rectangle(-27,-23,54,46), null);


(lib._2故障2动画 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2障碍2();
	this.instance.parent = this;
	this.instance.setTransform(-18,-25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2故障2动画, new cjs.Rectangle(-18,-25.5,36,51), null);


(lib.结算背景_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.结算背景();
	this.instance.parent = this;
	this.instance.setTransform(-320,-514.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算背景_1, new cjs.Rectangle(-320,-514.5,640,1029), null);


(lib.结算房子_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.结算房子();
	this.instance.parent = this;
	this.instance.setTransform(-181.5,-97.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算房子_1, new cjs.Rectangle(-181.5,-97.5,363,195), null);


(lib.结算怪兽 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer 2
	this.instance = new lib.结算怪物4();
	this.instance.parent = this;
	this.instance.setTransform(-41.5,-59.5);

	this.instance_1 = new lib.结算怪物3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-41.5,-59.5);

	this.instance_2 = new lib.结算怪物2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-41.5,-59.5);

	this.instance_3 = new lib.结算怪物1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-41.5,-59.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},6).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},5).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance}]},2).to({state:[{t:this.instance_1}]},6).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.5,-59.5,83,119);


(lib.结算字1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.结算字1();
	this.instance.parent = this;
	this.instance.setTransform(-81.5,-26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算字1_1, new cjs.Rectangle(-81.5,-26.5,163,53), null);


(lib.结算奖金总额_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.结算奖金总额();
	this.instance.parent = this;
	this.instance.setTransform(-207,-34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算奖金总额_1, new cjs.Rectangle(-207,-34,414,68), null);


(lib.结算在玩一次 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.结算再玩一次();
	this.instance.parent = this;
	this.instance.setTransform(-111.5,-36.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算在玩一次, new cjs.Rectangle(-111.5,-36.5,223,73), null);


(lib.结算人手_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.结算人手();
	this.instance.parent = this;
	this.instance.setTransform(-5.5,-34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算人手_1, new cjs.Rectangle(-5.5,-34,11,34), null);


(lib.结算二维码_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.qrcode();
	this.instance.parent = this;
	this.instance.setTransform(-107,-70,0.495,0.496);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("Aw6w/MAh1AAAMAAAAh/Mgh1AAAg");
	this.shape.setTransform(0.6,35.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Aw5Q/MAAAgh+MAhzAAAMAAAAh+g");
	this.shape_1.setTransform(0.6,35.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// 图层 1
	this.instance_1 = new lib.结算二维码();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-120.5,-154.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.结算二维码_1, new cjs.Rectangle(-120.5,-154.5,241,309), null);


(lib.教程跳线 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(6,1).p("AgfAnIA/hN");
	this.shape.setTransform(69.4,-190.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApqaqQgMgCgIgJQgHgKABgMQAMhfAOhfQABgMALgHQAKgIAMACQAMACAHAKQAIAKgCAMQgOBegLBeQgCAMgKAIQgIAGgKAAIgEAAgAo0UyQgMgCgHgLQgHgKACgMQAQheAShdQACgMALgHQAKgHAMACQAMADAHAKQAHAKgCAMQgSBdgQBdQgCAMgKAIQgIAFgJAAIgGAAgAnsO9QgNgDgGgKQgHgKADgNQAUhdAWhcQADgMALgGQAKgHAMADQAMADAHALQAGAKgCAMQgXBcgUBcQgDAMgKAHQgHAFgJAAIgGgBgAmUJMQgMgDgGgLQgHgLADgMQAYhcAbhbQADgMALgGQALgGAMADQAMAEAGALQAGALgDAMQgbBagYBbQgDAMgLAGQgHAFgIAAIgHgBgAksDfQgLgEgGgLQgGgLAEgLIAFgQIAAAAQAahVAchTQAEgLAMgGQALgFALAEQAMAEAGALQAFAKgEAMQgcBSgaBVIgFAQQgEAMgLAFQgHAEgHAAIgJgCgAiyiKQgMgEgFgMQgGgLAFgMQAhhaAihXQAFgLAMgFQALgFALAEQAMAFAFALQAFAMgFALQgiBXghBZQgEAMgMAFQgGADgGAAQgFAAgFgCgAgonqQgMgFgEgMQgFgLAFgMQAlhXAnhWQAFgMALgEQAMgEALAFQALAFAFAMQAEALgFAMQgnBVgkBXQgFALgLAFQgGACgGAAQgGAAgFgCgABztDQgLgFgEgMQgEgLAGgMQAqhWAthTQAGgLAMgEQALgDALAGQALAGAEALQAEAMgGALQgtBTgqBVQgGALgLAEQgFACgFAAQgGAAgHgEgAEkySQgKgHgEgMQgDgLAGgLQAwhUAyhQQAGgLAMgDQAMgCALAGQALAHADAMQACAMgGAKQgxBQgwBTQgGAKgMAEIgIABQgIAAgHgEgAHr3WQgLgHgCgMQgDgNAHgKQA2hQA3hNQAHgKAMgCQANgCAKAHQAKAIACAMQACAMgHAKQg3BMg1BPQgHALgMACIgGABQgJAAgHgFg");
	this.shape_1.setTransform(-8.1,-2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(6,1).p("AgDAyQACgjAFhA");
	this.shape_2.setTransform(-72.1,189.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程跳线, new cjs.Rectangle(-75.5,-197.5,151,395), null);


(lib.教程跳箭头 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AChDsIhljTQgDgHgIgBIkJgoQgMgCgBgMQgCgLALgFIGXi9QAQgHAPAKQAPAKgCASIgoG6QgBAMgMACIgEABQgJAAgEgKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程跳箭头, new cjs.Rectangle(-23,-24.6,46.2,49.2), null);


(lib.教程跳图标 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgTnA9/ICMimQIdCfI+AAQMmAALfk3QLHktIkojQIlolEsrHQE3reAAsnQAAslk3rfQksrHolokQokokrHktQrgk3slAAQskAArgE3QrGEtolIkQokIkksLHQk4LgAAMkQAAGhBVGTIihC+Qh8nuAAoEQAAtLFHsHQE8rqI/pAQJApALrk8QMHlHNLAAQNNAAMGFHQLrE8JAJAQJAJAE8LqQFGMGAANMQAANOlGMGQk8LqpAJAQpAJArrE8QsFFGtOAAQqIAApfjBg");
	this.shape.setTransform(1.7,-2.1,0.083,0.083);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANCzQilimiVi6ICEicQCbDGCpCpQBIBHBLBEIiBCZQhchThEhEg");
	this.shape_1.setTransform(-22.8,20.7,0.083,0.083);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjHicIglhcICTiuQAlBkAlBYQBsEBCQDwIiHChQiskUiBkwg");
	this.shape_2.setTransform(-28.4,12.6,0.083,0.083);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AmmiAICBiZQFMDtGACnIiGCfQl2iplRjxg");
	this.shape_3.setTransform(-14.9,26.9,0.083,0.083);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AQ5MxQkxk0iqikQk0kqhzgoQjGhFkwhAQmRhVkHAFQgaAAgegEIhFgHQmTgLhpkvQghhfAChxIAHheIBKgYQBigbB3gOQFrgqGnBbIFHBMQIyCGCHAtQCuA5FtFYQDJC9FaFeQBtBpgICIQgIB6hfBfQheBgh8ALIgbABQh5AAhihfg");
	this.shape_4.setTransform(7.5,5.9,0.083,0.083);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("EAOMAkPQiEgkhCiIQi0mMhnjUQi6mChehNQifiFkJinQlbjaj4hXQgbgJgZgNIg+gfQl3iWAHlAQAChkAohqIAohVQDvnbByjcQCplECTj/QlBhmkVBjQkeBnjgE4QhXB6iNAVQh/ASh1hEQh0hEgjhvQgmh9BYh7QG6prJpiIQJuiKKMGEQAkAWDJBwQGgD3Fng9QF1hAEWmFQBXh6CNgUQB/gSB1BDQB1BEAiBwQAmB8hZB8QloH5nnC6QnnC5oVijQk/Ijk/JqQDHBmEIC7QC0B/DCCbQCQByDfHAQB7D3DMHBQBCCJg3B8QgxBwh6A5QhOAkhNAAQgrAAgsgMg");
	this.shape_5.setTransform(1.2,1,0.083,0.083);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AnQHQQjAjAAAkQQAAkPDAjAQDBjBEPAAQEQAADADBQDBDAAAEPQAAEQjBDAQi/DBkRAAQkPAAjBjBg");
	this.shape_6.setTransform(6.4,-20.9,0.083,0.083);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AspPAQgmghgEgxQgEgyAggmIW37GQAhgmAxgEQAygFAmAgQAmAhAEAxQAEAyggAmI24bGQggAngxAEIgMAAQgqAAgigcg");
	this.shape_7.setTransform(-9.3,28.4,0.083,0.083);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("At8QiQgmgggEgyQgEgxAggnIZd+KQAggmAygFQAxgEAmAgQAnAhAEAxQAEAyggAmI5deLQghAmgxAEIgLAAQgrAAgigcg");
	this.shape_8.setTransform(-13.8,17.5,0.083,0.083);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("At8QiQgmghgEgxQgEgyAggmIZd+KQAhgmAxgFQAygEAmAgQAlAgAFAyQAEAyggAmI5eeKQgfAngyAEIgMAAQgqAAgigcg");
	this.shape_9.setTransform(-24.7,15.6,0.083,0.083);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("At8QiQgmgggEgyQgEgyAggmIZd+KQAggmAygFQAxgEAnAgQAmAhAEAxQAEAyggAmI5deLQghAmgxAEIgLAAQgrAAgigcg");
	this.shape_10.setTransform(-28.3,5.1,0.083,0.083);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程跳图标, new cjs.Rectangle(-36,-36.5,72.1,73.1), null);


(lib.教程按下圈 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(6,1).p("Ah5G1QhsgehVhUQiCiDAAi4QAAi3CCiDQCDiCC3AAQC5AACCCCQCCCDAAC3QAABVgcBK");
	this.shape.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程按下圈, new cjs.Rectangle(-47.5,-47.5,95,93.5), null);


(lib.教程手 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EAE9AjXQh9h+iygrQjXgqjbh0QiihWjgiiQh3hXihjAQi1jWhRhGQg2hIhjhYQgegbiLhzQgMgKg/hBQgyg1gggQQgegPgrhNQgthWgRgaQhbiIhDhKQgqguhOg9IiHhkQgogeAEhIQAEhBAegtQBPhvCwgEQCggEB9BOQAxAeBEBBQBeBaAPAMQBBA3CSCOQCHB7BkAnQDDBUDChaQAPgGARgUQARgUAJgXQBJifgwiiQgGgbgVgsMgRPgjAQhIiWBUhtQAqg3A4gZQBlgwA/ANQBcASBSCHIOVYYIAFACIAIALICGhEQDzg+DfBsQArAVAYAXICCB7ICNgiIAGACQCVgSCdAjQCYAjCCBOQDZCECsDBQAHAHAGgBQC9gqCYCuQA6BCAoBVQAjBLAIA5QAHBCAQA7ICjK+QAfB+AECPQAEDKgDCQIAGAEIDVGHQhJAmsRF1QtDGNiqBUg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程手, new cjs.Rectangle(-241.2,-272.3,482.4,544.8), null);


(lib.教程字2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.教程字2();
	this.instance.parent = this;
	this.instance.setTransform(-58.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程字2_1, new cjs.Rectangle(-58.5,-9.5,117,19), null);


(lib.教程字1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.教程字1();
	this.instance.parent = this;
	this.instance.setTransform(-59,-9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.教程字1_1, new cjs.Rectangle(-59,-9,118,18), null);


(lib.教学跑图标 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EganA75Qrqk8pApAQljljkDmqIDsAAQDiFbEmElQIjIkLHEtQLgE3MmAAQMlAALfk3QLHktIkokQIkokEtrHQE3rgAAslQAAslk3rfQktrHokokQokokrHktQrfk3slAAQsmAArgE3QrHEtojIkQokIkktLHQhOC5g4C1IjRAAQBCjiBdjaQE8rrI/o/QJApALqk8QMFlHNPAAQNNAAMFFHQLrE8I/JAQJAI/E8LrQFHMFAANNQAANOlHMFQk8LrpAI/Qo/JArrE8QsFFHtNAAQtPAAsFlHg");
	this.shape.setTransform(70.6,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAvIRIgkhRQjHnZhOn3IDLAAQBLHRC3GxQAlBWAjBJg");
	this.shape_1.setTransform(-322.3,117.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ah/HAQgEhhAAhVQAAlpA9lgIDKAAQhAFgAAFpQAABVAEBhg");
	this.shape_2.setTransform(-340.6,-26.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EAVJAkPQiFgkhCiIQizmMhnjUQi6mChehOQijiGkGilQlajaj4hXQgYgIgcgPQitDdj2CaQj4CbkcBAQknBDkmgpQk6gtkYijQiPhUgbiNQgZh/BLh2QBLh3B/gmQCPgpCQBUQDLB3DbgDQDIgCDGhmQC4hgCeiqQCZiiBmjLQDsnVB1jhQCplECTkAQlBhmkVBjQkfBnjfE5QhXB6iNAUQiAASh0hEQh1hDgihwQgmh9BYh7QG6pqJpiJQJuiJKLGDQAlAWDJBwQGgD3Fng9QF1g/EWmGQBXh6CNgUQB/gSB1BEQB0BDAiBwQAmB8hYB8QloH5nnC6QnnC5oVijQk9IflCJvQDHBlEJC6QC1CADBCaQCQBzDfHAQB7D3DMHBQBCCJg3B8QgyBwh6A5QhOAkhMAAQgsAAgrgMg");
	this.shape_3.setTransform(62.1,74.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AnPHQQjBjAAAkQQAAkPDBjAQDAjBEPAAQEQAADADBQDBDAAAEPQAAEQjBDAQjADBkQAAQkPAAjAjBg");
	this.shape_4.setTransform(169.7,-190.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AxuB4QgzAAgjgjQgjgjAAgyQAAgxAjgjQAjgjAzAAMAjdAAAQAyAAAkAjQAjAjAAAxQAAAygjAjQgkAjgyAAg");
	this.shape_5.setTransform(-352.5,192.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AzvB4QgxAAgkgjQgjgjAAgyQAAgxAjgjQAkgjAxAAMAnfAAAQAyAAAjAjQAjAjAAAxQAAAygjAjQgjAjgyAAg");
	this.shape_6.setTransform(-245.2,41.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AzvB4QgyAAgjgjQgjgjAAgyQAAgxAjgjQAjgjAyAAMAnfAAAQAyAAAjAjQAjAjAAAxQAAAygjAjQgjAjgyAAg");
	this.shape_7.setTransform(-325.1,-94.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AzvB4QgyAAgjgjQgjgjAAgyQAAgxAjgjQAjgjAyAAMAnfAAAQAyAAAjAjQAjAjAAAxQAAAygjAjQgjAjgyAAg");
	this.shape_8.setTransform(-99,-212.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.教学跑图标, new cjs.Rectangle(-478.1,-415.9,956.3,832), null);


(lib.adFlag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.6)").s().p("AC4BxIAAgPIh8AAIAAAPIgWAAIAAhdICoAAIAABdgAA8BSIB8AAIAAgqIh8AAgAjoBgQAQgSAHgbQAIgcgBgjIAAhAIBZAAIgJgXIgFgHIAbgGQAJASAFAPIgLADIBaAAIAAAVIitAAIAAAsQAAAXgCASQgBASgDAMQgEANgGAMQgGANgJAOgAAKgDIAAgUIBpAAIAAgjIg6AAQgHAOgLAOIgUgIQAMgPAIgRQAJgQAEgSIAWADIgIAYIAxAAIAAgjIAWAAIAAAjIBRAAIAAATIhRAAIAAAjIBgAAIAAAUg");
	this.shape.setTransform(39.2,11.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.adFlag, new cjs.Rectangle(15.8,0,46.7,22.5), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B2B2B").s().p("An9KeIAA07IP7AAIAAU7g");
	this.shape.setTransform(51,67);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,102,134), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.h头像框();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,121,160), null);


(lib.p4路4完成_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4路4完成();
	this.instance.parent = this;
	this.instance.setTransform(-67.5,-45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4路4完成_1, new cjs.Rectangle(-67.5,-45.5,135,91), null);


(lib.p4灯晕 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFDE00","rgba(255,255,0,0)"],[0,1],0,0,0,0,0,25.2).s().p("AiwCwQhJhIAAhoQAAhnBJhJQBJhJBnAAQBoAABIBJQBKBJAABnQAABohKBIQhIBKhoAAQhnAAhJhKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4灯晕, new cjs.Rectangle(-25,-25,50,50), null);


(lib.p4潜水艇 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_潜水艇();
	this.instance.parent = this;
	this.instance.setTransform(-46,-46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4潜水艇, new cjs.Rectangle(-46,-46,92,92), null);


(lib.p4房4问 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_房4问();
	this.instance.parent = this;
	this.instance.setTransform(-57,-56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4房4问, new cjs.Rectangle(-57,-56,114,112), null);


(lib.p4房2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_房2();
	this.instance.parent = this;
	this.instance.setTransform(-57.5,-100.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4房2, new cjs.Rectangle(-57.5,-100.5,115,201), null);


(lib.p4房1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_房1();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-118);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4房1, new cjs.Rectangle(-44.5,-118,89,118), null);


(lib.p4tv = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{aa:14});

	// timeline functions:
	this.frame_28 = function() {
		/* gotoAndPlay("aa");
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(28).call(this.frame_28).wait(13));

	// 显示器mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoSi0QHiAbJDjIIAAKJIwlA6g");

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6AC4C").s().p("AgpAqQgRgRgBgZQABgYARgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape.setTransform(-0.8,4.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E6AC4C").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAWAVQAUAVAAAcQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_1.setTransform(-0.8,4.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E6AC4C").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAlAAAZAZQAZAaAAAjQAAAkgZAaQgZAZglAAQgjAAgagZg");
	this.shape_2.setTransform(-0.8,4.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E6AC4C").s().p("AhLBNQghggAAgtQAAgsAhggQAfggAsAAQAtAAAhAgQAeAgAAAsQAAAtgeAgQghAggtAAQgsAAgfggg");
	this.shape_3.setTransform(-0.8,4.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E6AC4C").s().p("AhfBgQgngoAAg4QAAg3AngoQAognA3AAQA4AAAoAnQAnAoAAA3QAAA4gnAoQgoAng4AAQg3AAgogng");
	this.shape_4.setTransform(-0.8,4.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E6AC4C").s().p("Ah1B2QgxgxABhFQgBhEAxgxQAxgxBEABQBGgBAwAxQAxAxAABEQAABFgxAxQgwAwhGABQhEgBgxgwg");
	this.shape_5.setTransform(-0.8,4.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E6AC4C").s().p("AiPCPQg6g7AAhUQAAhUA6g7QA8g7BTAAQBVAAA7A7QA7A7AABUQAABUg7A7Qg7A8hVAAQhTAAg8g8g");
	this.shape_6.setTransform(-0.8,4.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E6AC4C").s().p("AirCtQhIhIAAhlQAAhlBIhHQBHhHBkAAQBmAABHBHQBHBHAABlQAABlhHBIQhHBHhmAAQhkAAhHhHg");
	this.shape_7.setTransform(-0.8,4.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E6AC4C").s().p("AjNDOQhUhVAAh5QAAh4BUhVQBWhVB3AAQB6AABUBVQBUBVAAB4QAAB5hUBVQhUBVh6AAQh3AAhWhVg");
	this.shape_8.setTransform(-0.8,4.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E6AC4C").s().p("AjxDyQhkhkAAiOQAAiOBkhjQBkhkCNAAQCPAABkBkQBjBjAACOQAACOhjBkQhkBkiPAAQiNAAhkhkg");
	this.shape_9.setTransform(-0.8,4.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E6AC4C").s().p("AkZEaQh0h1AAilQAAimB0hzQB0h1ClAAQCmAAB2B1QByBzAACmQAAClhyB1Qh2B1imAAQilAAh0h1g");
	this.shape_10.setTransform(-0.8,4.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E6AC4C").s().p("AlEFFQiHiGAAi/QAAi/CHiGQCGiGC+AAQDBAACGCGQCFCGAAC/QAAC/iFCGQiGCHjBAAQi+AAiGiHg");
	this.shape_11.setTransform(-0.8,4.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E6AC4C").s().p("AlzF0QibiZAAjbQAAjbCbiYQCZibDaAAQDcAACbCbQCYCYAADbQAADbiYCZQibCbjcAAQjaAAiZibg");
	this.shape_12.setTransform(-0.8,4.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E6AC4C").s().p("AmnGnQiuivAAj4QAAj5CuiuQCwiuD3AAQD6AACvCuQCuCuAAD5QAAD4iuCvQivCwj6AAQj3AAiwiwg");
	this.shape_13.setTransform(-0.8,4.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E6AC4C").s().p("AndHdQjFjFAAkYQAAkZDFjEQDGjFEXAAQEaAADFDFQDEDEAAEZQAAEYjEDFQjFDGkaAAQkXAAjGjGg");
	this.shape_14.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},26).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).wait(1));

	// Layer 5
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#5FB56E").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_15.setTransform(-0.9,4.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#5FB56E").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAVAVQAVAVAAAcQAAAdgVAVQgVAVgdAAQgcAAgVgVg");
	this.shape_16.setTransform(-0.9,4.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5FB56E").s().p("Ag9A+QgZgaAAgkQAAgjAZgZQAagaAjAAQAkAAAaAaQAZAZAAAjQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_17.setTransform(-0.9,4.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#5FB56E").s().p("AhMBNQggggAAgtQAAgsAggfQAgghAsAAQAtAAAgAhQAgAfAAAsQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_18.setTransform(-0.9,4.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#5FB56E").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAAoAoQAnAnAAA3QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_19.setTransform(-0.9,4.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#5FB56E").s().p("Ah1B2QgxgxABhFQgBhEAxgwQAxgxBEAAQBFAAAxAxQAwAwABBEQgBBFgwAxQgxAwhFABQhEgBgxgwg");
	this.shape_20.setTransform(-0.8,4.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#5FB56E").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA7A8QA7A6AABUQAABUg7A8Qg7A7hVAAQhTAAg7g7g");
	this.shape_21.setTransform(-0.9,4.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#5FB56E").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_22.setTransform(-0.9,4.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5FB56E").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB5AABWBWQBUBUAAB4QAAB5hUBVQhWBVh5AAQh4AAhUhVg");
	this.shape_23.setTransform(-0.9,4.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#5FB56E").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_24.setTransform(-0.9,4.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#5FB56E").s().p("AkYEbQh2h2AAilQAAimB2hyQB0h2CkAAQCmAAB2B2QBzByAACmQAAClhzB2Qh2B0imAAQikAAh0h0g");
	this.shape_25.setTransform(-0.9,4.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5FB56E").s().p("AlDFGQiIiHAAi/QAAi/CIiFQCFiHC+AAQDAAACICHQCECFAAC/QAAC/iECHQiICGjAAAQi+AAiFiGg");
	this.shape_26.setTransform(-0.9,4.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#5FB56E").s().p("AlyF2QicibAAjbQAAjbCciXQCYicDaAAQDbAACdCcQCXCXAADbQAADbiXCbQidCZjbAAQjaAAiYiZg");
	this.shape_27.setTransform(-0.8,4.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#5FB56E").s().p("AmlGoQiwiwAAj4QAAj5CwisQCtiwD4AAQD5AACxCwQCtCsAAD5QAAD4itCwQixCvj5AAQj4AAitivg");
	this.shape_28.setTransform(-0.8,4.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#5FB56E").s().p("AnbHfQjHjHAAkYQAAkZDHjCQDEjHEXAAQEZAADIDHQDCDCAAEZQAAEYjCDHQjIDEkZAAQkXAAjEjEg");
	this.shape_29.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_15}]},24).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).wait(3));

	// Layer 6
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#4774AA").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape_30.setTransform(-0.9,4.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#4774AA").s().p("AgxAyQgVgVAAgdQAAgdAVgUQAVgVAcAAQAdAAAWAVQAUAUAAAdQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_31.setTransform(-0.9,4.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#4774AA").s().p("Ag9A+QgZgaAAgkQAAgkAZgZQAagZAjAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_32.setTransform(-0.9,4.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#4774AA").s().p("AhMBNQggggAAgtQAAgtAggfQAgggAsAAQAtAAAhAgQAfAfAAAtQAAAtgfAgQghAggtAAQgsAAggggg");
	this.shape_33.setTransform(-0.9,4.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#4774AA").s().p("AheBgQgogoAAg4QAAg4AogmQAngoA3AAQA4AAApAoQAmAmAAA4QAAA4gmAoQgpAng4AAQg3AAgngng");
	this.shape_34.setTransform(-0.9,4.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#4774AA").s().p("Ah1B2QgxgxABhFQgBhFAxgvQAxgxBEAAQBFAAAxAxQAxAvAABFQAABFgxAxQgxAxhFAAQhEAAgxgxg");
	this.shape_35.setTransform(-0.8,4.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#4774AA").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_36.setTransform(-0.9,4.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#4774AA").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_37.setTransform(-0.9,4.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#4774AA").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB5AABXBWQBTBUAAB4QAAB5hTBVQhXBVh5AAQh4AAhUhVg");
	this.shape_38.setTransform(-0.9,4.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#4774AA").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_39.setTransform(-0.9,4.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#4774AA").s().p("AkYEbQh2h2AAilQAAilB2hzQB0h2ClAAQCmAAB2B2QByBzAAClQAAClhyB2Qh2B0imAAQilAAh0h0g");
	this.shape_40.setTransform(-0.9,4.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#4774AA").s().p("AlDFHQiIiIAAi/QAAi/CIiEQCFiIC/AAQC/AACJCIQCDCEAAC/QAAC/iDCIQiJCFi/AAQi/AAiFiFg");
	this.shape_41.setTransform(-0.9,4.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#4774AA").s().p("AlyF3QicidAAjaQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADaiXCdQicCYjcAAQjaAAiYiYg");
	this.shape_42.setTransform(-0.8,4.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#4774AA").s().p("AmlGpQiwixAAj4QAAj4CwitQCuiwD3AAQD6AACxCwQCsCtAAD4QAAD4isCxQixCuj6AAQj3AAiuiug");
	this.shape_43.setTransform(-0.8,4.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#4774AA").s().p("AnbHfQjHjHAAkYQAAkYDHjDQDEjHEXAAQEaAADIDHQDBDDAAEYQAAEYjBDHQjIDEkaAAQkXAAjEjEg");
	this.shape_44.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_30}]},22).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).wait(5));

	// Layer 7
	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#75426F").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_45.setTransform(-0.9,4.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#75426F").s().p("AgxAyQgVgVAAgdQAAgdAVgUQAVgVAcAAQAdAAAVAVQAVAUAAAdQAAAdgVAVQgVAVgdAAQgcAAgVgVg");
	this.shape_46.setTransform(-0.9,4.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#75426F").s().p("Ag9A+QgZgaAAgkQAAgkAZgZQAagZAjAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_47.setTransform(-0.9,4.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#75426F").s().p("AhMBNQggggAAgtQAAgtAggfQAgggAsAAQAtAAAgAgQAgAfAAAtQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_48.setTransform(-0.9,4.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#75426F").s().p("AheBgQgogoAAg4QAAg4AogmQAngoA3AAQA4AAAoAoQAnAmAAA4QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_49.setTransform(-0.9,4.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#75426F").s().p("Ah1B2QgxgxABhFQgBhFAxgvQAxgxBEAAQBFAAAxAxQAwAvABBFQgBBFgwAxQgxAwhFABQhEgBgxgwg");
	this.shape_50.setTransform(-0.8,4.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#75426F").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_51.setTransform(-0.9,4.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#75426F").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_52.setTransform(-0.9,4.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#75426F").s().p("AjMDOQhWhWAAh4QAAh4BWhUQBUhWB4AAQB5AABWBWQBUBUAAB4QAAB4hUBWQhWBVh5AAQh4AAhUhVg");
	this.shape_53.setTransform(-0.9,4.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#75426F").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_54.setTransform(-0.9,4.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#75426F").s().p("AkYEbQh2h2AAilQAAilB2hzQBzh2ClAAQCnAAB1B2QBzBzAAClQAAClhzB2Qh1B0inAAQilAAhzh0g");
	this.shape_55.setTransform(-0.9,4.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#75426F").s().p("AlDFGQiIiIAAi+QAAi/CIiEQCFiIC+AAQDAAACICIQCECEAAC/QAAC+iECIQiICGjAAAQi+AAiFiGg");
	this.shape_56.setTransform(-0.9,4.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#75426F").s().p("AlyF2QicicAAjZQAAjbCciYQCYicDaAAQDcAACcCcQCXCYAADbQAADZiXCcQicCZjcAAQjaAAiYiZg");
	this.shape_57.setTransform(-0.8,4.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#75426F").s().p("AmlGoQiwiwAAj3QAAj5CwitQCuiwD3AAQD6AACxCwQCsCtAAD5QAAD3isCwQixCvj6AAQj3AAiuivg");
	this.shape_58.setTransform(-0.8,4.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#75426F").s().p("AnbHfQjHjIAAkWQAAkZDHjDQDDjHEYAAQEaAADIDHQDBDDAAEZQAAEWjBDIQjIDEkaAAQkYAAjDjEg");
	this.shape_59.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_45}]},20).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).wait(7));

	// Layer 8
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#DD4A7D").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape_60.setTransform(-0.9,4.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#DD4A7D").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAWAVQAUAVAAAcQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_61.setTransform(-0.9,4.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#DD4A7D").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAkAAAaAZQAZAaAAAjQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_62.setTransform(-0.9,4.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#DD4A7D").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAtAAAhAgQAfAgAAAsQAAAtgfAgQghAggtAAQgsAAggggg");
	this.shape_63.setTransform(-0.9,4.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#DD4A7D").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAApAoQAmAnAAA3QAAA4gmAoQgpAng4AAQg3AAgngng");
	this.shape_64.setTransform(-0.9,4.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#DD4A7D").s().p("Ah1B2QgxgxABhFQgBhEAxgxQAwgxBFABQBGgBAwAxQAxAxAABEQAABFgxAxQgwAwhGABQhFgBgwgwg");
	this.shape_65.setTransform(-0.8,4.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#DD4A7D").s().p("AiOCQQg8g8AAhUQAAhTA8g7QA7g8BTAAQBVAAA8A8QA6A7AABTQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_66.setTransform(-0.9,4.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#DD4A7D").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABJBIQBFBGAABlQAABlhFBIQhJBHhmAAQhkAAhHhHg");
	this.shape_67.setTransform(-0.9,4.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#DD4A7D").s().p("AjMDOQhWhWAAh4QAAh4BWhUQBUhWB4AAQB6AABWBWQBTBUAAB4QAAB4hTBWQhWBVh6AAQh4AAhUhVg");
	this.shape_68.setTransform(-0.9,4.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#DD4A7D").s().p("AjwDyQhlhkAAiOQAAiOBlhjQBjhkCNAAQCPAABmBkQBhBjAACOQAACOhhBkQhmBkiPAAQiNAAhjhkg");
	this.shape_69.setTransform(-0.9,4.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#DD4A7D").s().p("AkYEaQh2h1AAilQAAilB2hzQBzh2CmAAQCmAAB2B2QByBzAAClQAAClhyB1Qh2B1imAAQimAAhzh1g");
	this.shape_70.setTransform(-0.9,4.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#DD4A7D").s().p("AlDFGQiIiIAAi+QAAi/CIiFQCFiHC/AAQDAAACICHQCDCFAAC/QAAC+iDCIQiICGjAAAQi/AAiFiGg");
	this.shape_71.setTransform(-0.9,4.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#DD4A7D").s().p("AlyF2QicicAAjaQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADaiXCcQicCZjcAAQjaAAiYiZg");
	this.shape_72.setTransform(-0.8,4.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#DD4A7D").s().p("AmlGoQiwiwAAj4QAAj4CwitQCuiwD3AAQD6AACyCwQCqCtABD4QgBD4iqCwQiyCvj6AAQj3AAiuivg");
	this.shape_73.setTransform(-0.8,4.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#DD4A7D").s().p("AnbHeQjHjHAAkXQAAkYDHjDQDEjHEXAAQEaAADIDHQDBDDAAEYQAAEXjBDHQjIDFkaAAQkXAAjEjFg");
	this.shape_74.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_60}]},18).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).wait(9));

	// Layer 9
	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#4DB1DF").s().p("AgpArQgSgSAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSASQgRARgZAAQgYAAgRgRg");
	this.shape_75.setTransform(-0.9,4.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#4DB1DF").s().p("AgxAzQgVgWAAgdQAAgcAVgVQAUgVAdAAQAdAAAVAVQAVAVAAAcQAAAdgVAWQgVAUgdAAQgdAAgUgUg");
	this.shape_76.setTransform(-0.9,4.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#4DB1DF").s().p("Ag9A+QgZgaAAgkQAAgjAZgZQAZgaAkAAQAkAAAaAaQAZAZAAAjQAAAkgZAaQgaAZgkAAQgkAAgZgZg");
	this.shape_77.setTransform(-0.9,4.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#4DB1DF").s().p("AhMBNQggggAAgtQAAgsAggfQAfghAtAAQAtAAAgAhQAgAfAAAsQAAAtggAgQggAggtAAQgtAAgfggg");
	this.shape_78.setTransform(-0.9,4.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#4DB1DF").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAAoAoQAnAnAAA3QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_79.setTransform(-0.9,4.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#4DB1DF").s().p("Ah1B2QgxgxABhFQgBhEAxgwQAxgxBEAAQBFAAAxAxQAwAwABBEQgBBFgwAxQgxAxhFAAQhEAAgxgxg");
	this.shape_80.setTransform(-0.8,4.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#4DB1DF").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA6g8BUAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhUAAg6g7g");
	this.shape_81.setTransform(-0.9,4.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#4DB1DF").s().p("AirCuQhIhJAAhlQAAhlBIhGQBGhIBlAAQBmAABIBIQBGBGAABlQAABlhGBJQhIBGhmAAQhlAAhGhGg");
	this.shape_82.setTransform(-0.9,4.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#4DB1DF").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB6AABVBWQBUBUAAB4QAAB5hUBVQhVBVh6AAQh4AAhUhVg");
	this.shape_83.setTransform(-0.9,4.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#4DB1DF").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_84.setTransform(-0.9,4.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#4DB1DF").s().p("AkYEbQh2h2AAilQAAilB2hzQBzh2ClAAQCnAAB1B2QBzBzAAClQAAClhzB2Qh1B0inAAQilAAhzh0g");
	this.shape_85.setTransform(-0.9,4.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#4DB1DF").s().p("AlDFHQiIiIAAi/QAAi/CIiFQCFiHC+AAQDBAACHCHQCECFAAC/QAAC/iECIQiHCFjBAAQi+AAiFiFg");
	this.shape_86.setTransform(-0.9,4.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#4DB1DF").s().p("AlyF2QicibAAjbQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADbiXCbQicCZjcAAQjaAAiYiZg");
	this.shape_87.setTransform(-0.8,4.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#4DB1DF").s().p("AmlGoQiwiwAAj4QAAj5CwisQCtiwD4AAQD7AACwCwQCsCsAAD5QAAD4isCwQiwCvj7AAQj4AAitivg");
	this.shape_88.setTransform(-0.8,4.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#4DB1DF").s().p("AnbHfQjHjHAAkYQAAkZDHjCQDEjHEXAAQEbAADHDHQDBDCAAEZQAAEYjBDHQjHDEkbAAQkXAAjEjEg");
	this.shape_89.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_75}]},16).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).wait(11));

	// 黄色
	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#EEE54D").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_90.setTransform(-0.9,4.1);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#EEE54D").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAeAAAUAVQAVAVAAAcQAAAdgVAVQgUAVgeAAQgcAAgVgVg");
	this.shape_91.setTransform(-0.9,4.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#EEE54D").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAlAAAZAZQAZAaAAAjQAAAkgZAaQgZAZglAAQgjAAgagZg");
	this.shape_92.setTransform(-0.9,4.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#EEE54D").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAuAAAfAgQAgAgAAAsQAAAtggAgQgfAgguAAQgsAAggggg");
	this.shape_93.setTransform(-0.9,4.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EEE54D").s().p("AhfBgQgngoAAg4QAAg3AngoQAognA3AAQA5AAAnAnQAnAoAAA3QAAA4gnAoQgnAng5AAQg3AAgogng");
	this.shape_94.setTransform(-0.9,4.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#EEE54D").s().p("Ah1B2QgwgxAAhFQAAhEAwgxQAwgxBFABQBGgBAvAxQAyAxAABEQAABFgyAxQgvAwhGABQhFgBgwgwg");
	this.shape_95.setTransform(-0.8,4.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#EEE54D").s().p("AiPCQQg7g8AAhUQAAhTA7g8QA8g7BTAAQBVAAA7A7QA7A8AABTQAABUg7A8Qg7A7hVAAQhTAAg8g7g");
	this.shape_96.setTransform(-0.9,4.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#EEE54D").s().p("AisCtQhHhHAAhmQAAhlBHhHQBHhHBlAAQBmAABHBHQBHBHAABlQAABmhHBHQhHBHhmAAQhlAAhHhHg");
	this.shape_97.setTransform(-0.9,4.1);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#EEE54D").s().p("AjNDOQhVhVAAh5QAAh4BVhVQBVhVB4AAQB6AABUBVQBVBVAAB4QAAB5hVBVQhUBVh6AAQh4AAhVhVg");
	this.shape_98.setTransform(-0.9,4.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#EEE54D").s().p("AjxDyQhkhjAAiPQAAiOBkhjQBkhkCNAAQCPAABjBkQBkBjAACOQAACPhkBjQhjBkiPAAQiNAAhkhkg");
	this.shape_99.setTransform(-0.9,4.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#EEE54D").s().p("AkZEaQh1h0AAimQAAilB1h0QB0h1ClAAQCnAABzB1QB1B0AAClQAACmh1B0QhzB1inAAQilAAh0h1g");
	this.shape_100.setTransform(-0.9,4.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#EEE54D").s().p("AlFFGQiGiGAAjAQAAi/CGiGQCHiGC+AAQDAAACGCGQCGCGAAC/QAADAiGCGQiGCGjAAAQi+AAiHiGg");
	this.shape_101.setTransform(-0.9,4.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#EEE54D").s().p("Al0F1QiaiZAAjcQAAjaCaiaQCZiaDbAAQDcAACZCaQCaCaAADaQAADciaCZQiZCajcAAQjbAAiZiag");
	this.shape_102.setTransform(-0.8,4.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#EEE54D").s().p("AmnGoQiuivAAj5QAAj4CuivQCviuD4AAQD5AACuCuQCwCvAAD4QAAD5iwCvQiuCvj5AAQj4AAivivg");
	this.shape_103.setTransform(-0.8,4.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#EEE54D").s().p("AndHeQjFjFAAkZQAAkYDFjFQDFjFEYAAQEZAADFDFQDFDFAAEYQAAEZjFDFQjFDFkZAAQkYAAjFjFg");
	this.shape_104.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_90}]},14).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).wait(13));

	// Layer 11
	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#E6AC4C").s().p("AgpAqQgRgRgBgZQABgYARgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape_105.setTransform(-0.8,4.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#E6AC4C").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAWAVQAUAVAAAcQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_106.setTransform(-0.8,4.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#E6AC4C").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAlAAAZAZQAZAaAAAjQAAAkgZAaQgZAZglAAQgjAAgagZg");
	this.shape_107.setTransform(-0.8,4.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#E6AC4C").s().p("AhLBNQghggAAgtQAAgsAhggQAfggAsAAQAtAAAhAgQAeAgAAAsQAAAtgeAgQghAggtAAQgsAAgfggg");
	this.shape_108.setTransform(-0.8,4.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#E6AC4C").s().p("AhfBgQgngoAAg4QAAg3AngoQAognA3AAQA4AAAoAnQAnAoAAA3QAAA4gnAoQgoAng4AAQg3AAgogng");
	this.shape_109.setTransform(-0.8,4.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#E6AC4C").s().p("Ah1B2QgxgxABhFQgBhEAxgxQAxgxBEABQBGgBAwAxQAxAxAABEQAABFgxAxQgwAwhGABQhEgBgxgwg");
	this.shape_110.setTransform(-0.8,4.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#E6AC4C").s().p("AiPCPQg6g7AAhUQAAhUA6g7QA8g7BTAAQBVAAA7A7QA7A7AABUQAABUg7A7Qg7A8hVAAQhTAAg8g8g");
	this.shape_111.setTransform(-0.8,4.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#E6AC4C").s().p("AirCtQhIhIAAhlQAAhlBIhHQBHhHBkAAQBmAABHBHQBHBHAABlQAABlhHBIQhHBHhmAAQhkAAhHhHg");
	this.shape_112.setTransform(-0.8,4.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#E6AC4C").s().p("AjNDOQhUhVAAh5QAAh4BUhVQBWhVB3AAQB6AABUBVQBUBVAAB4QAAB5hUBVQhUBVh6AAQh3AAhWhVg");
	this.shape_113.setTransform(-0.8,4.1);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#E6AC4C").s().p("AjxDyQhkhkAAiOQAAiOBkhjQBkhkCNAAQCPAABkBkQBjBjAACOQAACOhjBkQhkBkiPAAQiNAAhkhkg");
	this.shape_114.setTransform(-0.8,4.1);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#E6AC4C").s().p("AkZEaQh0h1AAilQAAimB0hzQB0h1ClAAQCmAAB2B1QByBzAACmQAAClhyB1Qh2B1imAAQilAAh0h1g");
	this.shape_115.setTransform(-0.8,4.1);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#E6AC4C").s().p("AlEFFQiHiGAAi/QAAi/CHiGQCGiGC+AAQDBAACGCGQCFCGAAC/QAAC/iFCGQiGCHjBAAQi+AAiGiHg");
	this.shape_116.setTransform(-0.8,4.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#E6AC4C").s().p("AlzF0QibiZAAjbQAAjbCbiYQCZibDaAAQDcAACbCbQCYCYAADbQAADbiYCZQibCbjcAAQjaAAiZibg");
	this.shape_117.setTransform(-0.8,4.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#E6AC4C").s().p("AmnGnQiuivAAj4QAAj5CuiuQCwiuD3AAQD6AACvCuQCuCuAAD5QAAD4iuCvQivCwj6AAQj3AAiwiwg");
	this.shape_118.setTransform(-0.8,4.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#E6AC4C").s().p("AndHdQjFjFAAkYQAAkZDFjEQDGjFEXAAQEaAADFDFQDEDEAAEZQAAEYjEDFQjFDGkaAAQkXAAjGjGg");
	this.shape_119.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_105}]},12).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).wait(15));

	// Layer 12
	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#5FB56E").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_120.setTransform(-0.9,4.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#5FB56E").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAVAVQAVAVAAAcQAAAdgVAVQgVAVgdAAQgcAAgVgVg");
	this.shape_121.setTransform(-0.9,4.1);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#5FB56E").s().p("Ag9A+QgZgaAAgkQAAgjAZgZQAagaAjAAQAkAAAaAaQAZAZAAAjQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_122.setTransform(-0.9,4.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#5FB56E").s().p("AhMBNQggggAAgtQAAgsAggfQAgghAsAAQAtAAAgAhQAgAfAAAsQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_123.setTransform(-0.9,4.1);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#5FB56E").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAAoAoQAnAnAAA3QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_124.setTransform(-0.9,4.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#5FB56E").s().p("Ah1B2QgxgxABhFQgBhEAxgwQAxgxBEAAQBFAAAxAxQAwAwABBEQgBBFgwAxQgxAwhFABQhEgBgxgwg");
	this.shape_125.setTransform(-0.8,4.1);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#5FB56E").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA7A8QA7A6AABUQAABUg7A8Qg7A7hVAAQhTAAg7g7g");
	this.shape_126.setTransform(-0.9,4.1);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#5FB56E").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_127.setTransform(-0.9,4.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#5FB56E").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB5AABWBWQBUBUAAB4QAAB5hUBVQhWBVh5AAQh4AAhUhVg");
	this.shape_128.setTransform(-0.9,4.1);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#5FB56E").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_129.setTransform(-0.9,4.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#5FB56E").s().p("AkYEbQh2h2AAilQAAimB2hyQB0h2CkAAQCmAAB2B2QBzByAACmQAAClhzB2Qh2B0imAAQikAAh0h0g");
	this.shape_130.setTransform(-0.9,4.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#5FB56E").s().p("AlDFGQiIiHAAi/QAAi/CIiFQCFiHC+AAQDAAACICHQCECFAAC/QAAC/iECHQiICGjAAAQi+AAiFiGg");
	this.shape_131.setTransform(-0.9,4.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#5FB56E").s().p("AlyF2QicibAAjbQAAjbCciXQCYicDaAAQDbAACdCcQCXCXAADbQAADbiXCbQidCZjbAAQjaAAiYiZg");
	this.shape_132.setTransform(-0.8,4.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#5FB56E").s().p("AmlGoQiwiwAAj4QAAj5CwisQCtiwD4AAQD5AACxCwQCtCsAAD5QAAD4itCwQixCvj5AAQj4AAitivg");
	this.shape_133.setTransform(-0.8,4.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#5FB56E").s().p("AnbHfQjHjHAAkYQAAkZDHjCQDEjHEXAAQEZAADIDHQDCDCAAEZQAAEYjCDHQjIDEkZAAQkXAAjEjEg");
	this.shape_134.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_120}]},10).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).wait(17));

	// Layer 13
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#4774AA").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape_135.setTransform(-0.9,4.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#4774AA").s().p("AgxAyQgVgVAAgdQAAgdAVgUQAVgVAcAAQAdAAAWAVQAUAUAAAdQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_136.setTransform(-0.9,4.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#4774AA").s().p("Ag9A+QgZgaAAgkQAAgkAZgZQAagZAjAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_137.setTransform(-0.9,4.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#4774AA").s().p("AhMBNQggggAAgtQAAgtAggfQAgggAsAAQAtAAAhAgQAfAfAAAtQAAAtgfAgQghAggtAAQgsAAggggg");
	this.shape_138.setTransform(-0.9,4.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#4774AA").s().p("AheBgQgogoAAg4QAAg4AogmQAngoA3AAQA4AAApAoQAmAmAAA4QAAA4gmAoQgpAng4AAQg3AAgngng");
	this.shape_139.setTransform(-0.9,4.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#4774AA").s().p("Ah1B2QgxgxABhFQgBhFAxgvQAxgxBEAAQBFAAAxAxQAxAvAABFQAABFgxAxQgxAxhFAAQhEAAgxgxg");
	this.shape_140.setTransform(-0.8,4.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#4774AA").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_141.setTransform(-0.9,4.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#4774AA").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_142.setTransform(-0.9,4.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#4774AA").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB5AABXBWQBTBUAAB4QAAB5hTBVQhXBVh5AAQh4AAhUhVg");
	this.shape_143.setTransform(-0.9,4.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#4774AA").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_144.setTransform(-0.9,4.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#4774AA").s().p("AkYEbQh2h2AAilQAAilB2hzQB0h2ClAAQCmAAB2B2QByBzAAClQAAClhyB2Qh2B0imAAQilAAh0h0g");
	this.shape_145.setTransform(-0.9,4.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#4774AA").s().p("AlDFHQiIiIAAi/QAAi/CIiEQCFiIC/AAQC/AACJCIQCDCEAAC/QAAC/iDCIQiJCFi/AAQi/AAiFiFg");
	this.shape_146.setTransform(-0.9,4.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#4774AA").s().p("AlyF3QicidAAjaQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADaiXCdQicCYjcAAQjaAAiYiYg");
	this.shape_147.setTransform(-0.8,4.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#4774AA").s().p("AmlGpQiwixAAj4QAAj4CwitQCuiwD3AAQD6AACxCwQCsCtAAD4QAAD4isCxQixCuj6AAQj3AAiuiug");
	this.shape_148.setTransform(-0.8,4.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#4774AA").s().p("AnbHfQjHjHAAkYQAAkYDHjDQDEjHEXAAQEaAADIDHQDBDDAAEYQAAEYjBDHQjIDEkaAAQkXAAjEjEg");
	this.shape_149.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_135}]},8).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).wait(19));

	// Layer 14
	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#75426F").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_150.setTransform(-0.9,4.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#75426F").s().p("AgxAyQgVgVAAgdQAAgdAVgUQAVgVAcAAQAdAAAVAVQAVAUAAAdQAAAdgVAVQgVAVgdAAQgcAAgVgVg");
	this.shape_151.setTransform(-0.9,4.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#75426F").s().p("Ag9A+QgZgaAAgkQAAgkAZgZQAagZAjAAQAkAAAaAZQAZAZAAAkQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_152.setTransform(-0.9,4.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#75426F").s().p("AhMBNQggggAAgtQAAgtAggfQAgggAsAAQAtAAAgAgQAgAfAAAtQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_153.setTransform(-0.9,4.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#75426F").s().p("AheBgQgogoAAg4QAAg4AogmQAngoA3AAQA4AAAoAoQAnAmAAA4QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_154.setTransform(-0.9,4.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#75426F").s().p("Ah1B2QgxgxABhFQgBhFAxgvQAxgxBEAAQBFAAAxAxQAwAvABBFQgBBFgwAxQgxAwhFABQhEgBgxgwg");
	this.shape_155.setTransform(-0.8,4.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#75426F").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA7g8BTAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_156.setTransform(-0.9,4.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#75426F").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABIBIQBGBGAABlQAABlhGBIQhIBHhmAAQhkAAhHhHg");
	this.shape_157.setTransform(-0.9,4.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#75426F").s().p("AjMDOQhWhWAAh4QAAh4BWhUQBUhWB4AAQB5AABWBWQBUBUAAB4QAAB4hUBWQhWBVh5AAQh4AAhUhVg");
	this.shape_158.setTransform(-0.9,4.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#75426F").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_159.setTransform(-0.9,4.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#75426F").s().p("AkYEbQh2h2AAilQAAilB2hzQBzh2ClAAQCnAAB1B2QBzBzAAClQAAClhzB2Qh1B0inAAQilAAhzh0g");
	this.shape_160.setTransform(-0.9,4.1);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#75426F").s().p("AlDFGQiIiIAAi+QAAi/CIiEQCFiIC+AAQDAAACICIQCECEAAC/QAAC+iECIQiICGjAAAQi+AAiFiGg");
	this.shape_161.setTransform(-0.9,4.1);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#75426F").s().p("AlyF2QicicAAjZQAAjbCciYQCYicDaAAQDcAACcCcQCXCYAADbQAADZiXCcQicCZjcAAQjaAAiYiZg");
	this.shape_162.setTransform(-0.8,4.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#75426F").s().p("AmlGoQiwiwAAj3QAAj5CwitQCuiwD3AAQD6AACxCwQCsCtAAD5QAAD3isCwQixCvj6AAQj3AAiuivg");
	this.shape_163.setTransform(-0.8,4.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#75426F").s().p("AnbHfQjHjIAAkWQAAkZDHjDQDDjHEYAAQEaAADIDHQDBDDAAEZQAAEWjBDIQjIDEkaAAQkYAAjDjEg");
	this.shape_164.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.shape_164];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_150}]},6).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).wait(21));

	// Layer 15
	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#DD4A7D").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAASASQARARAAAYQAAAZgRARQgSASgZAAQgYAAgRgSg");
	this.shape_165.setTransform(-0.9,4.1);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#DD4A7D").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAWAVQAUAVAAAcQAAAdgUAVQgWAVgdAAQgcAAgVgVg");
	this.shape_166.setTransform(-0.9,4.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#DD4A7D").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAkAAAaAZQAZAaAAAjQAAAkgZAaQgaAZgkAAQgjAAgagZg");
	this.shape_167.setTransform(-0.9,4.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#DD4A7D").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAtAAAhAgQAfAgAAAsQAAAtgfAgQghAggtAAQgsAAggggg");
	this.shape_168.setTransform(-0.9,4.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#DD4A7D").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAApAoQAmAnAAA3QAAA4gmAoQgpAng4AAQg3AAgngng");
	this.shape_169.setTransform(-0.9,4.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#DD4A7D").s().p("Ah1B2QgxgxABhFQgBhEAxgxQAwgxBFABQBGgBAwAxQAxAxAABEQAABFgxAxQgwAwhGABQhFgBgwgwg");
	this.shape_170.setTransform(-0.8,4.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#DD4A7D").s().p("AiOCQQg8g8AAhUQAAhTA8g7QA7g8BTAAQBVAAA8A8QA6A7AABTQAABUg6A8Qg8A7hVAAQhTAAg7g7g");
	this.shape_171.setTransform(-0.9,4.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#DD4A7D").s().p("AirCtQhIhIAAhlQAAhlBIhGQBHhIBkAAQBmAABJBIQBFBGAABlQAABlhFBIQhJBHhmAAQhkAAhHhHg");
	this.shape_172.setTransform(-0.9,4.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#DD4A7D").s().p("AjMDOQhWhWAAh4QAAh4BWhUQBUhWB4AAQB6AABWBWQBTBUAAB4QAAB4hTBWQhWBVh6AAQh4AAhUhVg");
	this.shape_173.setTransform(-0.9,4.1);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#DD4A7D").s().p("AjwDyQhlhkAAiOQAAiOBlhjQBjhkCNAAQCPAABmBkQBhBjAACOQAACOhhBkQhmBkiPAAQiNAAhjhkg");
	this.shape_174.setTransform(-0.9,4.1);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#DD4A7D").s().p("AkYEaQh2h1AAilQAAilB2hzQBzh2CmAAQCmAAB2B2QByBzAAClQAAClhyB1Qh2B1imAAQimAAhzh1g");
	this.shape_175.setTransform(-0.9,4.1);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#DD4A7D").s().p("AlDFGQiIiIAAi+QAAi/CIiFQCFiHC/AAQDAAACICHQCDCFAAC/QAAC+iDCIQiICGjAAAQi/AAiFiGg");
	this.shape_176.setTransform(-0.9,4.1);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#DD4A7D").s().p("AlyF2QicicAAjaQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADaiXCcQicCZjcAAQjaAAiYiZg");
	this.shape_177.setTransform(-0.8,4.1);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#DD4A7D").s().p("AmlGoQiwiwAAj4QAAj4CwitQCuiwD3AAQD6AACyCwQCqCtABD4QgBD4iqCwQiyCvj6AAQj3AAiuivg");
	this.shape_178.setTransform(-0.8,4.1);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#DD4A7D").s().p("AnbHeQjHjHAAkXQAAkYDHjDQDEjHEXAAQEaAADIDHQDBDDAAEYQAAEXjBDHQjIDFkaAAQkXAAjEjFg");
	this.shape_179.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_165,this.shape_166,this.shape_167,this.shape_168,this.shape_169,this.shape_170,this.shape_171,this.shape_172,this.shape_173,this.shape_174,this.shape_175,this.shape_176,this.shape_177,this.shape_178,this.shape_179];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_165}]},4).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).wait(23));

	// Layer 16
	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#4DB1DF").s().p("AgpArQgSgSAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSASQgRARgZAAQgYAAgRgRg");
	this.shape_180.setTransform(-0.9,4.1);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#4DB1DF").s().p("AgxAzQgVgWAAgdQAAgcAVgVQAUgVAdAAQAdAAAVAVQAVAVAAAcQAAAdgVAWQgVAUgdAAQgdAAgUgUg");
	this.shape_181.setTransform(-0.9,4.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#4DB1DF").s().p("Ag9A+QgZgaAAgkQAAgjAZgZQAZgaAkAAQAkAAAaAaQAZAZAAAjQAAAkgZAaQgaAZgkAAQgkAAgZgZg");
	this.shape_182.setTransform(-0.9,4.1);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#4DB1DF").s().p("AhMBNQggggAAgtQAAgsAggfQAfghAtAAQAtAAAgAhQAgAfAAAsQAAAtggAgQggAggtAAQgtAAgfggg");
	this.shape_183.setTransform(-0.9,4.1);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#4DB1DF").s().p("AheBgQgogoAAg4QAAg3AognQAngoA3AAQA4AAAoAoQAnAnAAA3QAAA4gnAoQgoAng4AAQg3AAgngng");
	this.shape_184.setTransform(-0.9,4.1);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#4DB1DF").s().p("Ah1B2QgxgxABhFQgBhEAxgwQAxgxBEAAQBFAAAxAxQAwAwABBEQgBBFgwAxQgxAxhFAAQhEAAgxgxg");
	this.shape_185.setTransform(-0.8,4.1);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#4DB1DF").s().p("AiOCQQg8g8AAhUQAAhUA8g6QA6g8BUAAQBVAAA8A8QA6A6AABUQAABUg6A8Qg8A7hVAAQhUAAg6g7g");
	this.shape_186.setTransform(-0.9,4.1);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#4DB1DF").s().p("AirCuQhIhJAAhlQAAhlBIhGQBGhIBlAAQBmAABIBIQBGBGAABlQAABlhGBJQhIBGhmAAQhlAAhGhGg");
	this.shape_187.setTransform(-0.9,4.1);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#4DB1DF").s().p("AjMDOQhWhVAAh5QAAh4BWhUQBUhWB4AAQB6AABVBWQBUBUAAB4QAAB5hUBVQhVBVh6AAQh4AAhUhVg");
	this.shape_188.setTransform(-0.9,4.1);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#4DB1DF").s().p("AjwDzQhlhlAAiOQAAiOBlhiQBjhlCNAAQCPAABlBlQBiBiAACOQAACOhiBlQhlBjiPAAQiNAAhjhjg");
	this.shape_189.setTransform(-0.9,4.1);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#4DB1DF").s().p("AkYEbQh2h2AAilQAAilB2hzQBzh2ClAAQCnAAB1B2QBzBzAAClQAAClhzB2Qh1B0inAAQilAAhzh0g");
	this.shape_190.setTransform(-0.9,4.1);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#4DB1DF").s().p("AlDFHQiIiIAAi/QAAi/CIiFQCFiHC+AAQDBAACHCHQCECFAAC/QAAC/iECIQiHCFjBAAQi+AAiFiFg");
	this.shape_191.setTransform(-0.9,4.1);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#4DB1DF").s().p("AlyF2QicibAAjbQAAjaCciYQCYicDaAAQDcAACcCcQCXCYAADaQAADbiXCbQicCZjcAAQjaAAiYiZg");
	this.shape_192.setTransform(-0.8,4.1);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#4DB1DF").s().p("AmlGoQiwiwAAj4QAAj5CwisQCtiwD4AAQD7AACwCwQCsCsAAD5QAAD4isCwQiwCvj7AAQj4AAitivg");
	this.shape_193.setTransform(-0.8,4.1);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#4DB1DF").s().p("AnbHfQjHjHAAkYQAAkZDHjCQDEjHEXAAQEbAADHDHQDBDCAAEZQAAEYjBDHQjHDEkbAAQkXAAjEjEg");
	this.shape_194.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_180,this.shape_181,this.shape_182,this.shape_183,this.shape_184,this.shape_185,this.shape_186,this.shape_187,this.shape_188,this.shape_189,this.shape_190,this.shape_191,this.shape_192,this.shape_193,this.shape_194];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_180}]},2).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).wait(25));

	// Layer 17
	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#EEE54D").s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSg");
	this.shape_195.setTransform(-0.9,4.1);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#EEE54D").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAeAAAUAVQAVAVAAAcQAAAdgVAVQgUAVgeAAQgcAAgVgVg");
	this.shape_196.setTransform(-0.9,4.1);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#EEE54D").s().p("Ag9A+QgZgaAAgkQAAgjAZgaQAagZAjAAQAlAAAZAZQAZAaAAAjQAAAkgZAaQgZAZglAAQgjAAgagZg");
	this.shape_197.setTransform(-0.9,4.1);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#EEE54D").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAuAAAfAgQAgAgAAAsQAAAtggAgQgfAgguAAQgsAAggggg");
	this.shape_198.setTransform(-0.9,4.1);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#EEE54D").s().p("AhfBgQgngoAAg4QAAg3AngoQAognA3AAQA5AAAnAnQAnAoAAA3QAAA4gnAoQgnAng5AAQg3AAgogng");
	this.shape_199.setTransform(-0.9,4.1);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#EEE54D").s().p("Ah1B2QgwgxAAhFQAAhEAwgxQAwgxBFABQBGgBAvAxQAyAxAABEQAABFgyAxQgvAwhGABQhFgBgwgwg");
	this.shape_200.setTransform(-0.8,4.1);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#EEE54D").s().p("AiPCQQg7g8AAhUQAAhTA7g8QA8g7BTAAQBVAAA7A7QA7A8AABTQAABUg7A8Qg7A7hVAAQhTAAg8g7g");
	this.shape_201.setTransform(-0.9,4.1);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#EEE54D").s().p("AisCtQhHhHAAhmQAAhlBHhHQBHhHBlAAQBmAABHBHQBHBHAABlQAABmhHBHQhHBHhmAAQhlAAhHhHg");
	this.shape_202.setTransform(-0.9,4.1);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#EEE54D").s().p("AjNDOQhVhVAAh5QAAh4BVhVQBVhVB4AAQB6AABUBVQBVBVAAB4QAAB5hVBVQhUBVh6AAQh4AAhVhVg");
	this.shape_203.setTransform(-0.9,4.1);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#EEE54D").s().p("AjxDyQhkhjAAiPQAAiOBkhjQBkhkCNAAQCPAABjBkQBkBjAACOQAACPhkBjQhjBkiPAAQiNAAhkhkg");
	this.shape_204.setTransform(-0.9,4.1);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#EEE54D").s().p("AkZEaQh1h0AAimQAAilB1h0QB0h1ClAAQCnAABzB1QB1B0AAClQAACmh1B0QhzB1inAAQilAAh0h1g");
	this.shape_205.setTransform(-0.9,4.1);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#EEE54D").s().p("AlFFGQiGiGAAjAQAAi/CGiGQCHiGC+AAQDAAACGCGQCGCGAAC/QAADAiGCGQiGCGjAAAQi+AAiHiGg");
	this.shape_206.setTransform(-0.9,4.1);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#EEE54D").s().p("Al0F1QiaiZAAjcQAAjaCaiaQCZiaDbAAQDcAACZCaQCaCaAADaQAADciaCZQiZCajcAAQjbAAiZiag");
	this.shape_207.setTransform(-0.8,4.1);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#EEE54D").s().p("AmnGoQiuivAAj5QAAj4CuivQCviuD4AAQD5AACuCuQCwCvAAD4QAAD5iwCvQiuCvj5AAQj4AAivivg");
	this.shape_208.setTransform(-0.8,4.1);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#EEE54D").s().p("AndHeQjFjFAAkZQAAkYDFjFQDFjFEYAAQEZAADFDFQDFDFAAEYQAAEZjFDFQjFDFkZAAQkYAAjFjFg");
	this.shape_209.setTransform(-0.8,4.1);

	var maskedShapeInstanceList = [this.shape_195,this.shape_196,this.shape_197,this.shape_198,this.shape_199,this.shape_200,this.shape_201,this.shape_202,this.shape_203,this.shape_204,this.shape_205,this.shape_206,this.shape_207,this.shape_208,this.shape_209];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_195}]}).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).wait(27));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.8,-1.8,12,12);


(lib.p4m进 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.m跑3();
	this.instance.parent = this;
	this.instance.setTransform(-49,-72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4m进, new cjs.Rectangle(-49,-72,98,144), null);


(lib.p4h进 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.人手1();
	this.instance.parent = this;
	this.instance.setTransform(23.9,17.8,1,1,-168.8);

	this.instance_1 = new lib.人身();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-57.3,-24.1,1,1,-41.9);

	this.instance_2 = new lib.人手2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-6.3,1.4,1,1,-66.7);

	this.instance_3 = new lib.人腿1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(18.7,58.2,1,1,-116.6);

	this.instance_4 = new lib.人腿2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.6,9,1,1,-7.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4h进, new cjs.Rectangle(-57.3,-58.2,114.6,116.4), null);


(lib.p2房3旗 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2房3旗子();
	this.instance.parent = this;
	this.instance.setTransform(-82,-85.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2房3旗, new cjs.Rectangle(-82,-85.5,164,171), null);


(lib.p2房2球 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2房2();
	this.instance.parent = this;
	this.instance.setTransform(-84,-183);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2房2球, new cjs.Rectangle(-84,-183,168,183), null);


(lib.p2房1问 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2问号();
	this.instance.parent = this;
	this.instance.setTransform(-53.5,-55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2房1问, new cjs.Rectangle(-53.5,-55,107,110), null);


(lib.p1飞船_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1飞船();
	this.instance.parent = this;
	this.instance.setTransform(-41.5,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1飞船_1, new cjs.Rectangle(-41.5,-23.5,83,47), null);


(lib.p1房子_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1房子();
	this.instance.parent = this;
	this.instance.setTransform(-46.5,-137);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1房子_1, new cjs.Rectangle(-46.5,-137,93,274), null);


(lib.p1m嘴_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1m嘴();
	this.instance.parent = this;
	this.instance.setTransform(-63.5,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1m嘴_1, new cjs.Rectangle(-63.5,-28,127,56), null);


(lib.p1m呆毛_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1m呆毛();
	this.instance.parent = this;
	this.instance.setTransform(-40,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1m呆毛_1, new cjs.Rectangle(-40,-103,80,103), null);


(lib.p1bt圆 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhwBxQgvgvAAhCQAAhBAvgvQAugvBCAAQBCAAAvAvQAvAvAABBQAABCgvAvQgvAvhCAAQhCAAgugvg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1bt圆, new cjs.Rectangle(-16,-16,32,32), null);


(lib._2飞碟_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2飞碟();
	this.instance.parent = this;
	this.instance.setTransform(-28,-25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2飞碟_1, new cjs.Rectangle(-28,-25.5,56,51), null);


(lib._2背景_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2背景();
	this.instance.parent = this;
	this.instance.setTransform(-320,-514.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2背景_1, new cjs.Rectangle(-320,-514.5,640,1029), null);


(lib._2灯晕 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFDE00","rgba(255,255,0,0)"],[0,1],0,0,0,0,0,25.2).s().p("AiwCwQhJhIAAhoQAAhnBJhJQBJhJBnAAQBoAABIBJQBKBJAABnQAABohKBIQhIBKhoAAQhnAAhJhKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._2灯晕, new cjs.Rectangle(-25,-25,50,50), null);


(lib._2梯子_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2梯子();
	this.instance.parent = this;
	this.instance.setTransform(-26,-34.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2梯子_1, new cjs.Rectangle(-26,-34.5,52,69), null);


(lib._2旗子 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#121513").ss(0.8,1,1).p("ABuhNIAFCbIjlgtg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5BF31").s().p("AhyAhIDghuIAFCbg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib._2旗子, new cjs.Rectangle(-12.5,-8.8,25.1,17.7), null);


(lib._2房子2动 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2房子2();
	this.instance.parent = this;
	this.instance.setTransform(-71,-73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2房子2动, new cjs.Rectangle(-71,-73.5,142,147), null);


(lib._2房子1动 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2房子1();
	this.instance.parent = this;
	this.instance.setTransform(-35,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._2房子1动, new cjs.Rectangle(-35,-60,70,120), null);


(lib._2彩灯闪 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFDE00","rgba(255,255,0,0)"],[0,1],0,0,0,0,0,10.1).s().p("AhGBHQgegdAAgqQAAgpAegdQAdgeApAAQAqAAAdAeQAeAdAAApQAAAqgeAdQgdAegqAAQgpAAgdgeg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._2彩灯闪, new cjs.Rectangle(-10,-10,20.1,20.1), null);


(lib.m转 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_6 = function() {
		//this.parent.gotoAndStop(2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(6).call(this.frame_6).wait(1));

	// Layer 2
	this.instance = new lib.m转1();
	this.instance.parent = this;
	this.instance.setTransform(-49,-144);

	this.instance_1 = new lib.m转2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-49,-144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{skewY:0,x:-49}}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance,p:{skewY:180,x:49}}]},3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49,-144,98,144);


(lib.m跑 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.m跑4();
	this.instance.parent = this;
	this.instance.setTransform(-49,-149);

	this.instance_1 = new lib.m跑3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-49,-144);

	this.instance_2 = new lib.m跑2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-49,-149);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},10).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},1).wait(2));

	// Layer 1
	this.instance_3 = new lib.m跑1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-49,-159);

	this.instance_4 = new lib.m跑2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-49,-149);

	this.instance_5 = new lib.m跑3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-49,-144);

	this.instance_6 = new lib.m跑4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-49,-149);

	this.instance_7 = new lib.m跑5();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-49,-154);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},3).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},2).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49,-159,98,144);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgeBsQgagQAAgkIAAgSIA9AAIAAAXQAAAJAGAGQAGAGALgBQATAAADgPQADgJgDgIQgEgKgQgKIgggTQgtgYgGgZQgDgPADgRQAEgaAXgNQAUgMAgAAQAgAAATALQAbAOAAAhIAAAQIg6AAIAAgOQAAgKgGgFQgFgGgKAAQgSAAgDAQQgBADABAJQACAIAPAKIAhASQAwAZAFAbQAEAPgDAXQgEAagYAOQgUAMgiAAQgjAAgVgPgAsQBsQgZgQAAgkIAAgSIA9AAIAAAXQAAAJAGAGQAHAGAKgBQATAAADgPQADgJgDgIQgEgKgPgKIghgTQgugYgFgZQgDgRACgPQAFgaAWgNQAVgMAhAAQAgAAATALQAaAOAAAhIAAAQIg5AAIAAgOQAAgKgGgFQgGgGgJAAQgTAAgCAQQgCADACAJQACAIAPAKIAhASQAvAZAGAbQADAQgDAWQgEAagXAOQgUAMgiAAQgkAAgWgPgACjBAIAAgOIAAimIA6AAIAACrIABAIQABAHAEAEQAGAGALAAQALAAAGgGQAEgEABgHIABgIIAAirIA6AAIAAC0QgGA6hLAAQhLAAgGg6gAKhBrQgYgPgDgeIgBgPIAAhgIABgQQAEgeAYgOQAUgNAiAAQAiAAAUANQAYAOADAeIABAQIAAAHIg7AAIAAgNIgBgJQgBgFgEgFQgGgGgMAAQgLAAgGAGQgFAFAAAFQgCAEAAAHIAABpIABAJQABAGAFAEQAGAHAMAAQALAAAGgHQAFgEABgGIABgJIAAghIgYAAIAAghIBSAAIAAA9IgBAPQgCAcgWAPQgIAGgKADIgIACQgOADgRAAQgiAAgVgMgAirBzIgBjWIgoDWIg7AAIgojWIgBDWIg6AAIAFjnIBeAAIAeC0IAdi0IBeAAIAFDngAnfBzIgfjWIghDWIg+AAIArjnIBnAAIAqDngAH2BxIg7jAIAEDAIg5AAIAAjlIBWAAIA2C6IgDi6IA6AAIAADlg");
	this.shape.setTransform(81,12.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,162.1,24.6), null);


(lib.l地 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.L地();
	this.instance.parent = this;
	this.instance.setTransform(-138,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.l地, new cjs.Rectangle(-138,-5.5,276,11), null);


(lib.l8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLAMIAAgXIAXAAIAAAXg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l8, new cjs.Rectangle(-1.2,-1.1,2.4,2.3), null);


(lib.l7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAABEQgNAAgLgEQgLgEgJgHIAAgQQAJAJAKAEQAKAFAKAAQAQAAAIgHQAIgIgBgOIgWAAQgZAAgNgLQgNgMAAgVQAAgZANgMQAOgMAYgBIAsAAIAABaQABAYgNALQgLAMgXAAIgCgBgAgQgsQgJAJAAARQAAAQAJAHQAJAIAQAAIARAAIAAhCIgRAAQgQAAgJAJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l7, new cjs.Rectangle(-4.8,-6.8,9.6,13.7), null);


(lib.l6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAXAxIAAg5QAAgNgGgGQgGgGgLAAIgVAAIAABSIgWAAIAAhhIAwAAQAUAAAKAJQAKAJgBATIAAA8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l6, new cjs.Rectangle(-4.4,-4.9,8.9,9.8), null);


(lib.l5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKBEIAAhfIAVAAIAABfgAgKgvIAAgUIAVAAIAAAUg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l5, new cjs.Rectangle(-1.1,-6.7,2.2,13.5), null);


(lib.l4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAFBJQgMAAgJgDQgKgDgHgGQgGgGgDgKQgEgJAAgNQAAgYANgMQANgNAYAAIAVAAIAAguIAWAAIAACRgAgPgDQgIAJAAASQAAAkAgAAIAQAAIAAhIIgQAAQgPAAgJAJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l4, new cjs.Rectangle(-4.6,-7.2,9.4,14.6), null);


(lib.l3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgBAyQgTAAgLgHQgKgIAAgOQAAgRALgIQALgIAWAAIAYAAQAAgNgFgGQgHgGgMABQgVgBgGAUIgRAAQADgRALgIQAMgIASABQAUAAAKAIQAJAJAAARIAABBgAgZAUQgBAIAHAFQAGAEANAAIAbAAIAAgkIgZAAQgbAAAAATg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(-4.2,-5,8.5,10.1), null);


(lib.l2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjAlQgMgNgCgXQABgYANgMQANgNAXgBQAuACACAvQAAAZgNAMQgNANgXAAQgXgBgMgMgAgUgaQgGAKgBARQABARAHAJQAHAJAMABQANAAAHgJQAGgJABgSQgBgRgGgJQgHgKgNAAQgMAAgIAJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l2, new cjs.Rectangle(-4.9,-5,9.9,10.1), null);


(lib.l1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AguBEIAAiHIAWAAIAAB6IBHAAIAAANg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.l1, new cjs.Rectangle(-4.7,-6.7,9.4,13.5), null);


(lib.h转 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_7 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7).call(this.frame_7).wait(1));

	// 人转身.png
	this.instance = new lib.人转身();
	this.instance.parent = this;
	this.instance.setTransform(-24.2,-120.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({y:-115.2},0).wait(2).to({skewY:180,x:29.3},0).wait(2).to({y:-120.2},0).wait(2));

	// 人转腿2.png
	this.instance_1 = new lib.人转腿2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(39.7,-42.5,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({skewX:35.7,skewY:215.7,x:40,y:-17.7},0).wait(2).to({rotation:-35.7,skewX:0,skewY:360,x:-33.6},0).wait(2).to({rotation:0,x:-34.7,y:-41.5},0).wait(2));

	// 人转腿1.png
	this.instance_2 = new lib.人转腿1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(5.5,-43.5,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({skewX:-21,skewY:159,x:1.8,y:-39.7},0).wait(2).to({rotation:21,skewX:0,skewY:0,x:4.6},0).wait(2).to({rotation:0,x:1,y:-43.7},0).wait(2));

	// 人转手2.png
	this.instance_3 = new lib.人转手2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(36.7,-77.2,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({skewX:17.5,skewY:197.5,x:38.2,y:-64.8},0).wait(2).to({rotation:-17.5,skewX:0,skewY:360,x:-31.8},0).wait(2).to({rotation:0,x:-31.5,y:-76.7},0).wait(2));

	// 人转手1.png
	this.instance_4 = new lib.人转手1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(2.7,-72.5,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({skewX:-21.2,skewY:158.8,x:1.8,y:-70.9},0).wait(2).to({rotation:21.2,skewX:0,skewY:0,x:4.6},0).wait(2).to({rotation:0,x:1,y:-73.2},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-120.2,70.3,106.8);


(lib.h跑 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 人手1.png
	this.instance = new lib.人手1();
	this.instance.parent = this;
	this.instance.setTransform(-36,-78.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({rotation:-26.2,x:-34.7,y:-58.7},0).wait(2).to({rotation:-78.7,x:-16.5,y:-35.8},0).wait(1).to({rotation:-113.7,x:4.1,y:-32.7},0).wait(2).to({rotation:-160.7,x:27.9,y:-53.4},0).wait(2).to({rotation:-113.7,x:4.1,y:-32.7},0).wait(2).to({rotation:-78.7,x:-16.5,y:-35.8},0).wait(1).to({rotation:-26.2,x:-34.7,y:-58.7},0).wait(2));

	// 人身.png
	this.instance_1 = new lib.人身();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-23,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({y:-120},0).wait(2).to({y:-117.5},0).wait(1).to({y:-120},0).wait(2).to({y:-127.5},0).wait(2).to({y:-120},0).wait(2).to({y:-117.5},0).wait(1).to({y:-120},0).wait(2));

	// 人手2.png
	this.instance_2 = new lib.人手2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-76.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({rotation:25.4,x:2.8,y:-74.5},0).wait(2).to({rotation:54.7,x:7.4,y:-72.7},0).wait(1).to({rotation:119.9,x:11.3,y:-70.7},0).wait(2).to({rotation:152.1,x:5.8,y:-70.5},0).wait(2).to({rotation:119.9,x:11.3,y:-70.7},0).wait(2).to({rotation:54.7,x:7.4,y:-72.7},0).wait(1).to({rotation:25.4,x:2.8,y:-74.5},0).wait(2));

	// 人腿1.png
	this.instance_3 = new lib.人腿1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-40,-51.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(3).to({rotation:-29.2,x:-40.7,y:-29.5},0).wait(2).to({rotation:-54.9,x:-33.1,y:-13.6},0).wait(1).to({rotation:-35.9,x:-36.7,y:-25.7},0).wait(2).to({rotation:0,x:-37.5,y:-54.2},0).wait(2).to({rotation:-35.9,x:-36.7,y:-25.7},0).wait(2).to({rotation:-54.9,x:-33.1,y:-13.6},0).wait(1).to({rotation:-29.2,x:-40.7,y:-29.5},0).wait(2));

	// 人腿2.png
	this.instance_4 = new lib.人腿2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-4,-48.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(3).to({rotation:23.5,x:2.4,y:-46.2},0).wait(2).to({rotation:69,x:13,y:-47.9},0).wait(1).to({rotation:33.4,x:3,y:-46.6},0).wait(2).to({rotation:2.3,x:-3.9,y:-52.8},0).wait(2).to({rotation:33.4,x:3,y:-46.6},0).wait(2).to({rotation:67.9,x:12.8,y:-48},0).wait(1).to({rotation:23.5,x:2.4,y:-46.2},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-125,79,108.3);


(lib.h头像框星_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.h头像框星();
	this.instance.parent = this;
	this.instance.setTransform(-12.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.h头像框星_1, new cjs.Rectangle(-12.5,-13.5,25,27), null);


(lib.h头像框尴尬 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhIBzQgGg6gDgFIgtgDQgNgDgFgGQgCgEAAgIQAAgNATgEQASgFAXAIQA8AVAABHIAAAeQgEAXgQAAQgUAAgGgsgAAXB9QgCgIACgIQAAgHACgLQAFgTAKgOQAfgrBIATQAKADAGAHQAEAGAAAEQAAAKgJAEQgTAKg3gBQgCACgLAlQgIAXgQAAQgRAAgDgOgAASg6QgKgTAAgkQAAgjAMgCQANgDAPAvQAEAcAzASQAyARAAANQAAAUgcAAQhRAAgagwgAifgZQgDgFABgGQAAgHAPgEIAggHQAwgOAAgyQAAg5AUAXQAUAYAAAZQAAAngIANQgUAkhLAAQgXAAgHgKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.h头像框尴尬, new cjs.Rectangle(-16.2,-15.9,32.5,31.9), null);


(lib.答题金币 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(21).call(this.frame_21).wait(1));

	// 答题固定金币
	this.instance = new lib.答题固定金币();
	this.instance.parent = this;
	this.instance.setTransform(150.7,-45.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({scaleX:1.55,scaleY:1.55},4).to({scaleX:1,scaleY:1},4).wait(1));

	// 答题金币2
	this.instance_1 = new lib.答题金币2_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-244.7,223.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.79,scaleY:0.79,rotation:360,guide:{path:[-244.6,223.5,-217.7,-124.9,152.1,-47.1]}},17,cjs.Ease.get(-0.2)).wait(5));

	// 答题金币2
	this.instance_2 = new lib.答题金币2_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-244.7,223.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.9,scaleY:0.9,rotation:477.3,guide:{path:[-244.6,223.5,-244,130.8,-186.3,70.2]}},8,cjs.Ease.get(-0.5)).to({scaleX:0.79,scaleY:0.79,rotation:1080,guide:{path:[-186.3,70,-92.6,-28.7,151.7,-43.1]}},9).wait(5));

	// 答题金币1
	this.instance_3 = new lib.答题金币1_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-244.7,224.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:0.9,scaleY:0.9,rotation:522,guide:{path:[-244.6,224.5,-185.9,102.3,-117.6,32.9]}},8).to({scaleX:0.63,scaleY:0.63,rotation:1080,guide:{path:[-117.5,32.7,2.1,-88.6,151.5,-48.2]}},9).wait(5));

	// 答题金币2
	this.instance_4 = new lib.答题金币2_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-244.3,223.7,0.4,0.4,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:0.79,scaleY:0.79,rotation:1800,guide:{path:[-244.2,223.7,-82.6,-112.3,152.5,-48]}},17,cjs.Ease.get(-0.5)).wait(5));

	// 答题金币2
	this.instance_5 = new lib.答题金币2_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-244.7,223.5,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:0.5,scaleY:0.5,rotation:1440,guide:{path:[-244.6,223.5,-206.3,9.3,152.1,-41.9]}},17,cjs.Ease.get(-1)).wait(5));

	// 答题金币1
	this.instance_6 = new lib.答题金币1_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-244.7,224.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({rotation:1800,guide:{path:[-244.6,223.5,-206.4,9.7,151.2,-41.8]}},17,cjs.Ease.get(0.4)).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-261.7,208.5,34,32);


(lib.答题背景动 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.item4 = new lib.Symbol3();
	this.item4.parent = this;
	this.item4.setTransform(127.3,21.5,1,1,0,0,0,89.6,13.8);
	this.item4.alpha = 0.051;

	this.item2 = new lib.Symbol3();
	this.item2.parent = this;
	this.item2.setTransform(127.3,-29.5,1,1,0,0,0,89.6,13.8);
	this.item2.alpha = 0.051;

	this.item3 = new lib.Symbol3();
	this.item3.parent = this;
	this.item3.setTransform(-65.7,21.5,1,1,0,0,0,89.6,13.8);
	this.item3.alpha = 0.051;

	this.item1 = new lib.Symbol3();
	this.item1.parent = this;
	this.item1.setTransform(-65.7,-29.5,1,1,0,0,0,89.6,13.8);
	this.item1.alpha = 0.051;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.item1},{t:this.item3},{t:this.item2},{t:this.item4}]}).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#42281B").ss(1,1,1).p("AFMnQQhNAVAEABQAEABhfAqQheAqAEABQAEAAg8ArQg7AqAEABQAEAAhWBFQhWBEAEABQAFAAg9BSQg8BQAEAAQAFABgnBRQgnBSAEAAQAFABgWBaQgVBZAEABQGuA7AIABIGEA0IgJvNQgEADhFATg");
	this.shape.setTransform(202.5,89.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// 图层 1
	this.delLineMc4 = new lib.Symbol5();
	this.delLineMc4.parent = this;
	this.delLineMc4.setTransform(101.7,23,1,1,0,0,0,70,6);

	this.delLineMc3 = new lib.Symbol5();
	this.delLineMc3.parent = this;
	this.delLineMc3.setTransform(-83.1,23,1,1,0,0,0,70,6);

	this.delLineMc2 = new lib.Symbol5();
	this.delLineMc2.parent = this;
	this.delLineMc2.setTransform(101.7,-27.1,1,1,0,0,0,70,6);

	this.delLineMc1 = new lib.Symbol5();
	this.delLineMc1.parent = this;
	this.delLineMc1.setTransform(-83.1,-27.1,1,1,0,0,0,70,6);

	this.questionText = new cjs.Text("问题文字", "18px 'Microsoft YaHei'");
	this.questionText.name = "questionText";
	this.questionText.textAlign = "center";
	this.questionText.lineHeight = 26;
	this.questionText.lineWidth = 389;
	this.questionText.parent = this;
	this.questionText.setTransform(-0.5,-92.1);

	this.titleText = new cjs.Text("春季有奖问答", "20px 'Microsoft YaHei'");
	this.titleText.name = "titleText";
	this.titleText.textAlign = "center";
	this.titleText.lineHeight = 28;
	this.titleText.lineWidth = 346;
	this.titleText.parent = this;
	this.titleText.setTransform(-0.5,-129.9);

	this.questionText4 = new cjs.Text("选项D", "16px 'Microsoft YaHei'");
	this.questionText4.name = "questionText4";
	this.questionText4.lineHeight = 23;
	this.questionText4.lineWidth = 145;
	this.questionText4.parent = this;
	this.questionText4.setTransform(74.1,12.5);

	this.questionText3 = new cjs.Text("选项C", "16px 'Microsoft YaHei'");
	this.questionText3.name = "questionText3";
	this.questionText3.lineHeight = 23;
	this.questionText3.lineWidth = 139;
	this.questionText3.parent = this;
	this.questionText3.setTransform(-117,12.5);

	this.questionText2 = new cjs.Text("选项B", "16px 'Microsoft YaHei'");
	this.questionText2.name = "questionText2";
	this.questionText2.lineHeight = 23;
	this.questionText2.lineWidth = 146;
	this.questionText2.parent = this;
	this.questionText2.setTransform(74.1,-38.9);

	this.questionText1 = new cjs.Text("选项A", "16px 'Microsoft YaHei'");
	this.questionText1.name = "questionText1";
	this.questionText1.lineHeight = 23;
	this.questionText1.lineWidth = 138;
	this.questionText1.parent = this;
	this.questionText1.setTransform(-117,-38.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#42281B").ss(1,1,1).p("ACvHVQAFABgFnWQgDnHADgNQgHAEioAvQi1AzAEAA");
	this.shape_1.setTransform(227.2,88.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.questionText1},{t:this.questionText2},{t:this.questionText3},{t:this.questionText4},{t:this.titleText},{t:this.questionText},{t:this.delLineMc1},{t:this.delLineMc2},{t:this.delLineMc3},{t:this.delLineMc4}]}).wait(1));

	// Layer 5
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag+AyQALgFAIgGQAHgGAEgGQAHgLAAgWIAAgFIgjAAIAAgJIB5AAIAAAJIgnAAIAAAxQAAAHAHAAIALAAQAJAAABgIIACgSIALADIgDASQgCAOgQAAIgQAAQgPAAAAgPIAAgyIgZAAIAAAEQAAAagIANQgJAOgYAMgAgwgwIAAgJIBhAAIAAAJg");
	this.shape_2.setTransform(100.4,92.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbAuIAAgMQAKAGALAAQAJAAAGgGQAGgGABgJQgBgKgGgEQgGgFgLAAIgQAAIAAgxIAwAAIAAALIgkAAIAAAcIAIAAQAPgBAIAJQAJAGAAAOQAAAPgJAJQgKAIgPAAQgOAAgHgEg");
	this.shape_3.setTransform(90.2,91.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQAEAAACACQACADAAACQAAADgCACQgCADgEAAQgDAAgCgDg");
	this.shape_4.setTransform(84.7,96.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgXAmQgIgMAAgYQAAgZAIgNQAJgOAPAAQAfAAAAAyQAAAZgIANQgJANgPAAQgPAAgIgNgAgTABQAAAoATAAQAUAAAAgoQAAgogUAAQgTAAAAAog");
	this.shape_5.setTransform(79.4,91.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgqA+IAAhJQgHAMgIAJIgEgLQASgYALgkIALAEIgLAaIAABdgAAHA8IgCgLIASABQAGAAACgDQACgCAAgIIAAg8Ig5AAIAAgJIA5AAIAAgcIALAAIAAAcIASAAIAAAJIgSAAIAAA/QAAAUgSABgAgQgDIAJgFIARAcIgJAGQgIgRgJgMg");
	this.shape_6.setTransform(68.9,92.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag9A1QAigIAUgLQgTgPgKgZIgNAAIAAgKIAtAAIAAgTIg5AAIAAgJIA5AAIAAgSIAKAAIAAASIA3AAIAAAJIg3AAIAAATIAjAAIAAAJQgLAYgUARQAUALAhAFIgIALQgkgHgTgNQgUANgkAJIgFgKgAABAdQATgPAJgUIg2AAQAJAVARAOg");
	this.shape_7.setTransform(56.1,92.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag6AzQAfgDATgHIgggMIAKgNIggAAIAAgIIAmAAIAHgLIAKADIgGAIIBMAAIAAAIIgdAAQgIANgMAJIApAMIgGAKIgtgQQgWAMgjAFgAgZAZIAbAJQANgHAGgLIgnAAgAArAAIAAgEIhVAAIAAAEIgKAAIAAglIAhAAIAAgOIgnAAIAAgJIB0AAIAAAJIgmAAIAAAOIAhAAIAAAlgAAUgMIAXAAIAAgQIgXAAgAgKgMIAVAAIAAgQIgVAAgAgqgMIAXAAIAAgQIgXAAgAgKglIAVAAIAAgOIgVAAg");
	this.shape_8.setTransform(43.1,92.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgxA7IAAgpIApAAIACgKIg4AAIAAgIIB8AAIAAAIIg7AAIgDAKIAzAAIAAAcQAAANgMAAIgOAAIgCgKIANABQAFAAABgGIAAgSIgWAAIAAAeIgJAAIAAgeIgVAAIAAAeIgJAAIAAgeIgVAAIAAAhgAgDgFIAAgeIgtAAIAAAQIgJAAIAAgYIA2AAIAAgHIgwAAIAAgIIBmAAIAAAIIguAAIAAAHIA1AAIAAAYIgJAAIAAgQIgsAAIAAAegAALgHIAAgGIAeAAIAAAGgAgogHIAAgGIAdAAIAAAGgAALgVIAAgHIAeAAIAAAHgAgogVIAAgHIAdAAIAAAHg");
	this.shape_9.setTransform(30.1,92.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgtA+IAAhGQgHAKgGAHIgEgKQATgbAKghIALAEQgHARgHAPIAABXgAgaA1IAAgIIBZAAIAAAIgAArAhIAAgJIgwAAIAAAJIgKAAIAAhWIBEAAIAABWgAgFAPIAwAAIAAgZIgwAAgAgFgSIAwAAIAAgaIgwAAg");
	this.shape_10.setTransform(17.1,92.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgEA/IAAgcQgTANggALIgHgIQAggIAUgMIgxAAIAAgJIA3AAIAAgKIAIAAIAAAKIA5AAIAAAJIgyAAQAUANAgAGIgHAJQgigKgSgOIAAAcgAg4AJQAfgEARgEIgfgHIAKgLIgeAAIAAgJIAlAAIAJgMIAKADIgHAJIBGAAIAAAJIgcAAQgGAKgKAHIAiAIIgEAJIgpgMQgSAHgnAFgAgYgKIAcAHQALgFAHgJIgoAAgAAugeIAAgLIhcAAIAAALIgKAAIAAgTIA1AAIgFgJIAIgEIAIANIAwAAIAAATg");
	this.shape_11.setTransform(4.1,92.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAfA/IAAgIIg8AAIAAAIIgKAAIAAgrIBQAAIAAArgAgdAuIA8AAIAAgRIg8AAgAg/AHQApgOASgWIAJAAQAUAYAnAJIgGAKQgPgFgNgHIAAAIIg7AAIAAgIQgNAIgPAGgAAdABQgRgIgMgNQgLAMgQAJIA4AAIAAAAgAg+gYQAQgQAJgWIALAAIgGANIAkAAIAAAJIgoAAQgJANgKAKgAAZgiIAHgFIAMAQIgIAGIgLgRgAgigiIAIgFIALAPIgIAFIgLgPgAABghQALgNAFgQIAKAAIgEANIAnAAIAAAJIgsAAIgJAOg");
	this.shape_12.setTransform(-8.9,92.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAQAaQgJAXggAMIgGgIQAfgKAHgVIgjAAIAAgIIAmAAIABgOIgiAAIAAgJIBRAAIAAAJIgmAAIAAAOIAqAAIAAAIIgnAAQALAXAdAGIgHAKQgdgJgLgagAg0AvQAFgDAAgIIAAguIgQAAIAAgKIAaAAIAAA6IAOgKIABALQgQAKgIAHgAAqgQIAAgGIgyAAIAAAGIgKAAIAAgqIBGAAIAAAqgAgIgeIAyAAIAAgTIgyAAgAg3g1IAIgHIASAUIgJAHIgRgUg");
	this.shape_13.setTransform(-21.9,92.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAsA+IAAgGIgtAAIAAAGIgJAAIAAg8IBAAAIAAA8gAgBAvIAtAAIAAgOIgtAAgAgBAYIAtAAIAAgOIgtAAgAgxA1QAEgEAAgIIAAgbIgQAAIAAgJIAQAAIAAgPIgFAAIAAgJIAbAAIAAAJIgMAAIAAAPIAPAAIAAAJIgPAAIAAAcIAOgNIACAJIgTASIgDAFgAg+gSQALgSAFgaIAKADIgFARIAVAAIAAAJIgYAAQgGANgHAMgAgTgJIAAgIIATAAIAAgRIgPAAIAAgIIAPAAIAAgTIAJAAIAAATIAWAAIAAgTIAKAAIAAATIASAAIAAAIIgSAAIAAARIAWAAIAAAIgAAJgRIAWAAIAAgRIgWAAg");
	this.shape_14.setTransform(-35,92.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgFA9IAAhOIAKAAIAABOgAg+gGQAogVASghIAMAAIgCADQAVAhAlAPIgIAKQgkgSgUgeQgRAdgnAVg");
	this.shape_15.setTransform(-47.9,92.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag1A6IAAhZIAgAAIAAgRIgoAAIAAgJIB6AAIAAAJIgmAAIAAARIAfAAIAABKQAAAPgOAAIgUAAIgCgKIASABQAJAAgBgIIAAg/IgVAAIgEAWQAOANAKALIgHAHIgTgWQgGARgNAOIgIgHQAXgVAAgiIgZAAQgBAOgBAFIAQAOIgFAIIgOgOQgGARgNAOIgIgHQAWgTABggIgXAAIAAAzIAAAdgAgMgfIAaAAIAAgRIgaAAgAgsAdgAgsAdIAAgzIAXAAQgBAggWATg");
	this.shape_16.setTransform(-60.9,92.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AANA+IAAgWIgmAAIAAgJIAmAAIAAgOIgUAAIAAAFIgJAAIAAg0IAbAAIAAggIAKAAIAAANIAoAAIAAAIIgoAAIAAALIAhAAIAAA0IgJAAIAAgFIgWAAIAAAOIAoAAIAAAJIgoAAIAAAWgAgHAJIA0AAIAAgMIg0AAgAgHgKIA0AAIAAgMIg0AAgAg8A8IgBgKIAKABQAGAAAAgHIAAggIgQAEIgBgLIARgDIAAgfIgQAAIAAgIIAQAAIAAgZIAKAAIAAAZIAOAAIAAAIIgOAAIAAAdIAOgDIAAAIIgOAEIAAAmQAAANgNAAg");
	this.shape_17.setTransform(-73.9,92.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAmA0IhJAEIgKADIgGgLQAGgCAEgFQAOgOANgUIgvAAIAAgJIA4AAIAAgcIguAAIAAgKIAuAAIAAgWIAKAAIAAAWIAvAAIAAAKIgvAAIAAAcIA5AAIAAAJIg+AAQgOAUgRATIA/gCIgSgXIAIgGQARAVAQAVIgJAGg");
	this.shape_18.setTransform(-86.9,92.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgIA1QAHgGAFgHIg9AJIgBgKIAKgBIAAhbIAtAAIAABVIAIgBIgBAIQAHgJACgMQAEgNAAgfIgPAAIAAgJIAPAAIAAgaIAKAAIAAAaIAhAAIgDBKQgBAUgQAAIgRAAIgDgMIASACQAJAAAAgLIADhAIgXAAQgBAggDAPQgGAYgSARIgHgJgAgmAlIAZgEIAAgUIgZAAgAgmAFIAZAAIAAgVIgZAAgAgmgYIAZAAIAAgVIgZAAg");
	this.shape_19.setTransform(96.9,73.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgcA+IgBgLIAQABQAJAAAAgKIAAgYIg0AcIgGgLQAbgMAfgQIAAgjIg4AAIAAgKIA4AAIAAgXIAKAAIAAAXIA3AAIAAAKIg3AAIAAAHQAFAOAJALQAOgKALgOIAJAHIgcAZQAPARAWALIgIAKQghgTgQgfIAAAtQgBARgPAAgAgxgPIAHgGQALAKALALIgJAIQgJgLgLgMgAARg2IAGgHQAMAIAIAGIgIAIIgSgPg");
	this.shape_20.setTransform(84.3,73);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgXA2QAfgPALgTQALgTAAglIAAgXIALAAIAAAXQAAAjgJAUIAdAgIgJAIIgZgfQgPAWgdANgAg8ArQAGgFgBgIIAAhXIALAAIAABaIAkgWIABAMIgmAYIgIAGgAgWg5IAJgFIARAhIgIAFIgSghg");
	this.shape_21.setTransform(71.5,73);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AACA4IgCgLIAVABQAKAAAAgKIAAhSIhdAAIAAgJIB9AAIAAAJIgVAAIAABVQAAARgRAAgAgwAfIAAg6IA3AAIAAAxIgtAAIAAAJgAgmANIAkAAIAAgfIgkAAg");
	this.shape_22.setTransform(58.3,73.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgJARIAIghIALAAIgKAhg");
	this.shape_23.setTransform(44.9,77.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("Ag+AyQALgFAIgGQAHgGADgGQAIgLAAgWIAAgFIgjAAIAAgJIB6AAIAAAJIgpAAIAAAxQAAAHAIAAIALAAQAJAAABgIIACgSIALADIgCASQgDAOgQAAIgPAAQgQAAgBgPIAAgyIgYAAIAAAEQAAAagJANQgIAOgXAMgAgwgwIAAgJIBhAAIAAAJg");
	this.shape_24.setTransform(32.3,73.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgbAyIAAgKIAWAAIAAhKIgXAGIAAgLIAigKIAABZIAXAAIAAAKg");
	this.shape_25.setTransform(22.2,72.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgsA3QAQgVAAgjIAAgoIAyAAIAAgTIAJAAIABATIAeAAIAAAJIgeAAQAAAfADARQAJgQAGgUIAJAEQgJAZgMAUQAEALAEAHQAEAEABgGIADgTIAJAEIgEAVQgDAKgGAAQgFABgFgHQgFgHgDgJQgJANgLAJIgJgFIAOgOIALgOQgFgVAAgnIgqAAIAAAgQAAAmgSAYIgHgHgAg+AtQAIgVAIgeIAJADIgPAzgAgLArIAAgsIAcAAIAAAkIgTAAIAAAIgAgCAcIALAAIAAgXIgLAAgAgNgNIAAgIIAeAAIAAAIgAg8guIAIgFIASAWIgJAGIgRgXgAAlg4IAGgFIAMAMIgHAHg");
	this.shape_26.setTransform(11.7,73);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAsA/IAAgHIgsAAIAAAHIgKAAIAAg9IBAAAIAAA9gAAAAvIAsAAIAAgPIgsAAgAAAAYIAsAAIAAgOIgsAAgAgxA1QAEgEAAgIIAAgcIgQAAIAAgIIAQAAIAAgPIgGAAIAAgJIAbAAIAAAJIgLAAIAAAPIAPAAIAAAIIgPAAIAAAdIAOgNIACAJIgTASIgEAFgAg+gSQALgRAGgaIAJACIgFARIAWAAIAAAJIgZAAQgFANgIAMgAgSgIIAAgJIASAAIAAgRIgPAAIAAgIIAPAAIAAgTIAJAAIAAATIAWAAIAAgTIALAAIAAATIASAAIAAAIIgSAAIAAARIAVAAIAAAJgAAJgRIAWAAIAAgRIgWAAg");
	this.shape_27.setTransform(-1.4,73);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAfA/IAAgIIg8AAIAAAIIgKAAIAAgrIBQAAIAAArgAgdAuIA8AAIAAgRIg8AAgAg/AHQApgOASgWIAJAAQAUAYAnAJIgGAKQgPgFgNgHIAAAIIg7AAIAAgIQgNAIgPAGgAAdABQgRgIgMgNQgLAMgQAJIA4AAIAAAAgAg+gYQAQgQAJgWIALAAIgGANIAkAAIAAAJIgoAAQgJANgKAKgAAZgiIAHgFIAMAQIgIAGIgLgRgAgigiIAIgFIALAPIgIAFIgLgPgAABghQALgNAFgQIAKAAIgEANIAnAAIAAAJIgsAAIgJAOg");
	this.shape_28.setTransform(-14.3,73);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgJARIAIghIALAAIgKAhg");
	this.shape_29.setTransform(-27.7,77.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("Ag+AyQALgFAHgGQAIgGADgGQAIgLAAgWIAAgFIgjAAIAAgJIB5AAIAAAJIgnAAIAAAxQgBAHAIAAIALAAQAJAAACgIIABgSIALADIgCASQgDAOgQAAIgQAAQgQAAAAgPIAAgyIgYAAIAAAEQAAAagIANQgIAOgZAMgAgwgwIAAgJIBiAAIAAAJg");
	this.shape_30.setTransform(-40.3,73.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgbAyIAAgKIAWAAIAAhKIgWAGIAAgLIAigKIAABZIAVAAIAAAKg");
	this.shape_31.setTransform(-50.4,72.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgrA/IAAg4IgPAQIgEgKQAQgPAPgaIAJAEIgMATIAABEgAALA9IgCgLIASABQAIAAAAgIIAAgQIg8AAIAAgIIA8AAIAAgLIg2AAIAAgIIBPAAIAAAIIgPAAIAAALIASAAIAAAIIgSAAIAAATQAAAPgPAAgAgMAhIAHgFIANAPIgIAGgAAqgFIAAgEIgtAAIAAAEIgJAAIAAgzIBAAAIAAAzgAgDgRIAtAAIAAgMIgtAAgAgDgkIAtAAIAAgMIgtAAgAg+gaQASgOANgWIAJAGQgQAXgSAQg");
	this.shape_32.setTransform(-61,73);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AALA9IgCgMIATABQAJAAAAgJIAAhAIgpAAIAAgKIApAAIAAgbIALAAIAAAbIAQAAIAAAKIgQAAIAABBQAAATgSAAgAg+AyQASgRAKgUIgYgkIAIgFIAWAeQAHgRACgWIgoAAIAAgKIAzAAIAAAKQgEAbgKAWIAUAdIgKAGIgPgZQgGALgHAJIgQARgAgBgHIAHgFQAKAOAIAOIgKAGIgPgdg");
	this.shape_33.setTransform(-73.9,72.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAfA/IAAgIIg9AAIAAAIIgJAAIAAgrIBQAAIAAArgAgeAuIA9AAIAAgRIg9AAgAg/AHQApgOASgWIAJAAQAUAYAnAJIgGAKQgPgFgMgHIAAAIIg8AAIAAgIQgNAIgPAGgAAdABQgQgIgNgNQgLAMgRAJIA5AAIAAAAgAg+gYQAQgQAJgWIALAAIgGANIAkAAIAAAJIgpAAQgIANgKAKgAAYgiIAIgFIAMAQIgIAGIgMgRgAghgiIAHgFIALAPIgIAFIgKgPgAACghQAKgNAEgQIALAAIgEANIAnAAIAAAJIgsAAIgJAOg");
	this.shape_34.setTransform(-86.9,73);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("A1NDcIAAm3MAqbAAAIAAG3g");
	this.shape_35.setTransform(6.9,87.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	// 答题背景.png
	this.getHelpBtn = new lib.Symbol4();
	this.getHelpBtn.parent = this;
	this.getHelpBtn.setTransform(203.4,88.5,1,1,0,0,0,41.4,48.6);
	this.getHelpBtn.alpha = 0.012;

	this.instance = new lib.答题背景();
	this.instance.parent = this;
	this.instance.setTransform(-254,-173);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.getHelpBtn}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.答题背景动, new cjs.Rectangle(-254,-173,507,324), null);


(lib.答题背景_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_16 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(16).call(this.frame_16).wait(1));

	// 图层 1
	this.questionPanelMc = new lib.答题背景动();
	this.questionPanelMc.parent = this;
	this.questionPanelMc.setTransform(0,-9.6,0.58,0.58);
	this.questionPanelMc.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.questionPanelMc).to({scaleX:1.11,scaleY:1.11,y:0,alpha:1},6,cjs.Ease.get(1)).to({scaleX:0.95,scaleY:0.95},4,cjs.Ease.get(0.5)).to({scaleX:1,scaleY:1},4).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147.4,-110,294.3,188.1);


(lib.答错mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// 错叉子
	this.instance = new lib.错叉子();
	this.instance.parent = this;
	this.instance.setTransform(241.6,221,4,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.65,scaleY:0.65,y:141},4,cjs.Ease.get(-1)).to({scaleX:1.2,scaleY:1.2},5,cjs.Ease.get(1)).to({scaleX:0.9,scaleY:0.9},3,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},3,cjs.Ease.get(1)).wait(2).to({scaleX:1.2,scaleY:1.2,alpha:0},7).wait(1));

	// 错怪兽
	this.instance_1 = new lib.错怪兽_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(50,281.4);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},4).wait(15).to({alpha:0},5,cjs.Ease.get(-1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-322.4,-343,1128,1128);


(lib.p4爆炸 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// 2爆炸
	this.instance = new lib._2爆炸_1();
	this.instance.parent = this;
	this.instance.setTransform(-2.4,8.3,0.163,0.163);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({scaleX:1.5,scaleY:1.5,x:-4.4},5,cjs.Ease.get(-1)).to({scaleX:1.8,scaleY:1.8,alpha:0},4).wait(3));

	// 炸弹
	this.instance_1 = new lib.m炸弹_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(66,11.1,0.4,0.4,90);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:1},0).to({scaleX:1,scaleY:1,rotation:-390,guide:{path:[65.9,11.1,103.9,-55.6,39.9,-70.4,-33,-87.3,-8.3,-0.1]}},10).to({_off:true},2).wait(9));

	// 2碎片5
	this.instance_2 = new lib._2碎片5_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.8,8.1,0.276,0.276);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:41.8,y:-3.3},5,cjs.Ease.get(1)).to({rotation:60,x:55.1,y:-4.5,alpha:0},4).wait(1));

	// 2碎片4
	this.instance_3 = new lib._2碎片4_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.6,6.6,0.276,0.276,15);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:23.3,y:-29.1},5,cjs.Ease.get(1)).to({x:34.9,y:-41.5,alpha:0},4).wait(1));

	// 2碎片6
	this.instance_4 = new lib._2碎片6_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-1.4,9.9,0.276,0.276);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:32.5,y:30},5,cjs.Ease.get(1)).to({rotation:45,x:48,y:35.7,alpha:0},4).wait(1));

	// 碎片3
	this.instance_5 = new lib.碎片3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-4.4,10.7,0.276,0.276);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-25.1,y:30},5,cjs.Ease.get(1)).to({rotation:-30,x:-36,y:44.9,alpha:0},4).wait(1));

	// 2碎片2
	this.instance_6 = new lib._2碎片2_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-5.2,9.9,0.276,0.276);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-44.2,y:16.2},5,cjs.Ease.get(1)).to({rotation:-90,x:-60,y:23.7,alpha:0},4).wait(1));

	// 2碎片1
	this.instance_7 = new lib._2碎片1_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-5.4,7.8,0.276,0.276,120);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:-40.2,y:-9.7},5,cjs.Ease.get(1)).to({rotation:60,x:-48,y:-10,alpha:0},4).wait(1));

	// 2爆炸后
	this.instance_8 = new lib.p4路2洞();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-31.3,-14.8);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(16).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(58.6,7.3,15,7.6);


(lib.p3爆炸 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// 2爆炸
	this.instance = new lib._2爆炸_1();
	this.instance.parent = this;
	this.instance.setTransform(-2.4,8.3,0.163,0.163);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({scaleX:1.5,scaleY:1.5,x:-4.4},5,cjs.Ease.get(-1)).to({scaleX:1.8,scaleY:1.8,alpha:0},4).wait(3));

	// 炸弹
	this.instance_1 = new lib.m炸弹_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-61.5,-84.8,0.4,0.4,90);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({x:-39.1,y:-46.4,alpha:1},0).to({scaleX:1,scaleY:1,rotation:-390,guide:{path:[-39.1,-46.4,-84.2,-151.7,-17.5,-152.1,54.9,-152.6,47.3,-85.1,40.6,-25.9,-6,0.1]}},10).to({_off:true},2).wait(9));

	// 2碎片5
	this.instance_2 = new lib._2碎片5_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.8,8.1,0.276,0.276);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:41.8,y:-3.3},5,cjs.Ease.get(1)).to({rotation:60,x:55.1,y:-4.5,alpha:0},4).wait(1));

	// 2碎片4
	this.instance_3 = new lib._2碎片4_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.6,6.6,0.276,0.276,15);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:23.3,y:-29.1},5,cjs.Ease.get(1)).to({x:34.9,y:-41.5,alpha:0},4).wait(1));

	// 2碎片6
	this.instance_4 = new lib._2碎片6_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-1.4,9.9,0.276,0.276);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:32.5,y:30},5,cjs.Ease.get(1)).to({rotation:45,x:48,y:35.7,alpha:0},4).wait(1));

	// 碎片3
	this.instance_5 = new lib.碎片3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-4.4,10.7,0.276,0.276);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-25.1,y:30},5,cjs.Ease.get(1)).to({rotation:-30,x:-36,y:44.9,alpha:0},4).wait(1));

	// 2碎片2
	this.instance_6 = new lib._2碎片2_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-5.2,9.9,0.276,0.276);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-44.2,y:16.2},5,cjs.Ease.get(1)).to({rotation:-90,x:-60,y:23.7,alpha:0},4).wait(1));

	// 2碎片1
	this.instance_7 = new lib._2碎片1_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-5.4,7.8,0.276,0.276,120);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:-40.2,y:-9.7},5,cjs.Ease.get(1)).to({rotation:60,x:-48,y:-10,alpha:0},4).wait(1));

	// 2爆炸后
	this.instance_8 = new lib._2爆炸后();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-23.9,-15.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(16).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.9,-88.6,15,7.6);


(lib.p2爆炸 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// 2爆炸
	this.instance = new lib._2爆炸_1();
	this.instance.parent = this;
	this.instance.setTransform(-2.4,8.3,0.163,0.163);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({scaleX:1.5,scaleY:1.5,x:-4.4},5,cjs.Ease.get(-1)).to({scaleX:1.8,scaleY:1.8,alpha:0},4).wait(3));

	// 炸弹
	this.instance_1 = new lib.m炸弹_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(91.1,-42.3,0.4,0.4,90);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:1},0).to({scaleX:1,scaleY:1,rotation:-390,guide:{path:[91.1,-42.4,98.6,-100.5,47.7,-113.7,-85.4,-123.5,-7.7,-0.3]}},10).to({_off:true},2).wait(9));

	// 2碎片5
	this.instance_2 = new lib._2碎片5_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.8,8.1,0.276,0.276);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:41.8,y:-3.3},5,cjs.Ease.get(1)).to({rotation:60,x:55.1,y:-4.5,alpha:0},4).wait(1));

	// 2碎片4
	this.instance_3 = new lib._2碎片4_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.6,6.6,0.276,0.276,15);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:23.3,y:-29.1},5,cjs.Ease.get(1)).to({x:34.9,y:-41.5,alpha:0},4).wait(1));

	// 2碎片6
	this.instance_4 = new lib._2碎片6_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-1.4,9.9,0.276,0.276);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:32.5,y:30},5,cjs.Ease.get(1)).to({rotation:45,x:48,y:35.7,alpha:0},4).wait(1));

	// 碎片3
	this.instance_5 = new lib.碎片3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-4.4,10.7,0.276,0.276);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-25.1,y:30},5,cjs.Ease.get(1)).to({rotation:-30,x:-36,y:44.9,alpha:0},4).wait(1));

	// 2碎片2
	this.instance_6 = new lib._2碎片2_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-5.2,9.9,0.276,0.276);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,x:-44.2,y:16.2},5,cjs.Ease.get(1)).to({rotation:-90,x:-60,y:23.7,alpha:0},4).wait(1));

	// 2碎片1
	this.instance_7 = new lib._2碎片1_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-5.4,7.8,0.276,0.276,120);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(12).to({_off:false},0).to({scaleX:1.2,scaleY:1.2,rotation:0,x:-40.2,y:-9.7},5,cjs.Ease.get(1)).to({rotation:60,x:-48,y:-10,alpha:0},4).wait(1));

	// 2爆炸后
	this.instance_8 = new lib.p2洞();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-29,-11.5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(16).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(83.7,-46.1,14.9,7.6);


(lib._2故障2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// 图层 1
	this.instance = new lib._2故障2动画();
	this.instance.parent = this;
	this.instance.setTransform(83.2,-10,0.153,0.153,126.7,0,0,0,17.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:1},0).to({regY:17.3,scaleX:1,scaleY:1,rotation:-50,guide:{path:[84.6,-10.1,83.4,-97.3,18.9,-69.5,2.3,-62.7,-2.9,-41.1,-8.1,-19.6,-1.9,16.7]}},8).to({regY:17.2,rotation:5,guide:{path:[-1.8,16.7,-1.8,17,-1.7,17.4]}},4).to({rotation:-35,x:0.2,y:16.1},4).to({rotation:-20,x:0,y:17.2},4).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(80.6,-12.9,9.6,9.1);


(lib.结算小男孩 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// Layer 4
	this.instance = new lib.结算人头1();
	this.instance.parent = this;
	this.instance.setTransform(-20,-47.5);

	this.instance_1 = new lib.结算人头2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-20,-45.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},39).to({state:[{t:this.instance}]},4).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance}]},4).wait(1));

	// 结算人身.png
	this.instance_2 = new lib.结算人身();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-26,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50));

	// 结算人手.png
	this.instance_3 = new lib.结算人手_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-21.5,-18.5,1,1,3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({rotation:-10},7).wait(2).to({rotation:3},7).wait(2).to({rotation:-10},7).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-52.7,54,104.3);


(lib.教程跳 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_64 = function() {
		this.stop();
		this.parent.dispatchEvent(new createjs.Event("guideComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(64).call(this.frame_64).wait(1));

	// 教程手
	this.instance = new lib.教程手();
	this.instance.parent = this;
	this.instance.setTransform(60,80,0.172,0.172);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:41.8,y:57.3,alpha:1},8).wait(4).to({x:27.7,y:-38.8},3).to({x:59.2,y:-154},4).to({x:134,y:-260.4},6).wait(9).to({x:41.8,y:57.3},0).to({x:27.7,y:-38.8},3).to({x:59.2,y:-154},4).to({x:134,y:-260.4},6).wait(11).to({alpha:0},6).wait(1));

	// 教程按下圈
	this.instance_1 = new lib.教程按下圈();
	this.instance_1.parent = this;
	this.instance_1.setTransform(21.2,24.7,0.126,0.126);
	this.instance_1.alpha = 0.461;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({scaleX:0.32,scaleY:0.32,x:12.8,y:14.4,alpha:1},3).wait(4).to({x:-1.3,y:-81.7},3).to({x:30.2,y:-196.9},4).to({x:105,y:-303.3},6).wait(9).to({x:12.8,y:14.4},0).to({x:-1.3,y:-81.7},3).to({x:30.2,y:-196.9},4).to({x:105,y:-303.3},6).wait(11).to({alpha:0},6).wait(1));

	// 教程跳箭头
	this.instance_2 = new lib.教程跳箭头();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-6.1,-46.2,0.507,0.507,-33.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(15).to({_off:false},0).to({scaleX:0.51,scaleY:0.51,rotation:-17.8,x:16.3,y:-168.3},4).to({scaleX:0.51,scaleY:0.51,rotation:0,x:74.3,y:-275.3},6).to({_off:true},9).wait(3).to({_off:false,rotation:-33.7,x:-6.1,y:-46.2},0).to({scaleX:0.51,scaleY:0.51,rotation:-17.8,x:16.3,y:-168.3},4).to({scaleX:0.51,scaleY:0.51,rotation:0,x:74.3,y:-275.3},6).wait(11).to({alpha:0},6).wait(1));

	// 图层 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_16 = new cjs.Graphics().p("AqnGiIAAtDIVPAAIAANDg");
	var mask_graphics_17 = new cjs.Graphics().p("AqnKWIAA0rIVPAAIAAUrg");
	var mask_graphics_18 = new cjs.Graphics().p("AqnOLIAA8VIVPAAIAAcVg");
	var mask_graphics_19 = new cjs.Graphics().p("AqnR/MAAAgj9IVPAAMAAAAj9g");
	var mask_graphics_20 = new cjs.Graphics().p("AqnV0MAAAgrnIVPAAMAAAArng");
	var mask_graphics_21 = new cjs.Graphics().p("AqnZpMAAAgzRIVPAAMAAAAzRg");
	var mask_graphics_22 = new cjs.Graphics().p("AqnddMAAAg65IVPAAMAAAA65g");
	var mask_graphics_23 = new cjs.Graphics().p("EgKnAhSMAAAhCjIVPAAMAAABCjg");
	var mask_graphics_24 = new cjs.Graphics().p("EgKnAlGMAAAhKLIVPAAMAAABKLg");
	var mask_graphics_25 = new cjs.Graphics().p("EgKnAo7MAAAhR1IVPAAMAAABR1g");
	var mask_graphics_38 = new cjs.Graphics().p("AqnGiIAAtDIVPAAIAANDg");
	var mask_graphics_39 = new cjs.Graphics().p("AqnKWIAA0rIVPAAIAAUrg");
	var mask_graphics_40 = new cjs.Graphics().p("AqnOLIAA8VIVPAAIAAcVg");
	var mask_graphics_41 = new cjs.Graphics().p("AqnR/MAAAgj9IVPAAMAAAAj9g");
	var mask_graphics_42 = new cjs.Graphics().p("AqnV0MAAAgrnIVPAAMAAAArng");
	var mask_graphics_43 = new cjs.Graphics().p("AqnZpMAAAgzRIVPAAMAAAAzRg");
	var mask_graphics_44 = new cjs.Graphics().p("AqnddMAAAg65IVPAAMAAAA65g");
	var mask_graphics_45 = new cjs.Graphics().p("EgKnAhSMAAAhCjIVPAAMAAABCjg");
	var mask_graphics_46 = new cjs.Graphics().p("EgKnAlGMAAAhKLIVPAAMAAABKLg");
	var mask_graphics_47 = new cjs.Graphics().p("EgKnAo7MAAAhR1IVPAAMAAABR1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_graphics_16,x:30.4,y:-27.5}).wait(1).to({graphics:mask_graphics_17,x:30.6,y:-26.4}).wait(1).to({graphics:mask_graphics_18,x:30.7,y:-25.4}).wait(1).to({graphics:mask_graphics_19,x:30.9,y:-24.3}).wait(1).to({graphics:mask_graphics_20,x:31.1,y:-23.3}).wait(1).to({graphics:mask_graphics_21,x:31.3,y:-22.3}).wait(1).to({graphics:mask_graphics_22,x:31.4,y:-21.2}).wait(1).to({graphics:mask_graphics_23,x:31.6,y:-20.2}).wait(1).to({graphics:mask_graphics_24,x:31.8,y:-19.1}).wait(1).to({graphics:mask_graphics_25,x:32,y:-18.1}).wait(9).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_38,x:30.4,y:-27.5}).wait(1).to({graphics:mask_graphics_39,x:30.6,y:-26.4}).wait(1).to({graphics:mask_graphics_40,x:30.7,y:-25.4}).wait(1).to({graphics:mask_graphics_41,x:30.9,y:-24.3}).wait(1).to({graphics:mask_graphics_42,x:31.1,y:-23.3}).wait(1).to({graphics:mask_graphics_43,x:31.3,y:-22.3}).wait(1).to({graphics:mask_graphics_44,x:31.4,y:-21.2}).wait(1).to({graphics:mask_graphics_45,x:31.6,y:-20.2}).wait(1).to({graphics:mask_graphics_46,x:31.8,y:-19.1}).wait(1).to({graphics:mask_graphics_47,x:32,y:-18.1}).wait(18));

	// 教程跳线
	this.instance_3 = new lib.教程跳线();
	this.instance_3.parent = this;
	this.instance_3.setTransform(35.2,-170.3,0.507,0.507);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(16).to({_off:false},0).to({_off:true},18).wait(4).to({_off:false},0).wait(20).to({alpha:0},6).wait(1));

	// 教程字2
	this.instance_4 = new lib.教程字2_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1.1,-55.6);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({alpha:1},8).wait(50).to({alpha:0},6).wait(1));

	// 教程跳图标
	this.instance_5 = new lib.教程跳图标();
	this.instance_5.parent = this;
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({alpha:1},8).wait(50).to({alpha:0},6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-65.1,159,192);


(lib.教程跑 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_73 = function() {
		this.parent.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(73).call(this.frame_73).wait(1));

	// 图层 4
	this.instance = new lib.教程字1_1();
	this.instance.parent = this;
	this.instance.setTransform(6,-57.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({alpha:1},9).wait(45).to({alpha:0},6).wait(1));

	// FlashAICB
	this.instance_1 = new lib.教程手();
	this.instance_1.parent = this;
	this.instance_1.setTransform(82.1,82.2,0.172,0.172);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({x:68.5,y:70,alpha:1},9).wait(5).to({x:45.6,y:61.5},5).to({x:45.2,y:60.7},6).to({x:68.5,y:70},4).wait(11).to({x:46,y:61.5},5).wait(6).to({x:68.5,y:70},4).wait(5).to({x:82.1,y:82.2,alpha:0},6).wait(1));

	// FlashAICB
	this.instance_2 = new lib.教程按下圈();
	this.instance_2.parent = this;
	this.instance_2.setTransform(31.2,23.4,0.112,0.112);
	this.instance_2.alpha = 0.09;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({_off:false},0).to({scaleX:0.32,scaleY:0.32,x:16.6,y:18.6,alpha:1},3).to({x:16.8,y:18.2},6).to({scaleX:0.11,scaleY:0.11,x:31.2,y:23.4,alpha:0.09},3).to({_off:true},1).wait(13).to({_off:false},0).to({scaleX:0.32,scaleY:0.32,x:16.6,y:18.6,alpha:1},3).to({x:16.8,y:18.2},6).to({scaleX:0.11,scaleY:0.11,x:31.2,y:23.4,alpha:0.09},3).to({_off:true},1).wait(12));

	// 图层 1
	this.instance_3 = new lib.教学跑图标();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,0.085,0.085);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({alpha:1},9).wait(58).to({alpha:0},6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.5,-35.3,81.1,70.6);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 3
	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(48,61,1,1,0,0,0,51,67);
	this.instance.alpha = 0.012;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer 1
	this.instance_1 = new lib.跳过();
	this.instance_1.parent = this;

	this.instance_2 = new lib.继续();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,-6,102,134);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(47.1,62,1,1,0,0,0,51,67);
	this.instance.alpha = 0.012;

	this.instance_1 = new lib.拍照();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-3.9,-5,102,134), null);


(lib.Symbol2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance_3 = new lib.Symbol8();
	this.instance_3.parent = this;
	this.instance_3.setTransform(40.2,37.1,0.785,0.552,0,0,0,51.2,67.1);
	this.instance_3.alpha = 0.012;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

	// Layer 1
	this.instance_4 = new lib.教学跑图标();
	this.instance_4.parent = this;
	this.instance_4.setTransform(40.7,35.4,0.085,0.085,0,0,0,0.6,0.6);

	this.instance_5 = new lib.教程跳();
	this.instance_5.parent = this;
	this.instance_5.setTransform(44,37.1);

	this.instance_6 = new lib.教程跳图标();
	this.instance_6.parent = this;
	this.instance_6.setTransform(43.1,36.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.instance_6},{t:this.instance_5}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,81.3,74);


(lib.p4路4完成mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4路4完成_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.2,scaleY:1.2,y:-5},7,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:0},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67.5,-45.5,135,91);


(lib.p4路3问_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4路3问();
	this.instance.parent = this;
	this.instance.setTransform(-10.5,-13.9);

	this.instance_1 = new lib.p4灯晕();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4路3问_1, new cjs.Rectangle(-25,-25,50,50), null);


(lib.p4灯晕2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4灯晕();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.697,0.697);
	this.instance.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({alpha:1},20).wait(5).to({alpha:0.199},20).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.4,-17.4,34.8,34.8);


(lib.p4灯晕1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4灯晕();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.697,0.697);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.199},19).wait(5).to({alpha:1},20).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.4,-17.4,34.8,34.8);


(lib.p4潜水艇mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4潜水艇();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-5.5},14).to({y:0},15).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46,-46,92,92);


(lib.p4房4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_房4();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-59.9);

	this.instance_1 = new lib.p4灯晕2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.6,-56.5,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4房4, new cjs.Rectangle(-34.5,-66.1,69,132.1), null);


(lib.p4房3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4_房3();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-46.9);

	this.instance_1 = new lib.p4灯晕2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-3.4,-42.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4房3, new cjs.Rectangle(-22.5,-60,45,120.1), null);


(lib.p4房2mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p4房2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.2,scaleY:1.15},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.5,-100.5,115,201);


(lib.p4房1mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p4房1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.2,x:5.5,y:8.8},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:0,y:0},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.5,-118,89,118);


(lib.p4tvmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_39 = function() {
		this.stop();
		this.parent.dispatchEvent(new Event("gameComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(1));

	// 完成
	this.instance = new lib.p4路4完成mc();
	this.instance.parent = this;
	this.instance.setTransform(-67.5,60.5,0.3,0.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(32).to({_off:false},0).to({scaleX:1,scaleY:1,y:45.5},7,cjs.Ease.get(1)).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1e2mMAq9gBBIhqYRQAmGlnhBdMgiYAO9g");
	mask.setTransform(-179.6,83.8);

	// 人进
	this.instance_1 = new lib.p4h进();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-153.3,58.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(27).to({_off:false},0).to({scaleX:0.7,scaleY:0.7,rotation:-23.2,x:-19.7,y:148.5},5).to({_off:true},1).wait(7));

	// 人手1.png
	this.instance_2 = new lib.人手1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-265.4,123.2,1,1,-26.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(22).to({_off:false},0).wait(1).to({rotation:-14,x:-242.5,y:93.7},0).wait(2).to({rotation:-97.9,x:-187.6,y:103},0).to({_off:true},2).wait(13));

	// 人身.png
	this.instance_3 = new lib.人身();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-258.1,64.8,1,1,-5);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(22).to({_off:false},0).wait(1).to({rotation:-14,x:-241.1,y:45.4},0).wait(2).to({x:-216.5,y:22.1},0).to({_off:true},2).wait(13));

	// 人手2.png
	this.instance_4 = new lib.人手2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-229.5,109,1,1,11.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(22).to({_off:false},0).wait(1).to({rotation:-14,x:-208,y:86.8},0).wait(2).to({rotation:-20.8,x:-184,y:64.7},0).to({_off:true},2).wait(13));

	// 人腿1.png
	this.instance_5 = new lib.人腿1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-269.5,143.2,1,1,-12.5);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(22).to({_off:false},0).wait(1).to({rotation:-14,x:-239.9,y:120.6},0).wait(2).to({rotation:-54.4,x:-206.3,y:118.3},0).to({_off:true},2).wait(13));

	// 人腿2.png
	this.instance_6 = new lib.人腿2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-229.7,136.9,1,1,13.7);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).wait(1).to({rotation:-14,x:-204.1,y:114.8},0).wait(2).to({rotation:9.5,x:-174,y:84.1},0).to({_off:true},2).wait(13));

	// m进
	this.instance_7 = new lib.m跑2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-278.1,35.1);

	this.instance_8 = new lib.m跑1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-260.3,22.8,1,1,-7.2);

	this.instance_9 = new lib.p4m进();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-154.6,62.1,1,1,-45);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_7,this.instance_8,this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7,p:{rotation:0,x:-278.1,y:35.1}}]}).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_7,p:{rotation:-20.4,x:-254.1,y:14.7}}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_9}]},5).to({state:[]},1).wait(29));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(5).to({_off:false},0).to({scaleX:0.7,scaleY:0.7,rotation:-79,x:-23,y:151.1},5).to({_off:true},1).wait(29));

	// 显示器动画
	this.instance_10 = new lib.p4tv();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-62.7,111.6);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(7).to({_off:false},0).wait(33));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-278.1,35.1,98,144);


(lib.p2路3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2路3();
	this.instance.parent = this;
	this.instance.setTransform(-214,-117);

	this.instance_1 = new lib.p4灯晕1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(66,-73);

	this.instance_2 = new lib.p4灯晕2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-140.1,-67.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2路3_1, new cjs.Rectangle(-214,-117,428,234), null);


(lib.p2路1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2路1();
	this.instance.parent = this;
	this.instance.setTransform(-133,-117.5);

	this.instance_1 = new lib.p4灯晕1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.9,-51);

	this.instance_2 = new lib.p4灯晕1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-97.4,-101.1);

	this.instance_3 = new lib.p4灯晕2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-51.4,-72.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2路1_1, new cjs.Rectangle(-133,-118.5,266,237), null);


(lib.p2房3旗mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2房3旗();
	this.instance.parent = this;
	this.instance.setTransform(27.5,9.5,1,1,0,0,0,27.5,9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:27.4,scaleX:1.01,skewY:-10,y:9.6},7,cjs.Ease.get(1)).to({regX:27.5,scaleX:1,skewY:0,y:9.5},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82,-85.5,164,171);


(lib.p2房3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p2房3.png
	this.instance = new lib.p2房3();
	this.instance.parent = this;
	this.instance.setTransform(-0.9,-215);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// p2房3旗mc
	this.instance_1 = new lib.p2房3旗mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-5,-190.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2房3_1, new cjs.Rectangle(-87,-275.9,174.1,276), null);


(lib.p2房2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2房2球();
	this.instance.parent = this;
	this.instance.setTransform(11,0,1,1,-5,0,0,11,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:0.1,rotation:8,y:0.1},29).to({regX:11.1,rotation:-5,x:11.1},30).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99.6,-188.6,183.4,196.9);


(lib.p2房1问mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p2房1问();
	this.instance.parent = this;
	this.instance.setTransform(0,16,1,1,-15,0,0,0,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:15},19).to({rotation:-15,y:16.1},20).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.1,-66.4,131.9,134);


(lib.p2房1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p2房1问mc
	this.instance = new lib.p2房1问mc();
	this.instance.parent = this;
	this.instance.setTransform(16.5,-164.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// p2房1.png
	this.instance_1 = new lib.p2房1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-70,-143);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2房1_1, new cjs.Rectangle(-70,-231,148.3,231), null);


(lib.p1飞船mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1飞船_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-5},12).to({y:0},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.5,-23.5,83,47);


(lib.p1房子mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1房子_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.98,rotation:-0.8,x:-3,y:-1.5},12).to({scaleX:1,scaleY:0.98,rotation:1,x:3.5,y:2},14).to({scaleY:1,rotation:0,x:0,y:0},13).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.5,-137,93,274);


(lib.p1m嘴mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1m嘴_1();
	this.instance.parent = this;
	this.instance.setTransform(0,-25.5,1,1,0,0,0,0,-25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-25.4,scaleX:1.05,scaleY:0.9,y:-25.4},5,cjs.Ease.get(1)).to({regY:-25.5,scaleX:1,scaleY:1,y:-25.5},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.5,-28,127,56);


(lib.p1m呆毛mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1m呆毛_1();
	this.instance.parent = this;
	this.instance.setTransform(-6,-0.1,0.899,1.099,10,0,0,-5,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:-51.5,scaleX:0.9,rotation:9.9,x:8.2,y:-55.2},0).wait(1).to({scaleX:0.9,scaleY:1.1,rotation:9.8,x:8.1},0).wait(1).to({scaleX:0.9,scaleY:1.1,rotation:9.5,x:7.8,y:-55.1},0).wait(1).to({scaleX:0.91,scaleY:1.09,rotation:9.1,x:7.4},0).wait(1).to({scaleX:0.91,scaleY:1.09,rotation:8.6,x:7,y:-55},0).wait(1).to({scaleX:0.91,scaleY:1.09,rotation:8,x:6.4},0).wait(1).to({scaleX:0.92,scaleY:1.08,rotation:7.3,x:5.7,y:-54.9},0).wait(1).to({scaleX:0.92,scaleY:1.08,rotation:6.4,x:5,y:-54.8},0).wait(1).to({scaleX:0.93,scaleY:1.07,rotation:5.5,x:4.1,y:-54.6},0).wait(1).to({scaleX:0.93,scaleY:1.07,rotation:4.5,x:3.2,y:-54.5},0).wait(1).to({scaleX:0.94,scaleY:1.06,rotation:3.4,x:2.2,y:-54.3},0).wait(1).to({scaleX:0.95,scaleY:1.05,rotation:2.2,x:1.2,y:-54.1},0).wait(1).to({scaleX:0.95,scaleY:1.05,rotation:0.9,x:0.1,y:-53.8},0).wait(1).to({scaleX:0.96,scaleY:1.04,rotation:-0.4,x:-1.1,y:-53.5},0).wait(1).to({scaleX:0.97,scaleY:1.03,rotation:-1.8,x:-2.2,y:-53.1},0).wait(1).to({scaleX:0.98,scaleY:1.02,rotation:-3.2,x:-3.4,y:-52.7},0).wait(1).to({scaleX:0.99,scaleY:1.01,rotation:-4.6,x:-4.5,y:-52.4},0).wait(1).to({scaleX:1,scaleY:1,rotation:-6,x:-5.6,y:-51.9},0).wait(1).to({scaleX:1,scaleY:1,rotation:-7.3,x:-6.7,y:-51.5},0).wait(1).to({scaleX:1.01,scaleY:0.99,rotation:-8.6,x:-7.7,y:-51},0).wait(1).to({scaleX:1.02,scaleY:0.98,rotation:-9.8,x:-8.6,y:-50.6},0).wait(1).to({scaleX:1.02,scaleY:0.97,rotation:-11,x:-9.5,y:-50.2},0).wait(1).to({scaleX:1.03,scaleY:0.97,rotation:-12,x:-10.3,y:-49.8},0).wait(1).to({scaleX:1.04,scaleY:0.96,rotation:-12.9,x:-10.9,y:-49.4},0).wait(1).to({scaleX:1.04,scaleY:0.96,rotation:-13.6,x:-11.4,y:-49.1},0).wait(1).to({scaleX:1.05,scaleY:0.95,rotation:-14.2,x:-11.8,y:-48.9},0).wait(1).to({scaleX:1.05,scaleY:0.95,rotation:-14.6,x:-12.2,y:-48.6},0).wait(1).to({scaleX:1.05,scaleY:0.95,rotation:-14.9,x:-12.4,y:-48.5},0).wait(1).to({regX:-4.9,regY:0.1,scaleY:0.95,rotation:-15,x:-4.8,y:0.2},0).wait(1).to({regX:0,regY:-51.5,scaleY:0.95,rotation:-14.9,x:-12.5,y:-48.5},0).wait(1).to({scaleX:1.05,scaleY:0.95,rotation:-14.8,x:-12.4,y:-48.6},0).wait(1).to({scaleX:1.05,scaleY:0.95,rotation:-14.5,x:-12.2,y:-48.7},0).wait(1).to({scaleX:1.04,scaleY:0.95,rotation:-14.2,x:-11.9,y:-48.8},0).wait(1).to({scaleX:1.04,scaleY:0.96,rotation:-13.7,x:-11.6,y:-49},0).wait(1).to({scaleX:1.04,scaleY:0.96,rotation:-13.1,x:-11.2,y:-49.3},0).wait(1).to({scaleX:1.03,scaleY:0.97,rotation:-12.5,x:-10.7,y:-49.5},0).wait(1).to({scaleX:1.03,scaleY:0.97,rotation:-11.7,x:-10.1,y:-49.9},0).wait(1).to({scaleX:1.02,scaleY:0.98,rotation:-10.8,x:-9.4,y:-50.2},0).wait(1).to({scaleX:1.02,scaleY:0.98,rotation:-9.8,x:-8.7,y:-50.6},0).wait(1).to({scaleX:1.01,scaleY:0.99,rotation:-8.8,x:-7.9,y:-50.9},0).wait(1).to({scaleX:1,scaleY:0.99,rotation:-7.7,x:-7,y:-51.3},0).wait(1).to({scaleX:1,scaleY:1,rotation:-6.5,x:-6.1,y:-51.7},0).wait(1).to({scaleX:0.99,scaleY:1.01,rotation:-5.2,x:-5.1,y:-52.1},0).wait(1).to({scaleX:0.98,scaleY:1.02,rotation:-3.9,x:-4.1,y:-52.5},0).wait(1).to({scaleX:0.98,scaleY:1.02,rotation:-2.6,x:-2.9,y:-52.9},0).wait(1).to({scaleX:0.97,scaleY:1.03,rotation:-1.2,x:-1.9,y:-53.3},0).wait(1).to({scaleX:0.96,scaleY:1.04,rotation:0.1,x:-0.7,y:-53.6},0).wait(1).to({scaleX:0.95,scaleY:1.05,rotation:1.5,x:0.4,y:-53.9},0).wait(1).to({scaleX:0.94,scaleY:1.06,rotation:2.7,x:1.6,y:-54.2},0).wait(1).to({scaleX:0.94,scaleY:1.06,rotation:4,x:2.7,y:-54.4},0).wait(1).to({scaleX:0.93,scaleY:1.07,rotation:5.1,x:3.7,y:-54.6},0).wait(1).to({scaleX:0.92,scaleY:1.08,rotation:6.2,x:4.7,y:-54.8},0).wait(1).to({scaleX:0.92,scaleY:1.08,rotation:7.2,x:5.6,y:-54.9},0).wait(1).to({scaleX:0.91,scaleY:1.09,rotation:8,x:6.3,y:-55},0).wait(1).to({scaleX:0.91,scaleY:1.09,rotation:8.7,x:7},0).wait(1).to({scaleX:0.9,scaleY:1.1,rotation:9.3,x:7.5,y:-55.1},0).wait(1).to({scaleX:0.9,scaleY:1.1,rotation:9.7,x:7.9},0).wait(1).to({scaleX:0.9,scaleY:1.1,rotation:9.9,x:8.1,y:-55.2},0).wait(1).to({regX:-5,regY:0.1,scaleX:0.9,rotation:10,x:-6,y:-0.1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37,-117.1,90.6,124);


(lib.p1m = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p1m呆毛mc
	this.instance = new lib.p1m呆毛mc();
	this.instance.parent = this;
	this.instance.setTransform(10,-314,1,1,0,0,0,0,-51.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// p1m嘴mc
	this.instance_1 = new lib.p1m嘴mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-4.7,-118.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// p1m身.png
	this.instance_2 = new lib.p1m身();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-121,-271);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1m, new cjs.Rectangle(-121,-379.7,242,379.7), null);


(lib.p1bt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 可点击区域
	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(1.3,-0.7,1,1,0,0,0,51,67);
	this.instance.alpha = 0.012;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20));

	// Layer 6
	this.instance_1 = new lib.p1bt圆();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-19.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({scaleX:1.3,scaleY:1.3},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},10,cjs.Ease.get(-1)).wait(5));

	// Layer 5
	this.instance_2 = new lib.p1bt圆();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,-19.7,1.15,1.15);
	this.instance_2.alpha = 0.25;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({scaleX:1.3,scaleY:1.3,alpha:0.5},0).to({scaleX:2.82,scaleY:2.82,alpha:0},18,cjs.Ease.get(-1)).wait(1));

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AHAAAQAAC5iECDQiDCEi5AAQi4AAiEiEQiDiDAAi5QAAi4CDiEQCEiDC4AAQC5AACDCDQCECEAAC4g");
	this.shape.setTransform(0,-19.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(20));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AmpBSQAxgXgCgyIgyAAIAAgSIAyAAIAAg5IgoAAIAAgSICzAAIAAASIgmAAIAAA5IAvAAIAAASIgvAAIAABXIgUAAIAAhXIg9AAQABAegNAXQgNAWgbAPgAlmgJIA9AAIAAg5Ig9AAgACdBiIAAgLIhhAAIAAALIgTAAIAAhCICHAAIAABCgAA8BJIBhAAIAAgZIhhAAgAgrBiIAAgNIg7AAIAAANIgSAAIAAhZIBgAAIAABZgAhmBGIA7AAIAAgtIg7AAgADkBWQAHgKADgPQAEgQAAgWIAPABIAAAUQAHAPAKAHIAAg0IgsAAIAAgPIBbAAIAAAPIgfAAIAAAUIAdAAIAAAOIgdAAIAAAZQANACASABIBsgBIgGASIhngBQgyAAgRgbQgBAIgEAIQgDAIgFAIgAjTBSQALgIAKgJQAJgIAHgKIgegaQAJgmAEgXIgTAAIAAgRIAWAAIAFgoIATACIgGAmIAmAAIAAARQgCAdgFAUQgFAVgHAOIAYAWIgNAMIgVgTQgGAJgJAJQgKAJgNAKgAi5AQIAUAQQAFgKAEgSQAEgRACgbIgXAAQgHAogFAQgAFAA7QAYgJAMgPQALgPgCgWIAAgYIAQAAIgBAYQAAAPgCALIAIAGIAkAbIgKANIgGgEIghgcQgFAKgLAJQgLAJgQAHQgEgEgGgKgAGPAcIAAhBIg0AAIAABBIgQAAIAAhQIAbAAIAEgVIglAAIAAgPIBiAAIAAAPIgrAAIgEAVIAnAAIAABQgAAJAIQAfgKAYgOQAYgNAQgRIAUACIgPgJQAJgKAHgLQAIgLAEgNIATADIgIAQIA6AAIAAAQIhEAAQgBAEgGAGIgGAJIABAAIgFAFQAQAQAWALQAWALAcAGIgJARIgZgJQgLgFgKgFIAAAMIhaAAIAAgLQgNAGgeANQAYgJgbALgACWABQgJgEgKgHQgKgHgLgKQgJAIgKAHIgWANIBRAAIAAAAgAgjgRIhFAEQgKAAgJACIgIgSQAIgEAHgKQANgSATglIAUAIIgJANQgYAlgIAJIA9gCIgQgcIAPgIIAjA6IgRAJgADxgPIAAhLIBIAAIAABLgAEBgdIAoAAIAAgQIgoAAgAEBg6IAoAAIAAgRIgoAAgACVgzIANgJIASAWIgPAJIgQgWgAA0gyIANgJIASATIgOAKgAAJgtQANgLAJgOQAJgNAGgPIATADQgDAJgFAHIA1AAIAAAQIg+AAIgLAQIgPAQg");
	this.shape_1.setTransform(0,54.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.7,-67.7,102,134);


(lib._2飞碟和梯子 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 第二段飞碟
	this.instance = new lib._2飞碟_1();
	this.instance.parent = this;
	this.instance.setTransform(12,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:12.8},9).to({y:14.8},9).wait(1));

	// 第二段梯子
	this.instance_1 = new lib._2梯子_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14,-5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-40.3,80,80.6);


(lib._2道路2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 3
	this.instance = new lib._2旗子();
	this.instance.parent = this;
	this.instance.setTransform(-90,-100.4,1.011,1,0,0,8.4,11.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.01,skewY:-8.8},10).to({scaleX:1.01,skewY:8.4},9).wait(1));

	// 图层 1
	this.instance_1 = new lib._2道路2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-99.5,-233.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113.4,-233.5,213,467);


(lib._2灯晕2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._2灯晕();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.697,0.697);
	this.instance.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({alpha:1},20).wait(5).to({alpha:0.199},20).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.4,-17.4,34.8,34.8);


(lib._2灯晕1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._2灯晕();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.697,0.697);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.199},19).wait(5).to({alpha:1},20).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.4,-17.4,34.8,34.8);


(lib._2彩灯闪2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2彩灯闪();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({alpha:0.199},10).wait(3).to({alpha:1},11).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20.1,20.1);


(lib._2彩灯 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2彩灯闪();
	this.instance.parent = this;
	this.instance.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({alpha:1},10).wait(3).to({alpha:0.199},11).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20.1,20.1);


(lib.monster = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// m转
	this.instance = new lib.m转();
	this.instance.parent = this;
	this.instance.setTransform(0,15,1,1,0,0,180);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).wait(1));

	// m跑
	this.instance_1 = new lib.m跑();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,15,1,1,0,0,180);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({_off:true},1).wait(1));

	// m转
	this.instance_2 = new lib.m转();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,15);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true},1).wait(2));

	// m跑
	this.instance_3 = new lib.m跑();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,15);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49,-144,98,144);


(lib.l地mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1cCRIAAkhMAq5AAAIAAEhg");

	// l地
	this.instance = new lib.l地();
	this.instance.parent = this;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-276.4},39).wait(1));

	// l地
	this.instance_1 = new lib.l地();
	this.instance_1.parent = this;
	this.instance_1.setTransform(283.5,0);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:7.1},39).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.3,-5.5,274.6,11);


(lib.ltxt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// l8
	this.instance = new lib.l8();
	this.instance.parent = this;
	this.instance.setTransform(105.4,12.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(27).to({scaleX:1.5,scaleY:1.5},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8,cjs.Ease.get(-1)).wait(2));

	// l8
	this.instance_1 = new lib.l8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(98.1,12.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({scaleX:1.5,scaleY:1.5},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8,cjs.Ease.get(-1)).wait(5));

	// l8
	this.instance_2 = new lib.l8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(90.8,12.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({scaleX:1.5,scaleY:1.5},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8,cjs.Ease.get(-1)).wait(8));

	// l7
	this.instance_3 = new lib.l7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(77.2,11.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(18).to({scaleX:1.3,scaleY:1.3,y:12.6},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:11.5},8,cjs.Ease.get(-1)).wait(11));

	// l6
	this.instance_4 = new lib.l6();
	this.instance_4.parent = this;
	this.instance_4.setTransform(64,9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({scaleX:1.3,scaleY:1.3,y:10},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:9.5},8,cjs.Ease.get(-1)).wait(14));

	// l5
	this.instance_5 = new lib.l5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(54.2,7.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({scaleX:1.3,scaleY:1.3},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8,cjs.Ease.get(-1)).wait(17));

	// l4
	this.instance_6 = new lib.l4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(43.8,7.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({scaleX:1.3,scaleY:1.3,y:6.9},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:7.3},8,cjs.Ease.get(-1)).wait(20));

	// l3
	this.instance_7 = new lib.l3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(30.9,9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(6).to({scaleX:1.3,scaleY:1.3,y:9.8},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:9.6},8,cjs.Ease.get(-1)).wait(23));

	// l2
	this.instance_8 = new lib.l2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(18,9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(3).to({scaleX:1.3,scaleY:1.3,y:9.8},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:9.6},8,cjs.Ease.get(-1)).wait(26));

	// l1
	this.instance_9 = new lib.l1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(4.7,7.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({scaleX:1.3,scaleY:1.3},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8,cjs.Ease.get(-1)).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,106.6,18.3);


(lib.loadingClass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 小怪物
	this.instance = new lib.m跑();
	this.instance.parent = this;
	this.instance.setTransform(322.2,383.5,0.8,0.8,0,0,0,0,-87);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 地
	this.instance_1 = new lib.l地mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(322.6,452.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Loading
	this.instance_2 = new lib.ltxt();
	this.instance_2.parent = this;
	this.instance_2.setTransform(239.1,368,1,1,0,0,0,53.2,9.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// 背景
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C1C1C").s().p("Egx/BQZMAAAigxMBj/AAAMAAACgxg");
	this.shape.setTransform(320,514.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.loadingClass, new cjs.Rectangle(0,0,744.1,1029), null);


(lib.h头像框星mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(41));

	// Layer 2
	this.instance = new lib.h头像框星_1();
	this.instance.parent = this;
	this.instance.setTransform(13.3,24.5,0.3,0.3);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:1},0).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},4,cjs.Ease.get(1)).to({_off:true},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.h头像框星_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3,0.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.3,scaleY:0.3},5,cjs.Ease.get(1)).to({_off:true},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9.5,20.5,7.5,8.1);


(lib.h头像框尴尬mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49));

	// Layer 1
	this.instance = new lib.h头像框尴尬();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.2,0.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.6,scaleY:0.6,alpha:1},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.6,scaleY:0.6},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.6,scaleY:0.6},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.6,scaleY:0.6},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({scaleX:0.6,scaleY:0.6},5,cjs.Ease.get(1)).to({scaleX:0.2,scaleY:0.2,alpha:0},3,cjs.Ease.get(1)).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.5,6.4);


(lib.logoClass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logo
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(15.8,18.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoClass, new cjs.Rectangle(15.8,18.2,162,24.6), null);


(lib.questionMc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 答题金币
	this.successMc = new lib.答题金币();
	this.successMc.parent = this;
	this.successMc.setTransform(375.3,4);

	this.timeline.addTween(cjs.Tween.get(this.successMc).wait(1));

	// 答错
	this.failMc = new lib.答错mc();
	this.failMc.parent = this;
	this.failMc.setTransform(208.7,183,1,1,0,0,0,191.3,141);

	this.timeline.addTween(cjs.Tween.get(this.failMc).wait(1));

	// 答题背景
	this.questionMc = new lib.答题背景_1();
	this.questionMc.parent = this;
	this.questionMc.setTransform(257.4,192.6);

	this.timeline.addTween(cjs.Tween.get(this.questionMc).wait(1));

}).prototype = getMCSymbolPrototype(lib.questionMc, new cjs.Rectangle(-305,-301,1128,1128), null);


(lib.page5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_30 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(30).call(this.frame_30).wait(1));

	// Layer 2
	this.awardText = new cjs.Text("刘德华仔仔 获得 10 元", "60px 'Microsoft YaHei'", "#FFFFFF");
	this.awardText.name = "awardText";
	this.awardText.textAlign = "center";
	this.awardText.lineHeight = 79;
	this.awardText.lineWidth = 635;
	this.awardText.parent = this;
	this.awardText.setTransform(320.5,190.9);

	this.timeline.addTween(cjs.Tween.get(this.awardText).wait(31));

	// 结算在玩一次
	this.p5Btn = new lib.结算在玩一次();
	this.p5Btn.parent = this;
	this.p5Btn.setTransform(311.6,918.9,0.165,0.165);
	this.p5Btn.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.p5Btn).wait(20).to({alpha:1},0).to({scaleX:1.15,scaleY:1.15},6,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4).wait(1));

	// 结算字1
	this.instance = new lib.结算字1_1();
	this.instance.parent = this;
	this.instance.setTransform(310.8,778.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(6));

	// 结算怪兽
	this.instance_1 = new lib.结算怪兽();
	this.instance_1.parent = this;
	this.instance_1.setTransform(334.9,373.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).to({x:262.9,alpha:1},6,cjs.Ease.get(1)).to({x:275.7},4).wait(15));

	// 结算小男孩
	this.instance_2 = new lib.结算小男孩();
	this.instance_2.parent = this;
	this.instance_2.setTransform(402.8,378.9);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(6).to({_off:false},0).to({x:330.8,alpha:1},6,cjs.Ease.get(1)).to({x:343.6},4).wait(15));

	// 结算房子
	this.instance_3 = new lib.结算房子_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(436.8,398.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({_off:false},0).to({x:364.8,alpha:1},6,cjs.Ease.get(1)).to({x:377.6},4).wait(15));

	// 图层 16 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_6 = new cjs.Graphics().p("EgK7A7uMAAAgwbMAwbAAAMAAAAwbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(6).to({graphics:mask_graphics_6,x:240,y:382.3}).wait(25));

	// 结算二维码
	this.instance_4 = new lib.结算二维码_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(311.1,300.1);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).to({y:600.9},7,cjs.Ease.get(1)).to({y:584.9},4).wait(5));

	// 结算奖金总额
	this.instance_5 = new lib.结算奖金总额_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(312.2,124.5,0.183,0.295);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:1.25,scaleY:1.11},6,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4).wait(21));

	// 图层 2
	this.instance_6 = new lib.结算背景_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(320,519.5,1.01,1.01);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.1,0,646.2,1039);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.h头像框星mc();
	this.instance.parent = this;
	this.instance.setTransform(-9.5,-20.4);

	this.instance_1 = new lib.h头像框尴尬mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-32,24.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,7.5,8.1);


(lib.p4路4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p4灯晕2
	this.instance = new lib.p4灯晕2();
	this.instance.parent = this;
	this.instance.setTransform(94.9,5.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16));

	// p4路4.png
	this.instance_1 = new lib.p4路4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-274.5,-284);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16));

	// p4房4问
	this.instance_2 = new lib.p4房4问();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-161.6,-298);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1.1,scaleY:0.9,y:-320},7,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:-298},8,cjs.Ease.get(-1)).wait(1));

	// Layer 1
	this.instance_3 = new lib.p4灯晕1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(224.3,185.1);

	this.instance_4 = new lib.p4灯晕1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(72.1,-91.5);

	this.instance_5 = new lib.p4灯晕2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(6.6,-26.6);

	this.instance_6 = new lib.p4灯晕1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-78.2,-41.5);

	this.instance_7 = new lib.p4灯晕2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-151.8,-66);

	this.instance_8 = new lib.p4灯晕1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-207.7,-35.4);

	this.instance_9 = new lib.p4灯晕2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-255.1,-96.5);

	this.instance_10 = new lib.p4灯晕1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-271,-172.6);

	this.instance_11 = new lib.p4灯晕2();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-255.1,-242.7);

	this.instance_12 = new lib.p4灯晕1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-203.3,-272);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(16));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-288.4,-354,576.9,708);


(lib.p4路3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p4路3问
	this.instance = new lib.p4路3问_1();
	this.instance.parent = this;
	this.instance.setTransform(5,-48.6,1,1,-15,0,0,1.7,8.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:15},24).to({rotation:-15},25).wait(1));

	// p4路3.png
	this.instance_1 = new lib.p4路3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-160.5,-75);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	// Layer 1
	this.instance_2 = new lib.p4灯晕1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-97.2,5.8,0.55,0.55);

	this.instance_3 = new lib.p4灯晕2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-59.5,-3.9,0.55,0.55);

	this.instance_4 = new lib.p4灯晕1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-25.4,-15.1,0.55,0.55);

	this.instance_5 = new lib.p4灯晕1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(35.9,-29.1,0.55,0.55);

	this.instance_6 = new lib.p4灯晕2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(66.7,-37.3,0.55,0.55);

	this.instance_7 = new lib.p4灯晕1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(91.7,-44.4,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.5,-86.8,321,168.8);


(lib.p4路1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p4路1();
	this.instance.parent = this;
	this.instance.setTransform(6.5,0);

	this.instance_1 = new lib.p4灯晕1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(330.7,18.5);

	this.instance_2 = new lib.p4灯晕2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(219.9,26);

	this.instance_3 = new lib.p4灯晕1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(142.6,67.2);

	this.instance_4 = new lib.p4灯晕2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(73,138.2);

	this.instance_5 = new lib.p4灯晕1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.4,193.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4路1_1, new cjs.Rectangle(0,0,385.5,257), null);


(lib.p4房4mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p4房4();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.2,y:-2.1},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:0},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-66.1,69,132.1);


(lib.p4房3mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p4房3();
	this.instance.parent = this;
	this.instance.setTransform(1.7,14.5,1,1,0,0,0,1.7,14.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.2,x:1.8},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:1.7},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-60,45,120.1);


(lib.p2房3mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p2房3_1();
	this.instance.parent = this;
	this.instance.setTransform(44.5,-63.5,1,1,0,0,0,44.5,-63.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.2},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87,-275.9,174.1,276);


(lib.p2房2mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p2房2_1();
	this.instance.parent = this;
	this.instance.setTransform(13.5,-0.5,1,1,0,0,0,13.5,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.1,scaleY:1.1,x:13.6},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:13.5},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99.6,-188.6,183.4,196.9);


(lib.p2房1mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// Layer 1
	this.instance = new lib.p2房1_1();
	this.instance.parent = this;
	this.instance.setTransform(0,-52.8,1,1,0,0,0,0,-52.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.2,scaleY:1.2,x:-1,y:-53.8},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:0,y:-52.8},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-231,148.3,231);


(lib.p2guide = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ⭐️2故障2
	this.node1 = new lib._2故障2();
	this.node1.parent = this;
	this.node1.setTransform(346.7,539.7,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.node1).wait(1));

	// ⭐️p2爆炸
	this.node2 = new lib.p2爆炸();
	this.node2.parent = this;
	this.node2.setTransform(350,710.6);

	this.timeline.addTween(cjs.Tween.get(this.node2).wait(1));

	// p2路3
	this.instance = new lib.p2路3_1();
	this.instance.parent = this;
	this.instance.setTransform(426,741.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ⭐️p2房3
	this.room3 = new lib.p2房3mc();
	this.room3.parent = this;
	this.room3.setTransform(186,587,1,1,0,0,0,0,-138);

	this.timeline.addTween(cjs.Tween.get(this.room3).wait(1));

	// ⭐️p2房2
	this.room2 = new lib.p2房2mc();
	this.room2.parent = this;
	this.room2.setTransform(470.5,351,1,1,0,0,0,0,-91.5);

	this.timeline.addTween(cjs.Tween.get(this.room2).wait(1));

	// ⭐️p2房1
	this.room1 = new lib.p2房1mc();
	this.room1.parent = this;
	this.room1.setTransform(307,391.2,1,1,0,0,0,0,-109.8);

	this.timeline.addTween(cjs.Tween.get(this.room1).wait(1));

	// p2路2
	this.instance_1 = new lib.p2路2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(217.4,427.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// p2路1
	this.instance_2 = new lib.p2路1_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(133,404.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// bg2.jpg
	this.instance_3 = new lib.bg2();
	this.instance_3.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2guide, new cjs.Rectangle(0,0,640,1029), null);


(lib.p1mmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.p1m();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.02,scaleY:0.98},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(-1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-121,-379.7,242,379.7);


(lib.page1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stage.mouseChildren=this.stage.mouseEnable=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// p1mmc
	this.instance = new lib.p1mmc();
	this.instance.parent = this;
	this.instance.setTransform(214.6,455.3,1,1,0,0,0,0,-182.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// p1飞船
	this.instance_1 = new lib.p1飞船mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(533,106);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// p1房子
	this.instance_2 = new lib.p1房子mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(511,287);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// p1txt
	this.instance_3 = new lib.p1txt();
	this.instance_3.parent = this;
	this.instance_3.setTransform(151.1,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// ⭐️p1bt
	this.goBtn = new lib.p1bt();
	this.goBtn.parent = this;
	this.goBtn.setTransform(318.9,900.8,1,1,0,0,0,0,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.goBtn).wait(1));

	// bg1
	this.instance_4 = new lib.bg1();
	this.instance_4.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.page1, new cjs.Rectangle(0,0,640,1098), null);


(lib.p4怪兽mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{扔炸弹:115,转身:130,扔障碍:205,转身1:254});

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}
	this.frame_324 = function() {
		this.stop();
		this.dispatchEvent(new Event("monsterRunComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(300).call(this.frame_324).wait(1));

	// monster
	this.monsterMc = new lib.monster();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(-293,-89.1,1,1,-15);

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).to({rotation:0,guide:{path:[-293,-89.2,-223.4,-116.1,-136.4,-208.7,-46.8,-304.4,32.6,-298.4]}},62).to({rotation:30,guide:{path:[32.7,-298.4,55.9,-296.6,78.3,-286.2,162.5,-246.8,244.8,-192.1]}},37).to({rotation:3.3,guide:{path:[244.8,-192.1,259,-182.7,273.1,-172.8,353.6,-116.5,338.5,-32.8]}},31).to({rotation:-20,guide:{path:[338.5,-32.7,335.6,-16.7,329.2,0.4,262.8,48.1,265.2,-65.1]}},32).to({rotation:0,guide:{path:[265.2,-65,265.3,-69.2,265.5,-73.7,98.2,60.6,-70.7,8.9,-97.5,28.3,-127,29.8,-170.8,31.4,-185.1,53.2]}},92).to({guide:{path:[-185.1,53.2,-206.2,85.2,-163.8,160.9,-108.5,259.5,26.7,272.9]}},69).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-377.6,-240.9,132,164.5);


(lib.p3怪兽mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"转身":89,"扔炸弹":93,"转身1":149,"扔障碍":244});

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}
	this.frame_299 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(275).call(this.frame_299).wait(1));

	// monster
	this.monsterMc = new lib.monster();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(-344.2,205.4);

	this.instance = new lib.monster("single",2);
	this.instance.parent = this;
	this.instance.setTransform(52.4,198.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).to({rotation:25,guide:{path:[-344.1,205.4,-248.5,189.5,-153,225.3]}},39).to({rotation:4,guide:{path:[-152.9,225.4,-146,228,-139,230.9,-67.6,264.6,-23.6,257.4]}},28).to({_off:true,rotation:0,guide:{path:[-23.5,257.5,-4.4,254.4,9.4,243.7,42.9,220.8,52.4,198.3]},mode:"single",startPosition:2},22).to({_off:false,rotation:-10,guide:{path:[52.4,198.2,72,151.8,-11,107.1,-54.4,76.8,-76.3,-0.8]},mode:"independent"},60).to({rotation:0,guide:{path:[-76.3,-0.9,-77.3,-4.6,-78.3,-8.4,-84.4,-36.4,-76.2,-49.3,-68,-62.2,-51.3,-105.9,-34.7,-149.7,-10.1,-170.1,14.4,-190.5,44.8,-191.4,75.1,-192.3,98.1,-199.9,102.1,-201.2,106.9,-201.4]}},75).to({rotation:30,guide:{path:[106.9,-201.4,129.8,-202.1,171.3,-176.3,177.6,-172.3,183.7,-168.9]}},20).to({rotation:-15,guide:{path:[183.8,-168.8,226,-145.1,258.3,-146.3,295.3,-147.7,333,-171.1,361.7,-188.9,405.8,-202.6]}},55).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(67).to({_off:false},22).to({_off:true,rotation:-10,guide:{path:[52.4,198.2,72,151.8,-11,107.1,-54.4,76.8,-76.3,-0.8]},mode:"independent"},60).wait(151));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-393.2,61.4,98,144);


(lib._2问号_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2问号();
	this.instance.parent = this;
	this.instance.setTransform(-10.5,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 2
	this.instance_1 = new lib._2灯晕1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._2问号_1, new cjs.Rectangle(-17.4,-17.4,34.8,34.8), null);


(lib._2道路第三段 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2道路3();
	this.instance.parent = this;
	this.instance.setTransform(-128.5,-86);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 2
	this.instance_1 = new lib._2彩灯();
	this.instance_1.parent = this;
	this.instance_1.setTransform(112.7,-35.6);

	this.instance_2 = new lib._2彩灯闪2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(97.8,-40);

	this.instance_3 = new lib._2彩灯();
	this.instance_3.parent = this;
	this.instance_3.setTransform(81.9,-47.6);

	this.instance_4 = new lib._2彩灯闪2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(70,-57.8);

	this.instance_5 = new lib._2彩灯();
	this.instance_5.parent = this;
	this.instance_5.setTransform(12,-57.8);

	this.instance_6 = new lib._2彩灯闪2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-2.1,-52.5);

	this.instance_7 = new lib._2彩灯();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-18.6,-47.6);

	this.instance_8 = new lib._2彩灯闪2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-36.4,-43.7);

	this.instance_9 = new lib._2彩灯();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-57.3,-41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib._2道路第三段, new cjs.Rectangle(-128.5,-86,257,172), null);


(lib._2道路1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2道路1();
	this.instance.parent = this;
	this.instance.setTransform(-156,-84.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 2
	this.instance_1 = new lib._2灯晕2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(90,-30);

	this.instance_2 = new lib._2灯晕1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(70,-30);

	this.instance_3 = new lib._2灯晕2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-38.4,-68.8);

	this.instance_4 = new lib._2灯晕1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-18,-68.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib._2道路1_1, new cjs.Rectangle(-156,-86.2,312,170.7), null);


(lib.p2怪兽mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"转身":145,"扔障碍":214,"转身1":229,"扔炸弹":267});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_34 = function() {
		this.stop();
	}
	this.frame_324 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(290).call(this.frame_324).wait(1));

	// monster
	this.monsterMc = new lib.monster();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(-369,-126);

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).to({rotation:25,guide:{path:[-368.9,-126.8,-281.4,-127.4,-248.9,-91.9,-235.4,-84.9,-222.5,-79.8]}},34).to({scaleX:1,scaleY:1,rotation:-10,guide:{path:[-222.5,-79.9,-182.8,-64.4,-148.8,-67.6,-130,-70.6,-111.1,-73.5]}},25).to({rotation:35,guide:{path:[-111,-73.5,-108.3,-74,-105.5,-74.4,-92.8,-48.8,-80.1,-33.8]}},11).to({scaleX:1,scaleY:1,rotation:0,guide:{path:[-80.1,-33.8,-72.6,-24.9,-65.1,-19.7,-18.5,-7.5,28.1,4.7,48.7,17.6,128.8,13.1,231.7,12.9,253.5,47.3]}},75).to({rotation:0.2,guide:{path:[253.6,47.5,258.4,55.1,259.3,64.4,256.8,87.9,212.5,97.9,168.2,107.8,82.1,104.2,-82.7,102.3,-86.2,195.2]}},84).to({rotation:0.1,guide:{path:[-86.2,195.1,-86.4,202.7,-85.6,211,-76.9,246,-35.1,258.8,6.8,271.6,81.8,262.2]}},38).to({rotation:0.2,guide:{path:[81.9,262.3,132.9,255.9,199.1,239.3,304.5,214,372.5,227]}},57).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-418,-270,98,144);


(lib.h头像框_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ⭐️星星
	this.expressionMc = new lib.Symbol6();
	this.expressionMc.parent = this;
	this.expressionMc.setTransform(67,-143.2,1,1,0,0,0,-1,-6.2);

	this.timeline.addTween(cjs.Tween.get(this.expressionMc).wait(1));

	// h头像框.png
	this.headContainor = new lib.Symbol7();
	this.headContainor.parent = this;
	this.headContainor.setTransform(0,-80,1,1,0,0,0,60.5,80);

	this.timeline.addTween(cjs.Tween.get(this.headContainor).wait(1));

}).prototype = getMCSymbolPrototype(lib.h头像框_1, new cjs.Rectangle(-60.5,-160,136,160), null);


(lib.human = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 2
	this.headBox = new lib.h头像框_1();
	this.headBox.parent = this;
	this.headBox.setTransform(0,-111.5);

	this.timeline.addTween(cjs.Tween.get(this.headBox).wait(4));

	// h转
	this.instance = new lib.h转();
	this.instance.parent = this;
	this.instance.setTransform(0.2,13.5,1,1,0,0,180);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({alpha:1},0).wait(1));

	// h跑
	this.angleMc2 = new lib.h跑();
	this.angleMc2.parent = this;
	this.angleMc2.setTransform(0.2,13.5,1,1,0,0,180);
	this.angleMc2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.angleMc2).wait(2).to({alpha:1},0).to({_off:true},1).wait(1));

	// h转
	this.instance_1 = new lib.h转();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.2,13.5);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:1},0).to({_off:true},1).wait(2));

	// h跑
	this.angleMc1 = new lib.h跑();
	this.angleMc1.parent = this;
	this.angleMc1.setTransform(0.2,13.5);

	this.timeline.addTween(cjs.Tween.get(this.angleMc1).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.5,-271.5,136,271.5);


(lib.page6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// ⭐️教程跑
	this.instance = new lib.教程跑();
	this.instance.parent = this;
	this.instance.setTransform(318.8,868.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// ⭐️教程跳
	this.instance_1 = new lib.教程跳();
	this.instance_1.parent = this;
	this.instance_1.setTransform(322.8,869.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.647)").s().p("Eg0zBIqMAAAiRTMBpnAAAMAAACRTg");
	this.shape.setTransform(323.1,519.5,0.956,1.117);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer 3
	this.instance_2 = new lib.p2guide();
	this.instance_2.parent = this;
	this.instance_2.setTransform(267.8,519.5,1.01,1.01,0,0,0,265.2,514.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,646.3,1039);


(lib.page3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.p3Btn2 = new lib.Symbol2();
	this.p3Btn2.parent = this;
	this.p3Btn2.setTransform(431.5,891.5,1,1,0,0,0,46.5,63.5);

	this.p3Btn1 = new lib.Symbol1();
	this.p3Btn1.parent = this;
	this.p3Btn1.setTransform(205.5,892,1,1,0,0,0,46.5,64);

	this.instance = new lib.human();
	this.instance.parent = this;
	this.instance.setTransform(564.4,227.6,1,1,0,0,0,-0.1,-48.9);

	this.instance_1 = new lib.椭圆2拷贝3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(16,154);

	this.instance_2 = new lib.录入头像游戏更精彩();
	this.instance_2.parent = this;
	this.instance_2.setTransform(310,62);

	this.instance_3 = new lib.图层190();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,1,1.01);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.p3Btn1},{t:this.p3Btn2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.page3, new cjs.Rectangle(0,0,640,1039), null);


(lib.p4人mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{问题1:73,出现1:89,停1:99,复活1:116,问题2:129,"转身":130,出现2:171,停2:190,复活2:207,问题3:224,出现3:241,"转身1":254});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_324 = function() {
		this.stop();
		this.dispatchEvent(new Event("ManRunComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(324).call(this.frame_324).wait(1));

	// monster
	this.manMc = new lib.human();
	this.manMc.parent = this;
	this.manMc.setTransform(-291.8,-86.1,1,1,-15);

	this.timeline.addTween(cjs.Tween.get(this.manMc).to({rotation:0,guide:{path:[-291.8,-86.1,-226.7,-109.3,-143.9,-202.7,-63.1,-293.9,31.9,-291.1]}},62).to({rotation:30,guide:{path:[32,-291,70.2,-289.9,110.6,-273.6,177.9,-233.9,245.3,-194.2]}},37).to({rotation:3.3,guide:{path:[245.3,-194.2,247.4,-193,249.5,-191.8,361.5,-125.9,340.3,-32.4]}},31).to({rotation:-20,guide:{path:[340.3,-32.3,336.7,-16.4,329.2,0.4,262.8,48.1,265.2,-65.1]}},32).to({rotation:0,guide:{path:[265.2,-65.1,265.3,-69.3,265.5,-73.7,123.6,46.1,-70.7,8.8,-97.5,28.2,-127,29.7,-170.8,31.3,-185.1,53.1]}},92).to({guide:{path:[-185.1,53.2,-206.2,85.2,-163.8,160.8,-108.4,259.6,26.4,277.2]}},69).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-420.5,-363.9,167.2,288.1);


(lib.p3人mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"问题1":64,"出现1":77,"停1":80,"转身":89,"复活1":99,"转身1":149,"问题2":189,"问题2":192,"出现2":222,"停2":231,"复活2":255});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_299 = function() {
		this.stop();
		this.dispatchEvent(new Event("ManRunComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(299).call(this.frame_299).wait(1));

	// monster
	this.manMc = new lib.human();
	this.manMc.parent = this;
	this.manMc.setTransform(-344.2,207.4);

	this.timeline.addTween(cjs.Tween.get(this.manMc).to({rotation:25,guide:{path:[-344.1,207.4,-248.5,191.5,-153,227.3]}},39).to({rotation:4,guide:{path:[-152.9,227.4,-146,230,-139,232.9,-67.6,266.6,-23.6,259.4]}},28).to({rotation:0,guide:{path:[-23.5,259.5,-4.4,256.4,9.4,245.7,42.9,222.8,52.4,200.3]}},22).to({rotation:-10,guide:{path:[52.4,200.2,72,153.8,-11,109.1,-54.4,78.8,-76.3,1.2]}},60).to({rotation:0,guide:{path:[-76.3,1.1,-77.3,-2.6,-78.3,-6.4,-84.4,-34.4,-76.2,-47.3,-68,-60.2,-51.3,-103.9,-34.7,-147.7,-10.1,-168.1,14.4,-188.5,44.8,-189.4,75.1,-190.3,98.1,-197.9,102.1,-199.2,106.9,-199.4]}},75).to({rotation:30,guide:{path:[106.9,-199.4,129.8,-200.1,171.3,-174.3,177.6,-170.3,183.7,-166.9]}},20).to({rotation:-15,guide:{path:[183.8,-166.8,226,-143.1,258.3,-144.3,295.3,-145.7,333,-169.1,361.7,-186.9,405.8,-200.6]}},55).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-404.7,-64.1,136,271.5);


(lib._2问号动 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib._2问号_1();
	this.instance.parent = this;
	this.instance.setTransform(1.9,11.5,1,1,-4.7,0,0,1.9,11.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:10.7},9).to({rotation:-4.7},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.7,-18.6,37.6,37.6);


(lib._2房子2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// 第二段问号动
	this.instance = new lib._2问号动();
	this.instance.parent = this;
	this.instance.setTransform(-37.3,-89.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.29,scaleY:1.29,x:-45.1,y:-125.3},5).to({scaleX:1,scaleY:1,x:-37.3,y:-89.6},5).wait(1));

	// 第二段问号动
	this.instance_1 = new lib._2问号动();
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.5,-97.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.29,scaleY:1.29,x:6.2,y:-135},5).to({scaleX:1,scaleY:1,x:2.5,y:-97.1},5).wait(1));

	// 图层 1
	this.instance_2 = new lib._2房子2动();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,-1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1.29,scaleY:1.29,x:3,y:-11.9},5).to({scaleX:1,scaleY:1,x:0,y:-1.6},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71,-115.7,142,187.6);


(lib._2房子1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11));

	// 图层 3
	this.instance = new lib._2问号动();
	this.instance.parent = this;
	this.instance.setTransform(-15.5,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.27,scaleY:1.27,x:-22.4,y:-102},5).to({scaleX:1,scaleY:1,x:-15.5,y:-76},5).wait(1));

	// 图层 1
	this.instance_1 = new lib._2房子1动();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.27,scaleY:1.27,x:-2.7,y:-5.4},5).to({scaleX:1,scaleY:1,x:0,y:0},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.2,-94.6,70.3,154.6);


(lib.p2人mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"问题1":74,"出现1":94,"问题2":119,"出现2":130,"转身":149,"停1":186,"复活1":209,"问题3":222,"转身1":229,"出现3":235,"停2":248,"复活2":267});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_324 = function() {
		this.stop();
		this.dispatchEvent(new Event("ManRunComplete"));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(323).call(this.frame_324).wait(1));

	// monster
	this.manMc = new lib.human();
	this.manMc.parent = this;
	this.manMc.setTransform(-369,-126);

	this.timeline.addTween(cjs.Tween.get(this.manMc).to({scaleX:1,scaleY:1,rotation:25,guide:{path:[-368.9,-126.8,-281.4,-127.4,-248.9,-91.9,-236.2,-83.6,-223.8,-77.5]}},34).to({rotation:-10,guide:{path:[-223.9,-77.6,-183,-57.6,-146.9,-61.6,-129.2,-68,-111.6,-74.4,-111.6,-74.4,-111.6,-74.4]}},25).to({scaleX:1,scaleY:1,rotation:35,guide:{path:[-111.5,-74.4,-94.9,-48.6,-80.6,-33.6]}},11).to({scaleX:1,scaleY:1,rotation:0,guide:{path:[-80.6,-33.5,-72.5,-24.9,-65.2,-19.7,-18.6,-7.5,28,4.6,47.5,16.9,120.7,13.5]}},44).to({guide:{path:[120.7,13.5,124.6,13.3,128.8,13.1,136.5,13.1,143.8,13.3]}},5).to({scaleX:1,scaleY:1,guide:{path:[143.9,13.4,233.4,15.6,253.6,47.4]}},26).to({rotation:0.1,guide:{path:[253.6,47.4,258.4,55,259.2,64.3,256.7,87.9,212.4,97.9,168.2,107.9,82.1,104.2,-49,102.7,-78,161]}},77).to({rotation:0.2,guide:{path:[-78,161.1,-85.5,176.1,-86.2,195.2]}},7).to({guide:{path:[-86.2,195.1,-86.5,202.7,-85.7,211,-74,257.9,-2.8,264.9,68.4,272,199.1,239.2,304.5,213.9,372.4,226.9]}},95).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-429.5,-397.5,136,271.5);


(lib.p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p4人mc
	this.manMc = new lib.p4人mc();
	this.manMc.parent = this;
	this.manMc.setTransform(241.6,392.6,1,1,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.manMc).wait(1));

	// p4怪兽mc
	this.monsterMc = new lib.p4怪兽mc();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(241.6,392.6,1,1,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).wait(1));

	// ⭐️2故障2
	this.node2 = new lib._2故障2();
	this.node2.parent = this;
	this.node2.setTransform(252,388.1,1,1,0,0,180,85.4,-8.4);

	this.timeline.addTween(cjs.Tween.get(this.node2).wait(1));

	// ⭐️p4爆炸
	this.node1 = new lib.p4爆炸();
	this.node1.parent = this;
	this.node1.setTransform(618.9,181.8,1,1,0,0,0,88.5,-42);

	this.timeline.addTween(cjs.Tween.get(this.node1).wait(1));

	// ⭐️完成
	this.completeMc = new lib.p4tvmc();
	this.completeMc.parent = this;
	this.completeMc.setTransform(378,573.5,1,1,0,0,0,-139.1,84.5);

	this.timeline.addTween(cjs.Tween.get(this.completeMc).wait(1));

	// 潜水艇
	this.instance = new lib.p4潜水艇mc();
	this.instance.parent = this;
	this.instance.setTransform(569.1,756.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ⭐️房4
	this.room3 = new lib.p4房4mc();
	this.room3.parent = this;
	this.room3.setTransform(161.5,410);

	this.timeline.addTween(cjs.Tween.get(this.room3).wait(1));

	// 路4
	this.instance_1 = new lib.p4路4_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(291.6,675);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// 路3
	this.instance_2 = new lib.p4路3_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(350.5,399.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// ⭐️房2
	this.room2 = new lib.p4房2mc();
	this.room2.parent = this;
	this.room2.setTransform(543.6,431.5);

	this.timeline.addTween(cjs.Tween.get(this.room2).wait(1));

	// ⭐️房3
	this.instance_3 = new lib.p4房3mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(508.6,320.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// 路2
	this.instance_4 = new lib.p4路2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(377.1,138);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// ⭐️房1
	this.room1 = new lib.p4房1mc();
	this.room1.parent = this;
	this.room1.setTransform(381.5,114,1,1,0,0,0,0,-59);

	this.timeline.addTween(cjs.Tween.get(this.room1).wait(1));

	// 路1
	this.instance_5 = new lib.p4路1_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(186.3,186.5,1,1,0,0,0,192.8,128.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// bg4.jpg
	this.instance_6 = new lib.bg4();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4, new cjs.Rectangle(-179.1,0,819.1,1029), null);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p2怪兽mc
	this.monsterMc = new lib.p2怪兽mc();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(320.3,449.8,1,1,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).wait(1));

	// p2人mc
	this.manMc = new lib.p2人mc();
	this.manMc.parent = this;
	this.manMc.setTransform(320.3,449.8,1,1,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.manMc).wait(1));

	// ⭐️2故障2
	this.node1 = new lib._2故障2();
	this.node1.parent = this;
	this.node1.setTransform(346.7,539.7,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.node1).wait(1));

	// ⭐️p2爆炸
	this.node2 = new lib.p2爆炸();
	this.node2.parent = this;
	this.node2.setTransform(350,710.6);

	this.timeline.addTween(cjs.Tween.get(this.node2).wait(1));

	// p2路3
	this.instance = new lib.p2路3_1();
	this.instance.parent = this;
	this.instance.setTransform(426,741.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ⭐️p2房3
	this.room3 = new lib.p2房3mc();
	this.room3.parent = this;
	this.room3.setTransform(186,587,1,1,0,0,0,0,-138);

	this.timeline.addTween(cjs.Tween.get(this.room3).wait(1));

	// ⭐️p2房2
	this.room2 = new lib.p2房2mc();
	this.room2.parent = this;
	this.room2.setTransform(470.5,351,1,1,0,0,0,0,-91.5);

	this.timeline.addTween(cjs.Tween.get(this.room2).wait(1));

	// ⭐️p2房1
	this.room1 = new lib.p2房1mc();
	this.room1.parent = this;
	this.room1.setTransform(307,391.2,1,1,0,0,0,0,-109.8);

	this.timeline.addTween(cjs.Tween.get(this.room1).wait(1));

	// p2路2
	this.instance_1 = new lib.p2路2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(217.4,427.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// p2路1
	this.instance_2 = new lib.p2路1_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(133,404.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// bg2.jpg
	this.instance_3 = new lib.bg2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-7,0,1.01,1.01);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2, new cjs.Rectangle(-109.5,0,749.5,1039), null);


(lib._2游戏 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p3人mc
	this.manMc = new lib.p3人mc();
	this.manMc.parent = this;
	this.manMc.setTransform(-285.2,-52.5);

	this.timeline.addTween(cjs.Tween.get(this.manMc).wait(1));

	// p3怪兽mc
	this.monsterMc = new lib.p3怪兽mc();
	this.monsterMc.parent = this;
	this.monsterMc.setTransform(-285.2,-52.5);

	this.timeline.addTween(cjs.Tween.get(this.monsterMc).wait(1));

	// ⭐️路障
	this.node2 = new lib._2故障2();
	this.node2.parent = this;
	this.node2.setTransform(-105.7,-233.2);

	this.timeline.addTween(cjs.Tween.get(this.node2).wait(1));

	// ⭐️p3爆炸
	this.node1 = new lib.p3爆炸();
	this.node1.parent = this;
	this.node1.setTransform(-224.8,126.6);

	this.timeline.addTween(cjs.Tween.get(this.node1).wait(1));

	// 2道路1
	this.instance = new lib._2道路1_1();
	this.instance.parent = this;
	this.instance.setTransform(-424.5,216.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ⭐️2房子1
	this.room1 = new lib._2房子1_1();
	this.room1.parent = this;
	this.room1.setTransform(-284.7,192.5);

	this.timeline.addTween(cjs.Tween.get(this.room1).wait(1));

	// 2道路2
	this.instance_1 = new lib._2道路2_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-305.1,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// ⭐️2房子2
	this.room2 = new lib._2房子2_1();
	this.room2.parent = this;
	this.room2.setTransform(-240.2,-257.2);

	this.timeline.addTween(cjs.Tween.get(this.room2).wait(1));

	// 2飞碟和梯子
	this.instance_2 = new lib._2飞碟和梯子();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-164.7,-197.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// 2道路第三段
	this.instance_3 = new lib._2道路第三段();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-69,-208.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// 2背景
	this.instance_4 = new lib._2背景_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-260.5,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._2游戏, new cjs.Rectangle(-689.9,-515,749.5,1029), null);


(lib.page4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.moneyMc = new lib.答题固定金币();
	this.moneyMc.parent = this;
	this.moneyMc.setTransform(594.6,56.7,1,1,0,0,0,0.6,11.7);

	this.gameBtn = new lib.Symbol2_1();
	this.gameBtn.parent = this;
	this.gameBtn.setTransform(320.9,911.2,1,1,0,0,0,40.6,35.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.gameBtn},{t:this.moneyMc}]}).wait(3));

	// p2
	this.level1 = new lib.p2();
	this.level1.parent = this;
	this.level1.setTransform(320,514.5,1,1,0,0,0,320,514.5);

	this.timeline.addTween(cjs.Tween.get(this.level1).to({_off:true},1).wait(2));

	// p3
	this.level2 = new lib._2游戏();
	this.level2.parent = this;
	this.level2.setTransform(580.5,515);
	this.level2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.level2).wait(1).to({scaleX:1.01,scaleY:1.01,y:519,alpha:1},0).to({_off:true},1).wait(1));

	// p4
	this.level3 = new lib.p4();
	this.level3.parent = this;
	this.level3.setTransform(320,514.5,1,1,0,0,0,320,514.5);
	this.level3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.level3).wait(2).to({scaleX:1.01,scaleY:1.01,x:323.1,y:519.5,alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179.1,0,824.2,1039);


// stage content:
(lib.game = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;
// library properties:
lib.properties = {
	width: 640,
	height: 1029,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/_2房子1.png?1494579046039", id:"_2房子1"},
		{src:"images/_2房子2.png?1494579046039", id:"_2房子2"},
		{src:"images/_2梯子.png?1494579046039", id:"_2梯子"},
		{src:"images/_2爆炸.png?1494579046039", id:"_2爆炸"},
		{src:"images/_2爆炸后.jpg?1494579046039", id:"_2爆炸后"},
		{src:"images/_2碎片1.png?1494579046039", id:"_2碎片1"},
		{src:"images/_2碎片2.png?1494579046039", id:"_2碎片2"},
		{src:"images/_2碎片3.png?1494579046039", id:"_2碎片3"},
		{src:"images/_2碎片4.png?1494579046039", id:"_2碎片4"},
		{src:"images/_2碎片5.png?1494579046039", id:"_2碎片5"},
		{src:"images/_2碎片6.png?1494579046039", id:"_2碎片6"},
		{src:"images/_2背景.jpg?1494579046039", id:"_2背景"},
		{src:"images/_2道路1.png?1494579046039", id:"_2道路1"},
		{src:"images/_2道路2.png?1494579046039", id:"_2道路2"},
		{src:"images/_2道路3.png?1494579046039", id:"_2道路3"},
		{src:"images/_2问号.png?1494579046039", id:"_2问号"},
		{src:"images/_2障碍2.png?1494579046039", id:"_2障碍2"},
		{src:"images/_2飞碟.png?1494579046039", id:"_2飞碟"},
		{src:"images/bg1_1.jpg?1494579046039", id:"bg1_1"},
		{src:"images/bg2.jpg?1494579046039", id:"bg2"},
		{src:"images/bg4.png?1494579046039", id:"bg4"},
		{src:"images/h头像框.png?1494579046039", id:"h头像框"},
		{src:"images/h头像框星.png?1494579046039", id:"h头像框星"},
		{src:"images/L地.png?1494579046039", id:"L地"},
		{src:"images/m炸弹.png?1494579046039", id:"m炸弹"},
		{src:"images/m跑1.png?1494579046039", id:"m跑1"},
		{src:"images/m跑2.png?1494579046039", id:"m跑2"},
		{src:"images/m跑3.png?1494579046039", id:"m跑3"},
		{src:"images/m跑4.png?1494579046039", id:"m跑4"},
		{src:"images/m跑5.png?1494579046039", id:"m跑5"},
		{src:"images/m转1.png?1494579046039", id:"m转1"},
		{src:"images/m转2.png?1494579046039", id:"m转2"},
		{src:"images/p1m呆毛.png?1494579046039", id:"p1m呆毛"},
		{src:"images/p1m嘴.png?1494579046039", id:"p1m嘴"},
		{src:"images/p1m身.png?1494579046039", id:"p1m身"},
		{src:"images/p1txt.png?1494579046039", id:"p1txt"},
		{src:"images/p1房子.png?1494579046039", id:"p1房子"},
		{src:"images/p1飞船.png?1494579046039", id:"p1飞船"},
		{src:"images/p2房1.png?1494579046039", id:"p2房1"},
		{src:"images/p2房2.png?1494579046039", id:"p2房2"},
		{src:"images/p2房3.png?1494579046039", id:"p2房3"},
		{src:"images/p2房3旗子.png?1494579046039", id:"p2房3旗子"},
		{src:"images/p2洞.jpg?1494579046039", id:"p2洞"},
		{src:"images/p2路1.png?1494579046039", id:"p2路1"},
		{src:"images/p2路2.png?1494579046039", id:"p2路2"},
		{src:"images/p2路3.png?1494579046039", id:"p2路3"},
		{src:"images/p2问号.png?1494579046039", id:"p2问号"},
		{src:"images/p4_房1.png?1494579046039", id:"p4_房1"},
		{src:"images/p4_房2.png?1494579046039", id:"p4_房2"},
		{src:"images/p4_房3.png?1494579046039", id:"p4_房3"},
		{src:"images/p4_房4.png?1494579046039", id:"p4_房4"},
		{src:"images/p4_房4问.png?1494579046039", id:"p4_房4问"},
		{src:"images/p4_潜水艇.png?1494579046039", id:"p4_潜水艇"},
		{src:"images/p4路1.png?1494579046039", id:"p4路1"},
		{src:"images/p4路2.png?1494579046039", id:"p4路2"},
		{src:"images/p4路2洞.jpg?1494579046039", id:"p4路2洞"},
		{src:"images/p4路3.png?1494579046039", id:"p4路3"},
		{src:"images/p4路3问.png?1494579046039", id:"p4路3问"},
		{src:"images/p4路4.png?1494579046039", id:"p4路4"},
		{src:"images/p4路4完成.png?1494579046039", id:"p4路4完成"},
		{src:"images/qrcode.png?1494579046039", id:"qrcode"},
		{src:"images/人手1.png?1494579046039", id:"人手1"},
		{src:"images/人手2.png?1494579046039", id:"人手2"},
		{src:"images/人腿1.png?1494579046039", id:"人腿1"},
		{src:"images/人腿2.png?1494579046039", id:"人腿2"},
		{src:"images/人身_.png?1494579046039", id:"人身"},
		{src:"images/人转手1.png?1494579046039", id:"人转手1"},
		{src:"images/人转手2.png?1494579046039", id:"人转手2"},
		{src:"images/人转腿1.png?1494579046039", id:"人转腿1"},
		{src:"images/人转腿2.png?1494579046039", id:"人转腿2"},
		{src:"images/人转身_.png?1494579046039", id:"人转身"},
		{src:"images/叉子_.png?1494579046039", id:"叉子"},
		{src:"images/固定金币_.png?1494579046039", id:"固定金币"},
		{src:"images/图层190.png?1494579046039", id:"图层190"},
		{src:"images/录入头像游戏更精彩_.png?1494579046039", id:"录入头像游戏更精彩"},
		{src:"images/拍照_.png?1494579046039", id:"拍照"},
		{src:"images/教程字1.png?1494579046039", id:"教程字1"},
		{src:"images/教程字2.png?1494579046039", id:"教程字2"},
		{src:"images/椭圆2拷贝3.png?1494579046039", id:"椭圆2拷贝3"},
		{src:"images/答题背景_.png?1494579046039", id:"答题背景"},
		{src:"images/答题道道_.png?1494579046039", id:"答题道道"},
		{src:"images/答题金币1.png?1494579046039", id:"答题金币1"},
		{src:"images/答题金币2.png?1494579046039", id:"答题金币2"},
		{src:"images/结算二维码_.png?1494579046039", id:"结算二维码"},
		{src:"images/结算人头1.png?1494579046039", id:"结算人头1"},
		{src:"images/结算人头2.png?1494579046039", id:"结算人头2"},
		{src:"images/结算人手_.png?1494579046039", id:"结算人手"},
		{src:"images/结算人身_.png?1494579046039", id:"结算人身"},
		{src:"images/结算再玩一次_.png?1494579046039", id:"结算再玩一次"},
		{src:"images/结算奖金总额_.png?1494579046039", id:"结算奖金总额"},
		{src:"images/结算字1.png?1494579046039", id:"结算字1"},
		{src:"images/结算怪物1.png?1494579046039", id:"结算怪物1"},
		{src:"images/结算怪物2.png?1494579046039", id:"结算怪物2"},
		{src:"images/结算怪物3.png?1494579046039", id:"结算怪物3"},
		{src:"images/结算怪物4.png?1494579046039", id:"结算怪物4"},
		{src:"images/结算房子_.png?1494579046039", id:"结算房子"},
		{src:"images/结算背景_.jpg?1494579046039", id:"结算背景"},
		{src:"images/继续_.png?1494579046039", id:"继续"},
		{src:"images/跳过_.png?1494579046039", id:"跳过"},
		{src:"images/错怪兽_.png?1494579046039", id:"错怪兽"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;