/**
 * Created by cheilchina on 2016/12/14.
 */
var GameJs = (function () {

    var init = function () {
        exportRoot.gameView.gotoAndStop(0);
        setTimeout(function () {
            exportRoot.gameView.gotoAndStop(0);
            exportRoot.gameView.btn.addEventListener("click", level1)
        }, 1000)
    }

    function level1() {
        setTimeout(function () {
            exportRoot.gameView.gotoAndPlay(1);

            GUtil.addFrameEvent(exportRoot.gameView, 'showIcon', function () {
                exportRoot.gameView.icon.gotoAndStop(0);
            })
            GUtil.addFrameEvent(exportRoot.gameView, 'level1Complete', function () {
                exportRoot.gameView.contentImage.gotoAndStop(0);
                // stop(exportRoot.gameView.contentImage, 0);
            })
        })
    }

    function stop(mc, num) {
        if (mc) {
            for (; ;) {
                if (mc.currentFrame != num) {
                    mc.gotoAndStop(num);
                } else {
                    break;
                }
            }

        }
    }

    return {
        init: init
    }
})()