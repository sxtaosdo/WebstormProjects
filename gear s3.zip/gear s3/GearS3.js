(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.a1_bt1 = function() {
	this.initialize(img.a1_bt1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,156,39);


(lib.a1_bt2 = function() {
	this.initialize(img.a1_bt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,156,39);


(lib.a1_jiantou = function() {
	this.initialize(img.a1_jiantou);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,35,102);


(lib.a1_line = function() {
	this.initialize(img.a1_line);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,620,2);


(lib.a1_point = function() {
	this.initialize(img.a1_point);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.a1_shou = function() {
	this.initialize(img.a1_shou);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,47,51);


(lib.a1_slg = function() {
	this.initialize(img.a1_slg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,586,195);


(lib.a1_txt = function() {
	this.initialize(img.a1_txt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,29);


(lib.a2_di1guan = function() {
	this.initialize(img.a2_di1guan);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,127,37);


(lib.a2_di2guan = function() {
	this.initialize(img.a2_di2guan);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,127,38);


(lib.a2_di3guan = function() {
	this.initialize(img.a2_di3guan);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,127,38);


(lib.bg_black = function() {
	this.initialize(img.bg_black);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.cp1 = function() {
	this.initialize(img.cp1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,476,796);


(lib.cp2 = function() {
	this.initialize(img.cp2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,451,453);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,117,18);


(lib.表盘10 = function() {
	this.initialize(img.表盘10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,62);


(lib.表盘11 = function() {
	this.initialize(img.表盘11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,58);


(lib.表盘11bg = function() {
	this.initialize(img.表盘11bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘11txt2 = function() {
	this.initialize(img.表盘11txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,391,106);


(lib.表盘11大 = function() {
	this.initialize(img.表盘11大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,337,337);


(lib.表盘12 = function() {
	this.initialize(img.表盘12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘13 = function() {
	this.initialize(img.表盘13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,59);


(lib.表盘13bg = function() {
	this.initialize(img.表盘13bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘13txt2 = function() {
	this.initialize(img.表盘13txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,464,105);


(lib.表盘13大 = function() {
	this.initialize(img.表盘13大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,337,337);


(lib.表盘14 = function() {
	this.initialize(img.表盘14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘15 = function() {
	this.initialize(img.表盘15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘16 = function() {
	this.initialize(img.表盘16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘17 = function() {
	this.initialize(img.表盘17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘18 = function() {
	this.initialize(img.表盘18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,58);


(lib.表盘18bg = function() {
	this.initialize(img.表盘18bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘18txt2 = function() {
	this.initialize(img.表盘18txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,390,103);


(lib.表盘18大 = function() {
	this.initialize(img.表盘18大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,337,337);


(lib.表盘19 = function() {
	this.initialize(img.表盘19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘21 = function() {
	this.initialize(img.表盘21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘22 = function() {
	this.initialize(img.表盘22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘23 = function() {
	this.initialize(img.表盘23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,57);


(lib.表盘23bg = function() {
	this.initialize(img.表盘23bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘23txt2 = function() {
	this.initialize(img.表盘23txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,510,106);


(lib.表盘23大 = function() {
	this.initialize(img.表盘23大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,337,337);


(lib.表盘24 = function() {
	this.initialize(img.表盘24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘25 = function() {
	this.initialize(img.表盘25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘26 = function() {
	this.initialize(img.表盘26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,58);


(lib.表盘26bg = function() {
	this.initialize(img.表盘26bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘26txt2 = function() {
	this.initialize(img.表盘26txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,558,106);


(lib.表盘26大 = function() {
	this.initialize(img.表盘26大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,338,338);


(lib.表盘27 = function() {
	this.initialize(img.表盘27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,56);


(lib.表盘28 = function() {
	this.initialize(img.表盘28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,58);


(lib.表盘28bg = function() {
	this.initialize(img.表盘28bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘28txt2 = function() {
	this.initialize(img.表盘28txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,558,106);


(lib.表盘28大 = function() {
	this.initialize(img.表盘28大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,336,336);


(lib.表盘31 = function() {
	this.initialize(img.表盘31);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,59);


(lib.表盘32 = function() {
	this.initialize(img.表盘32);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,59);


(lib.表盘33 = function() {
	this.initialize(img.表盘33);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,58,58);


(lib.表盘33bg = function() {
	this.initialize(img.表盘33bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘33txt2 = function() {
	this.initialize(img.表盘33txt2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,585,106);


(lib.表盘33大 = function() {
	this.initialize(img.表盘33大);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,336,336);


(lib.表盘34 = function() {
	this.initialize(img.表盘34);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,59);


(lib.表盘35 = function() {
	this.initialize(img.表盘35);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,59);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.表盘point1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrAsQgTgSABgaQgBgZATgSQASgTAZABQAagBASATQASASAAAZQAAAagSASQgSASgaAAQgZAAgSgSg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘point1, new cjs.Rectangle(-6.2,-6.2,12.5,12.5), null);


(lib.表盘大G = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer 1
	this.instance = new lib.表盘11大();
	this.instance.parent = this;
	this.instance.setTransform(-168.5,-168.5);

	this.instance_1 = new lib.表盘13大();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-168.5,-168.5);

	this.instance_2 = new lib.表盘18大();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-168.5,-168.5);

	this.instance_3 = new lib.表盘23大();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-168.5,-168.5);

	this.instance_4 = new lib.表盘26大();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-169,-169);

	this.instance_5 = new lib.表盘28大();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-168,-168);

	this.instance_6 = new lib.表盘33大();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-168,-168);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.5,-168.5,337,337);


(lib.表盘txt2G = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// 表盘11txt2.png
	this.instance = new lib.表盘11txt2();
	this.instance.parent = this;
	this.instance.setTransform(-195.5,-53);

	this.instance_1 = new lib.表盘13txt2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-232,-52.5);

	this.instance_2 = new lib.表盘18txt2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-195,-51.5);

	this.instance_3 = new lib.表盘23txt2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-255,-53);

	this.instance_4 = new lib.表盘26txt2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-279,-53);

	this.instance_5 = new lib.表盘28txt2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-279,-53);

	this.instance_6 = new lib.表盘33txt2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-292.5,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-195.5,-53,391,106);


(lib.表盘txt1G = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(26));

	// 表盘1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACiBxQA5gNAggTQAfgTAGgZQAEgLABgRQACgRAAgZIAUAAQAAAYgCARQgBASgEAMIB+BIIgMARQgegTg0geIgngWQgIAXggATQggATg4APgAlBCAIAAjqIhzAAIAAgUIEXAAIAAAUIiOAAIAADqgADHA8IAAiEIBPAAIALgpIh1AAIAAgSIEJAAIAAASIh9AAIgNApIBuAAIAACCIgVAAIAAhxIipAAIAABzgAkogeIANgSIBsA8IgOAUQhAgmgrgYgAiMgEIAAgVIEcAAIAAAVg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AEsB/QALgRAGgXQAFgYAAgfIARACIgBAfQAHANAIAJQAHAJAIAFIAAhWIhBAAIAAgQICCAAIAAAQIgwAAIAAAiIAsAAIAAAQIgsAAIAAApQAHAEALABIAeACQBIADBSgDIgFALIgCAIIiWgBQglAAgXgKQgYgLgMgVQgCAMgGANQgFANgIAMgAkWCKIAAjAIBwAAIAAhVIAUAAIAABVIBxAAIAACcQAAAPgIAJQgJAIgSAAQgKACgdAAIgGgWIAnACQAKAAAGgEQAFgEAAgHIAAiKIjOAAIAACvgAmzCIIgFgWIAqACQAOAAAGgFQAHgHgBgLIAAiWIhlAAIAAgTIBlAAIAAg/IAUAAIAAA/IAnAAIAAATIgnAAIAACaQAAATgKAJQgKAKgTABgAAEB8IAAgSICBAAIAAhSIhpAAIAAgTIBpAAIAAhIIh1AAIAAgTID/AAIAAATIh1AAIAABIIBqAAIAAATIhqAAIAABSICCAAIAAASgApKB7IAAjsIBgAAIAADpIgTAAIAAgXIg7AAIAAAagAo4BPIA7AAIAAhPIg7AAgAo4gPIA7AAIAAhQIg7AAgAG1BiIgGgGQAlgNAQgYQASgXgDgjIAAgkIARAAIAAAkQgBAXgDASQAYARAnAhIgMAOIg5gwQgHAPgQANQgQAOgZAKgAjZBUIAAhUIB6AAIAABUgAjHBDIBVAAIAAgzIhVAAgAnPgOIAPgJIAlA+IgSAJgAIkArIAAhlIhSAAIAABlIgQAAIAAh0IAoAAIAGglIg5AAIAAgOICMAAIAAAOIhAAAIgHAlIA6AAIAAB0gAFBgZIAAhmIBhAAIAABmgAFSgoIBAAAIAAgcIhAAAgAFShTIBAAAIAAgdIhAAAgAhuhQQAWgQAggfIAPANQgjAggUAQgAkPhyIANgNIA2AsIgQAPQgVgVgegZgAB8iEIATgHIAVArIgVAGQgGgRgNgZg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AEpB4QglgBgUgWQgSgWgBgrQACgqASgXQATgXAkgBQAcABARANQARANAIAYIgSAFQgFgTgNgLQgMgKgUgBQgdABgOASQgPATgBAkQABAkAPASQAOATAdABQAYgBANgMQANgMADgXIARAEQgCAPgGALQgFALgJAHQgKAHgLAEQgLADgNAAIgEAAgAn8BnQgagRgIgkIAUgIQAFAgATAQQAVAQAiAAQAhgBARgNQASgNACgZQACgUgTgMQgTgNgngFQgrgGgWgPQgUgQAAgYQACgeAVgQQAVgPAngBQAmAAAXAQQAWAPAGAfIgTAGQgFgagRgNQgRgMgdgBQgeABgRAMQgQALgDAWQgBARASAMQASAMAkAGQAvAFAWAQQAVARgCAdQgDAdgVAQQgWAQgoACIgFAAQgnAAgXgRgAGXBgQgVgVgCgqQAEhWBNgEQAmABAUAXQATAXABAsIAAAEIiMAAQACAhAPARQAQARAdABQAZAAAPgLQAPgKAEgUIASAEQgHAagTAMQgTANgeAAQgogCgUgWgAGlgYQgOARgDAfIB4AAQAAgggPgRQgPgQgdgBQgcACgQAQgAgBBgQgUgVgBgpQABgsAVgXQAUgXAogBQAkABATAXQATAXACAqQAAArgVAWQgTAWgoABQgmgDgTgVgAAMgWQgPAUgBAkQABAjAPASQAPASAfACQAcgBAQgSQAPgTACgkQgCgjgPgTQgQgTgcgCQgfABgPATgACpB0IAAiqIASAAIAACqgAiaB0IhijoIATAAIBZDbIBXjbIAUAAIhjDogACphbIAAgaIASAAIAAAag");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AFACOIAAkGIBKAAIAAATIgYBPQANANAFAQQAGARAAAWQAAARgGAKQgHAKgNABIgTACQAAgKgFgJIARAAQAJAAAEgGQAEgGgBgMQABgPgGgQQgGgQgMgQIAXhSIgoAAIAAD0gAECCNIAAgUIhuAAIAAAUIgTAAIAAkDICVAAIAAEDgACUBqIBuAAIAAg7IhuAAgACUAfIBuAAIAAg5IhuAAgACUgrIBuAAIAAg6IhuAAgAA2CNIAAiiQgIAZgKAVQgKAVgMARIgJgWQAPgUAMgZQAMgZAJggIgrAAIAAgSIAsAAIAAg6IATAAIAAA6IAnAAIAAASIgnAAIAAAwIAIgIIAkAjIgNANIgfgiIAACUgAosCNIAAiLIDRAAIAACKIgUAAIAAgRIipAAIAAASgAoYBrICpAAIAAgjIipAAgAoYA3ICpAAIAAgkIipAAgAF3B7IApgnIAAhpIgWAAIAAgRIAmAAIAAB8QALAPASAIQASAHAYgBQAdACA8gCIgGATIhXgBQgaAAgTgHQgTgIgMgQQgOAMgVAYgAjRCIIgFgVIAkABQALABAGgFQAFgFgBgLIAAhXIhxAAIAPh6QAzAAA1gDQA2gDA5gFIAGASQguAFgyACIhqAEIgMBXIBbAAIAAhBIAUAAIAABBIBwAAIAAARIhwAAIAABbQABASgJAJQgJAJgTAAgAkjBvQATgSASgUQARgUAPgWIASAKQgSAZgSAVQgSAVgSAQQgIgIgHgFgAgzBfQgeglgPgRIAPgKQAeAjArAtIgSAMgAIBBQIAWAAQAJAAADgEQAEgEAAgJIAAgVIg+AAIAAA3IgSAAIAAh7QgLAOgOAOIgIgPQAPgQANgTQANgTALgWIgjAAIAAgRIApAAQAHgPAEgRIATADQgFAPgHAOIBIAAIAAARIhNAAIgQAdIBLAAIAAB+QABAQgHAHQgIAIgPgBIgWABgAHpAcIA+AAIAAgcIg+AAgAHpgPIA+AAIAAgeIg+AAgApPgbIAAgSIBZAAIgWgeIAQgIIAaAfIgNAHIBKAAIAbgnIATAJIgYAeIBYAAIAAASgAGUiBIARgFIAVA8IgSAFgApBhZIAAgRIB7AAIgOgdIATgGIAQAfIgLAEIB3AAIAAARg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ADyCIQgHgFgFgLQgHgKgDgZQgDgZAAgpIAAgLIi4AAIAAgRIDMAAIAAAcQgBBJAMATQADAIAHABQAJgBACgMIAFgsIARAGQAAASgEAZQgFAcgYAAIgBAAQgIAAgHgEgAkiB6QA4gWAfghQAfggAGgoIh8AAIAAgUIB+AAQADgWAAg1IhxAAIAAgTID2AAIAAATIhwAAIgBAlQAAAagCAMICDAAIAAAUIh+AAQAKAuAgAfQAgAfA2AOIgNAUQg3gTgfggQgggfgKgtQgIAqgfAgQggAhg2AXgAAGgbQAWgXARgcQASgcANghIAUAEQgGAPgHANIDBAAIAAASIjKAAQgTAnglAqgABFgpIAAgRIC5AAIAAARg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ACbCBQAKgNAFgNQAHgNACgNQAEgMABgTIABicIB1AAIgIgaIAUgEIAIAeIBqAAIAAAQIjgAAIAABgQAAAbgBAUQgDAUgDANQgCANgIAPQgGAOgLARgAhVB+QAMgMAIgKQAIgLAGgKQgIgLgIgQQgGgPgFgUIAPgGQAMAlAIAOQAEgNADgSQAEgSABgXIgrAAIAAgRIAuhGIgqAAIAAgQIA9AAIAAASIguBFIAqAAIAAANQgCAegFAXQgFAXgGAPQAFAHAKAFQAIAFAKAEQALAEAOACIBxAEQgGALgBAGIhOgBQgjgCgXgIQgXgIgOgMQgTAagPAPQgGgFgFgJgAhwCMIAAimIgFAIQgMAXgIAMQgDgKgFgIQAmhBAOhIIASADQgIAlgNAeIAADQgAECB4IAaAAQALAAAFgEQAFgFgBgJIAAgSIghAMQgrANgTAHIgHgPQAcgJBKgZIAAgmIhOAAIAAgPIBOAAIAAgZIheAAIAAgPIBeAAIAAgYIhNAAIAAgPIBNAAIAAgXIASAAIAAAXIBVAAIAAAnIAfAAIAAAPIgfAAIAAAoIhVAAQALASAUAXQAVgLAkgVIAKAOQgaAQgcAOQANAKAQAHQARAIAVAGQgEAJgHAIQglgNgYgSQgagTgNgWIAAAuQADAggiAAIgdABgAFCAOIBCAAIAAgZIhCAAgAFCgaIBCAAIAAgYIhCAAgAmUBoQgZgRgIgkIATgIQAFAgAUAQQAUAQAjAAQAhgBAQgNQASgNADgZQABgUgSgMQgUgNgngFQgrgGgVgPQgVgQABgYQABgeAVgQQAWgPAngBQAmAAAXAQQAWAPAGAfIgTAGQgFgagSgNQgRgMgdgBQgdABgRAMQgRALgCAWQgCARATAMQASAMAkAGQAuAFAWAQQAWARgCAdQgDAdgVAQQgWAQgpACIgEAAQgnAAgYgRgAAvBoIAAgeIg0AAIAAgOIA0AAIAAgbIgvAAIAAgPIAvAAIAAgaIgsAAIAAgOIAsAAIAAgcIg4AAIAAgQIA4AAIAAgbIgqAAIAAgPIAqAAIAAgeIASAAIAAAeIA2AAIAAAqIAUAAIAAAQIgUAAIAAAqIg2AAIAAAaIA7AAIAAAPIg7AAIAAAbIA/AAIAAAOIg/AAIAAAegABBgWIAmAAIAAgcIgmAAgABBhCIAmAAIAAgbIgmAAgADcAxIAKgLIAqAZIgMAOQgNgKgbgSg");

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AlHB/QADACgGgHQAigUATgbQASgcAEgiIhDAAIAAgQIBEAAIABg4Ig7AAIAAgSIBLAAIAkg9IARAIIgiA1IAyAAIAAASIhCAAIAAA4IBMAAIAAAQIhLAAQARBLA9AfQgJAJgEAIQgggUgTgaQgSgZgGgfQgFAfgSAaQgTAaggAWgAlkCLIAAg3IhRAPIgDgTIAVgDIAAi0IgTAAIAAgRIB1AAIAAARIgRAAIAACmIAagFIAAARIgaAFIAAA7gAmSBKIAugIIAAgsIguAAgAmSAFIAuAAIAAgtIguAAgAmSg4IAuAAIAAgvIguAAgACrCAIgKgJQA4gfAgguQAfgtAHg9QADgVABg0IAVAAIgBAtQAIBQAgAzQAhAzA5AXIgGAIIgJALQg3gbgegsQgfgtgHg8QgIA7ggAtQggAtg3AegAg6BxQAHABAbAAQAKABAFgFQAFgFAAgKIAAg4IhSACIgaAEIgHgUQAMgCARgIQAYgLBBgiIhnAGIgHgSQAPgGAHgEQAXgMA3gkIhrAEIgDgTQBOgCCjgKIAFARIh6AIIAKAGQgxAhgkAUIBigEQAVgLAkgZIAQAOQgvAdgrAXQgrAXgnASICZgEIgjgeIAOgLQAlAeAlAkIgOAMIgWgVIhSACIAAA9QAAARgIAIQgIAJgRAAIgjABgAh/B6QgHgKgEgDQAPgHATgNQASgNAVgSIAOANQgfAZgYARIgTANgAAvBHIAPgNIBLAyIgNAQgAkuiBIAPgJQASAWAOAYIgSAIg");

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ADxCMIAAgUIhwAAIAAAUIgTAAIAAh6IBBAAIAAgzIhcAAIAAgSIBcAAIAAg1IhMADIgEgSQA8gBBvgGIAEARQgmABglAEIAAA1IBZAAIAAASIhZAAIAAAzIBBAAIAAB6gACBBnIBwAAIAAhEIhwAAgAAaB2QAGgFACgGQADgHgCgIIAAhxIghAAIAAgSIA2AAIAACKIAkgaQAAAMACAKQgeASgMAJQgKAIgDAEgAhDCDIhEAAQgVAAgKgKQgLgJABgVIAAghIhYAAIAAAVIgTAAIAAi0IBrAAIAAgmIATAAIAAAmIBrAAIAACfIhrAAIAAAeQAAANAHAFQAIAGAOAAIA3AAQAaABAHgTIAFgiQAJAFAKABQgDAagEANQgDANgLAHQgLAGgRAAIgCAAgAidAnIBXAAIAAg0IhXAAgAkIAnIBYAAIAAg0IhYAAgAidgeIBXAAIAAg1IhXAAgAkIgeIBYAAIAAg1IhYAAgAAOh5IAQgMIAqAuIgRAMQgUgagVgUg");

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAOB6QAcgGAsgNQAUgGAegPQgWgSgRgYQgRgagMgdIgbAAIAAgSIBpAAIAAgwIiEAAIAAgSICEAAIAAgoIATAAIAAAoIB/AAIAAASIh/AAIAAAwIBTAAIAAATQgOAdgUAYQgSAZgZASQARALAfAJQAeAJAsAGIgCAEIgKAQQgugKgggLQgfgKgSgMQgYAOghAMQggAMgpAKQgDgKgHgKgAB2AkQAQAWAUAMQAWgPASgVQASgWANgbIiIAAQANAdAQAWgAnvB8QA8gLApgZQApgZAXgoIhQAAQgJANgIAFQAUAQASARIgNAMIgkghIgqAeIgGgKIgEgGQAbgQAVgUQAWgUARgXIATAFIgNAOIBXAAIAAARQgXAsgrAeQgtAdhBAPQgBgJgIgJgAFhCLIAAipIgEAIQgNAVgRAVIgIgYQAWgdARghQARgiANgnIAVAGQgQAngMAbIAADOgAisB/QAfgbAOgpQAPgpAAg3IABgYIgqAAIAAgRIAqAAIACg9IAUAAIgCA9IBOAAIAAAKQgCBRgDBLQgBAWgLALQgKAMgUgBIgkAAIgGgWIAlACQANAAAHgHQAGgGABgNQADg3AChcIg6AAIgBAZQAAA4gQAtQgPAsgfAegAoeCLIAAiIQgIAYgKAUQgJAVgMARIgIgVQAOgXANgYQALgXAIgbIgrAAIAAgRIAsAAIAAgzIgnACQgBgNgCgEQAlgCA9gGIADARQgUADgVACIAAA0IAoAAIAAARIgoAAIAAAiIAGgFIAnAeIgMAPIgZgYIgIgGIAACAgAHOBxIAnACQAOABAIgGQAGgFgBgMIAAiQIiCAAIAAgTICCAAIAAhDIAWAAIAABDIAoAAIAAATIgoAAIAACTQAAAUgKAJQgKAKgWAAIgqABgAiwBeIhSAHIgUADIgIgQQAJgKAGgLQAWg0AMgeIgxAAIAAgTICHAAIAAATIhBAAQgKAagLAYQgLAagNAWIA5gEIAVgCIgYgyIASgHIAkBOIgTAHgAGZgJIAPgLQAUAVAnAwIgSANQgVgdgjgqgAnkgGQBngbAshAIhVAAIgMAMIAlAeIgMANQgSgSgSgOIgZAXIgMgPQAXgSARgSQASgTANgUIARAGIgPAXIBcAAIAAARQgVAkgoAbQgnAag4ARQgHgLgEgGgAkRhhIAAgSIBuAAIAAASg");

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAICBQAKgQAHgOQAHgPADgOQADgOACgVQACgVAAgdIAAhrIDpAAIAADgQABARgJAJQgKAJgUAAIgjABIgDgVIAiABQALAAAFgFQAGgEAAgKIAAg1IhZAAIAABaIgUAAIAAhaIhXAAQgBAYgIAYQgIAXgPAYgACmAdIBZAAIAAg5IhZAAgAA9AdIBVAAIAAg5IhUAAgACmguIBZAAIAAg6IhZAAgAA+guIBUAAIAAg6IhUAAgAJgB+QAigrgDhgIAAhcIB5AAIgOgdIAVgGIAPAjIBtAAIAAASIjpAAIAABMQABAygIAnQgJAmgSAYgAFjCMIAAiJQgQAwgXAhIgLgTQAQgVAMgaQAMgYAIgdIgqAAIAAgRIAsAAIAAgzIgnACIgBgGQAAgHgDgFIBigGIACARQgVADgTABIAAA0IAoAAIAAARIgoAAIAAAmIAIgGIAmAiIgNAOIghgjIAACCgArrB8QASgHAOgHQAOgHAKgIQgMgNgJgQQgJgRgHgUIgLAAIAAgOIBvAAIAAAPQgHAUgKAQQgJAQgMANQAIAFAOAHIAjANIgIARQgwgWgNgJQghAWgaAMgAq6A7QAIANALALQAJgIAJgOQAIgNAIgTIhDAAQAGAQAIAOgAsHCMIAAgdIhuANIgDgRIAcgBIAAhwIgeAAIAAgQIEcAAIAAAQIiWAAIAABmIAYgEIAAAGQgBAGABACIgYADIAAAfgAtKBpIBDgHIAAgZIhDAAgAtKA7IBDAAIAAgZIhDAAgAtKAUIBDAAIAAgaIhDAAgAkjB+QAKgOAGgPQAHgOADgOQACgOACgVIABiEIB5AAIgNgmIAUgEIAEAMQAIAUACAKIBqAAIAAASIjkAAIAAA8QAAAegBAYQgCAYgEARQgDAPgHARQgHAQgLAQgApQB5QAIgKAWgWIALgMIAAhgIgmAAIAAgTIA6AAIAAByQANASAUAJQATAJAagBICRgBIgHAUIiPgBQg2AAgegkIgkAtgALQCIIgCgJIgCgLIAkABQAKAAAFgFQAFgEAAgJIAAhAIhhAAIAAgSIBoAAIg6giIAMgOIAsAbIA8gmIiUAAIAAgQICzAAIAAATIhLArIAFAEIgJAJIBiAAIAAASIgXAyIgSgHIAVgrIhLAAIAABDQAAAQgIAIQgJAJgRABgAGUB9IAAgQIBYAAIAAgsIhCAAIAAgPIBCAAIAAgrIhJAAIAAgQICkAAIAAAQIhIAAIAAArIBCAAIAAAPIhCAAIAAAsIBTAAIAAAQgAjrB5IAAgQICHAAQAQgrAMgmQAMglAJgiIATAEQgfBngQAtIBGAAIAAAQgAmCBgIAAh2IhFAAQAAAjgJAdQgJAdgTAYIgJgJIgIgGQAKgMAHgNQAHgMADgMQADgLACgSQACgRAAgYIAAhKQAzgCBdgKIAHATIiDALIAAA4ICPAAIAAARIg2AAIAAB2gAjcgkIASgEQAXBIAKAoIgTAFQgKgogWhJgAiUgyIARgDIAaBvIgUAFgAGvgoIAAhRICOAAIAABRgAHDg6IBmAAIAAgvIhmAAgAtQgqIAAhUIDJAAIAABUgAs9g5ICiAAIAAgVIiiAAgAs9hbICiAAIAAgVIiiAAgAo7h+IAQgJQAaAgANATIgTALg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[]},1).wait(16));

	// 表盘2
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ACiBxQA5gNAggTQAfgTAGgZQAEgLABgRQACgRAAgZIAUAAQAAAYgCARQgBASgEAMIB+BIIgMARQgegTg0geIgngWQgIAXggATQggATg4APgAlBCAIAAjqIhzAAIAAgUIEXAAIAAAUIiOAAIAADqgADHA8IAAiEIBPAAIALgpIh1AAIAAgSIEJAAIAAASIh9AAIgNApIBuAAIAACCIgVAAIAAhxIipAAIAABzgAkogeIANgSIBsA8IgOAUQhAgmgrgYgAiMgEIAAgVIEcAAIAAAVg");

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ACLB/QAJgOAHgNQAFgNADgMQACgMACgTQACgUgBgaIgkAAIAABkQABAOgHAHQgGAHgPABIgcAAIgBgIIgCgLIAWABQAJAAAFgDQAEgEgBgIIAAhgIg0AAIgCAwQgBAUgDAPQgDAOgGAOQgGAPgJAPIgRgMQAJgOAFgNQAGgOACgMQADgMABgUIACgsIghAAIAAgSIAhAAIAAhqIBaAAIAABqIAkAAIAAhqIBfAAIAABqIAeAAIAAASIgeAAIAABrQAAAOgHAIQgJAGgPAAIgeAAQgBgKgDgIIAbAAQAKABAEgEQAFgDAAgIIAAhnIg5AAIgBAyQgBAUgDAOQgEANgGAPQgGAOgKAPgAC7gUIA5AAIAAhYIg5AAgAA9gUIA0AAIAAhXIg0AAgAgnCLIAAgTIhuAAIAAATIgTAAIAAkDICVAAIAAEDgAiVBoIBuAAIAAg6IhuAAgAiVAeIBuAAIAAg5IhuAAgAiVgtIBuAAIAAg5IhuAAgAjzCLIAAihQgIAYgKAWQgKAVgMARIgJgWQAPgUAMgZQAMgaAJgfIgqAAIAAgSIArAAIAAg7IATAAIAAA7IAoAAIAAASIgoAAIAAAwIAIgIIAkAjIgNANIgfgjIAACUg");

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAeCMIAAjaIASAAIAADagAg5CMIAAiVIguAAIAAAIQABAugJAjQgKAjgUAYIgBgBIgQgLQATgUAJggQAJghgBgsIAAhwQAtgDA/gIIAGASQg2AIgpACIAABGIBnAAIAAASIgnAAIAACVgADhCKIgEgTIAZABQALABAFgFQAFgFgBgLIAAjMIiTAAIAAgRICmAAIAADgQABARgIAJQgJAJgSAAgAj/CJIgEgTIAYABQAIAAAFgEQAEgEAAgIIAAhHIg7AAIAAgQIA7AAIAAgeIATAAIAAAeIA3AAIAAAQIg3AAIAABJQAAAPgHAIQgIAIgQABgADGB1IAAghQg+AChEAFIgBgSIAegBIAAh8IgYAAIAAgRICnAAIAAARIgYAAIAAB2IAdgCIAAAIIgBAJIgcACIAAAigABzBHIBTgEIAAgdIhTAAgABzAXIBTAAIAAgeIhTAAgABzgWIBTAAIAAgeIhTAAgAkcBpQAQgZANgfIAQAHQgKAWgTAhgAi7A4IAOgJQASAZALASIgPAJgAkcgVIAAgQIBUAAIAZguIARAHQgLAVgNASIAtAAIAAAQgAkFhMIAPgHIAXAlIgPAIgAAqh+IAQgMIAmAnIgQAOQgNgQgZgZgAkThZIAAgQIA9AAIgMgeIATgEIANAiIAyAAIAAAQg");

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Aj1B7QA5gLApgOQgggVgYggIgUAAIAAgQICyAAIAAARQgOAQgQANQgPANgRAKQASAGAZAGQAYAFAfAEIgEAKIgFAJQhHgNgmgTQglAThIAQQgDgKgGgIgAicBGQAOAKAOAJQAPgHAPgLQAPgLAPgPIhxAAQAMAOANALgAkjB/QAKgOAGgOQAFgOADgNQADgMABgVIACiTIB4AAQgBgNgGgRIAVgCIAJAgIBtAAIAAARIjqAAIAABTQAAA5gHAeQgDAPgGAPQgHAPgJAQgAD1CHQgHgFgFgLQgHgKgDgZQgDgZAAgpIAAgLIi4AAIAAgRIDMAAIAAAcQgBBJAMATQADAIAHABQAJgBACgMIAFgsIARAGQAAASgEAZQgFAcgYAAIgBAAQgIAAgHgEgAo9CLIAAiDID5AAIAABhQACAgghAAIgmAAIgDgTQAJABAYAAQALABAFgEQAFgEAAgJIAAhPIjUAAIAABzgAE1B8QALgPAHgOQAGgOADgNQAEgOACgVQABgUAAgcIAAhoID3AAIAAAUIjjAAIAABPQAAAfgBAYQgCAYgEAQQgDAPgIAQQgHAQgLAQgAFxB8IAAgSIBkAAIAAhoIhPAAIAAgSIBPAAIAAg/IAUAAIAAA/IBaAAIAAASIhaAAIAABoIBmAAIAAASgAoABqIAAg8ICAAAIAAA8gAntBcIBaAAIAAgeIhaAAgAIGAlIAPgMIAoAsIgQANQgTgYgUgVgAi9ADIAAgrIgqAAIAAgSIAqAAIAAgZIATAAIAAAZIBXAAIAAgZIARAAIAAAZIA1AAIAAASIg1AAIAAArgAiqgLIBXAAIAAgdIhXAAgAAJgcQAWgXARgcQASgcANghIAUAEQgGAPgHANIDBAAIAAASIjKAAQgTAnglAqgAodgPIAAg4IC6AAIAAA4gAoLgdICVAAIAAgcIiVAAgABIgqIAAgRIC5AAIAAARgApOheIAAgRICGAAQgBgNgGgMIAVgEIAHAdICAAAIAAARg");

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ADBCMIAAhkIgwAAIAAAPIgTAAIAAiJIBDAAIAAg4IASAAIAAA4IBDAAIAACJIgTAAIAAgPIgwAAIAABkgADTAXIAwAAIAAhXIgwAAgACRAXIAwAAIAAhXIgwAAgAkVCLIAAjaIATAAIAADagAhdCGIgFgTIAiAAQAMABAGgFQAGgFgBgLIAAjIIiSAAIAAgQIClAAIAADbQABASgJAJQgJAJgSAAgAAnB2QAIgIAAgKIAAhEIgmAAIAAgSIAmAAIAAgqIgUAAIAAgQIBKAAIAAAQIgjAAIAAAqIArAAIAAASIgrAAIAABHQAVgLAVgOQABAKAEAKQghAPgPAJIgCABQgHAFgEAFgAifB5IAAhuIgwAAIAABUIgSAAIAAhjIBCAAIAAgjIhQAAIAAgQIBYAAIgQgeIAQgGQAIAMALAUIgKAEIBQAAIAAAQIhQAAIAAAjIBCAAIAABGQABAOgGAGQgHAHgNAAIgTAAIgEgSIASABQAHAAADgDQADgDAAgIIAAgzIgxAAIAABugAAEgxQAPgVALgXQALgWAHgYIATAEQgHAVgIARIA7AAIAAASIhDAAQgGAOgSAaIgDAGgAkHh+IAPgMQAUATAPASIgPAOQgOgSgVgVg");

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAiCFIAAiIQgPAvgXAhIgKgTQAOgVANgaQAMgYAHgdIgpAAIAAgRIArAAIAAgzIgmABIgBgFQAAgIgCgEIBggGIADARQgWADgTABIAAA0IApAAIAAARIgpAAIAAAnIAIgHIAmAiIgMAOIgigjIAACCgAhXCDIAAgVIikAAIAAAVIgVAAIAAkDIDNAAIAAEDgAj7BdICkAAIAAhdIikAAgAj7gTICkAAIAAhaIikAAgABTB2IAAgQIBYAAIAAgsIhCAAIAAgPIBCAAIAAgrIhJAAIAAgQIClAAIAAAQIhJAAIAAArIBCAAIAAAPIhCAAIAAAsIBTAAIAAAQgABugwIAAhRICOAAIAABRgACChBIBmAAIAAgvIhmAAg");

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AIPCNIAAgkIhZAAIAAgPIBZAAIAAgaIhAAAIAAhYICVAAIAABYIhCAAIAAAaIBZAAIAAAPIhZAAIAAAkgAHhAyIBxAAIAAgYIhxAAgAHhAMIBxAAIAAgWIhxAAgAFrCNIAAkIIBNAAIAAATIgYBQQAZAeAAAnQAAASgHAKQgHAKgOACIgFABIgOABQgDgKgDgIIASAAQASgCgBgXQABgigZggIAXhUIgpAAIAAD3gADbCNIAAhoQgOAcgWAWQgWAVgeAQIgNgRQAegNAVgUQAWgTAOgZIhRAAIAAgSIBfAAIAAgfIAUAAIAAAfIBeAAIAAASIhRAAQANAXAVATQAVASAbAOQgFADgHAMQgegPgUgUQgVgVgMgbIAABpgABWCNIAAilQgMAWgRAXIgIgVQAog+AUhLIAUAGIgFAPQgLAkgJAQIAADNgAh/BpQgZgSgIgkIAUgHQAEAgAUAPQAUAQAjAAQAhgBARgNQAQgNADgYQABgUgRgNQgTgMgngGQgsgFgVgQQgVgPABgZQACgeAVgPQAVgQAngBQAmABAXAPQAVAQAGAeIgTAGQgEgZgRgNQgRgNgdgBQgeACgRALQgQAMgDAVQgBASASALQASAMAkAGQAuAGAVAQQAWARgCAcQgDAegVAQQgVAQgoABIgFAAQgnAAgYgQgApZBpQgZgSgIgkIAUgHQAEAgAUAPQAUAQAjAAQAhgBARgNQARgNADgYQABgUgSgNQgTgMgngGQgsgFgVgQQgVgPABgZQACgeAVgPQAVgQAngBQAmABAXAPQAWAQAGAeIgTAGQgFgZgRgNQgRgNgdgBQgeACgRALQgQAMgDAVQgBASASALQASAMAkAGQAuAGAWAQQAWARgCAcQgDAegVAQQgWAQgoABIgFAAQgnAAgYgQgAleBwQgVgIgOgPQgOgPgIgVQgHgVgCgcQADg5AdgfQAdgfA2gDQA0AEAcAeQAcAfAEA4QgDA5gcAdQgdAeg2ACQgbgBgUgIgAlyhHQgYAagDAwQADAxAXAaQAXAaAsADQAtgCAYgaQAXgaADgyQgDgwgXgbQgXgagtgEQgsAFgXAagACWgcIAAhfICeAAIAABfgACqguIB4AAIAAg7Ih4AAgAG7gtIAAgPIA4AAQgDgIgLgLIgGgIIAOgJIgnAAIAAgPIBOAAIgKgaIASgDIALAbIgKACIBRAAIAAAPIh/AAIAXAeIgMAGIAzAAIAWgiIASAHIgUAbIA5AAIAAAPg");

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgvCNIAAgSIh8AAIAAASIgUAAIAAhkICjAAIAABkgAirBrIB8AAIAAgwIh8AAgAkACNIAAioQgQAfgMAQIgIgVQATgdAQgiQAPgiAMgnIATAFQgHASgNAjIgFANIAADPgAC3CHIhFAAQgTAAgKgJQgKgJABgSIAAgrIATAAIAAAoQgCAWAbgBIA7AAQAMAAAIgEQAHgDABgIIAGgcIASAHIgBAIQgBAIgDAKQgEAOgLAHQgKAHgQAAIgCAAgAAGByQANgTAMglIATAFIgaA7gADxA/IAPgJIAlAuIgQAJgACBA2IANgLIAiAkIgPALgAAsAjIAAiRIBIAAQAHgSACgMIAVADIgJAbIByAAIAACRgABAATICnAAIAAgbIinAAgABAgXICnAAIAAgdIinAAgABAhDICnAAIAAgcIinAAgAjBALIAAgQICoAAIAAAQgAjBgjIAAgRICoAAIAAARgAjQhSIAAgSIBeAAIgPgiIAUgEIAQAjIgLADIBfAAIAAASg");

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABRE0QAfgYAPgkQAPgjgCgwIADg3IgnAAIAAgSIBXAAIgQguIATgEIASAvIgPADIBYAAIAAASIh6AAIgDAxIBpAAQgDBOgCAbQAAAagMAMQgLANgYgBIgjABIgEgVIAkAAQAPABAHgIQAJgIgBgRIAFhWIhVAAQAAAwgPAkQgQAlgfAZgAAOFCIAAkKIBUAAIAAAUIgZBRQAPASAHATQAHASAAASQAAATgIALQgHAKgQADIgYABIAAgEIgFgQIAWABQAJgBAFgGQAFgHAAgMQAAgfgggnIAbhWIgtAAIAAD5gAoGE0QAfgYAPgkQAPgjgCgwIADg3IgnAAIAAgSIBXAAIgRguIAUgEIASAvIgPADIBYAAIAAASIh6AAIgCAxIBoAAQgDBOgCAbQAAAagMAMQgLANgXgBIgkABIgFgVIAlAAQAPABAIgIQAHgIABgRIAEhWIhUAAQgBAwgPAkQgQAlgeAZgApJFCIAAkKIBVAAIAAAUIgaBRQAPASAHATQAHASAAASQAAATgIALQgHAKgPADIgZABIAAgEIgFgQIAWABQAJgBAGgGQAEgHAAgMQAAgfgfgnIAbhWIguAAIAAD5gAF4E9IgDgVIAjABQAaAAgBgVIAAjpIAUAAIAAAsQASAvAKATQARgNARgQQAQgQAQgRIAQAOIgkAjQgSARgSAOQASAdAYAZQAXAZAeAVIgIAKIgHAHQgpgfgegoQgegngRgwIAACUQABAmgpABgAkpE1IAAgTICDAAIAAg3IhqAAIAAgTIBqAAIAAgjIATAAIAAAjIBrAAIAAATIhrAAIAAA3ICEAAIAAATgAEsEVQAhggAVgkQAUglAJgoIhJAAIAAgUIBdAAIAAATQgKAugWAoQgWApgjAigAimCiIAAh2IATAAIAAB2gAkjCRQAWgOAUgPQAUgPASgRIAOAPQgjAfguAggAhyBiIANgPIBPA7IgPARgAE0g+QAXgMARgMQASgNAKgMQgggngQg4QgBAwgOAnQgOAogaAeIgRgNQARgTAKgTQALgTAFgUQAGgUADgeQADgeAAgpIAAgdIgaAAIAAgTICOAAIAAAUIgdA+IAzAAIAAASQgKAfgLAYQgMAYgOASQANAMAQALQARAMATAJQgHAJgGAKQgzglgMgMQgdAcgqAZgAFJj3QAMAmAPAeQAOAeAUAXQALgPAJgUQALgVAIgaIg0AAIAAgUIAeg9IhOAAgAiHhHQgQgGgJgOQgLgOgFgVQgFgVAAgbQAAiCBVAAQA0ACAOAyIgQAGQgFgWgNgLQgNgLgUABQhDAAAABtQAKgUARgKQASgKAYAAQBBAFAGBIQgDAlgTAUQgSATgjADIgCAAQgUAAgOgHgAiRi9QgQANgCAaQABAjAPASQAQASAeABQAcgBAPgQQAPgPABggQgCg8g3gDQgdACgRAOgAAxhFQgPgEgKgIQgKgJgFgLQgFgMgBgQQADgYALgPQAMgPAVgFQgSgJgJgNQgKgNAAgSQACgdARgQQARgQAhgCQA/AEAHA7QgBATgKANQgIAOgSAHQAWAHALAPQALAQACAYQgBAegUAPQgTAQgmABQgTgBgPgEgAAmioQgPANgBAaQABAaAPAMQAPANAeAAQAdgBAQgMQAOgMABgXQgBgbgPgOQgQgOgdgCQgdABgPAOgAAtkVQgMAMgCAXQABAXAMAMQANAMAaABQAYgBANgMQAMgMABgXQgBgXgNgMQgNgMgYgBQgYABgNAMgAmDhEIAAjpIBlAAQAkACAUARQATARADAgQAAAjgVASQgUARgoACIhQAAIAABdgAlxiyIBMAAQAhAAAQgOQARgOgBgcQgBgZgRgNQgQgMgfgCIhMAAgAnLhEIAAjpIARAAIAADpgAC3hcQA2gKAigIIAAATIhTAQgAC6ieQAKgGAMgPQAMgQAPgXQgdABgRADIgHgTQAHgFAKgQQAKgRAbgyIAUAHIgzBRIAqgBIAWgkIARAIQgrBCgcAlIA7gGIgDASIgRABQgsADgPAEg");

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ACiB4QA5gNAggTQAfgTAGgaQAEgKABgSQACgRAAgZIAUAAQAAAYgCARQgBASgEANIB+BHIgMASQgegTg0geIgngXQgIAXggATQggATg4APgAm0B4IAAgSIBxAAIAAjvIAXAAIAABXIB3AAIAAAVIh3AAIAACDICPAAIAAASgADHBDIAAiFIBPAAIALgpIh1AAIAAgRIEJAAIAAARIh9AAIgNApIBuAAIAACDIgVAAIAAhxIipAAIAABzgAiMABIAAgUIEcAAIAAAUg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10}]},10).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[]},1).wait(6));

	// 表盘3🔂
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ACiB4QA5gNAggTQAfgTAGgaQAEgKABgSQACgRAAgZIAUAAQAAAYgCARQgBASgEANIB+BHIgMASQgegTg0geIgngXQgIAXggATQggATg4APgAm0B4IAAgSIBxAAIAAjvIAXAAIAABXIB3AAIAAAVIh3AAIAACDICPAAIAAASgADHBDIAAiFIBPAAIALgpIh1AAIAAgRIEJAAIAAARIh9AAIgNApIBuAAIAACDIgVAAIAAhxIipAAIAABzgAiMABIAAgUIEcAAIAAAUg");

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AKuB+QAQgPALgOQAKgOAEgOQAFgNACgXQACgWAAggIAAhiIBmAAIAADaQAAAHADADQADAEAFgBIAGAAQAHABAEgEQADgEABgIQADgUACgcIASAGIgEApIgBAIQgDAOgHAHQgIAGgMAAIgNAAQgNAAgHgHQgGgHgBgOIAAjLIg/AAIAABRQAAAggDAYQgCAZgFAPQgFAPgKAQQgLAQgPAQgAKNCMIAAijQgJAcgJAWQgLAWgKAPIgIgWQAPgVAMgaQAMgaAHggIgnAAIAAgRIAoAAIAAg6IASAAIAAA6IAoAAIAAARIgoAAIAAAuIAIgKIAnAkIgNANIgighIAACXgAgyCLQgOAAgMgJQgNgKgMgTIgCgHQgEgIgCgFQgMALgSAKQgRALgXAJIgMgPQAWgKATgLQASgMARgMIgPheIhOAAIAAA1IA4gLIAAATIg4AJIAABCQABAPgIAIQgIAIgPAAIgkACIgFgUIAgAAQAKAAAEgEQAEgDAAgJIAAg6Ig7AKIgEgSIA/gLIAAg4Ig/AAIAAgTIA/AAIAAgvIgzAGIgEgTQAfgCBWgMIAEASIgtAHIAAAxIBOAAQgDg3AAghIAUAAQAAAiACA2IBoAAIAAATIhnAAIAEAhQADAdAFARQAOgMAOgQQANgPANgQIARALQgTAYgRARQgQASgNALIAKAYQAOAZASAAQAGAAAEgEQADgDAEgHIAGgoIAUAIQgEAagGAPQgEAOgJAGQgHAGgLAAIgCAAgAl5CCQgMgKgKgTQgHgMgGgRQgPALgSAKQgSAKgVAJQgHgKgHgGQAYgLAUgLQAVgLAQgMQgFgVgEgcIgDglIgxAFIgCgSIAygFQgDgbAAg7IAUAAQAAA5ACAaIBggMIACATIhgAMIAJBLQAQgOAPgPQAOgOANgRIAPAMQgOASgRASQgSARgSAQQAEATAIAPQAPAZARAAQAFAAAFgEQADgDADgHQAHgaAAgPIATAHQgDAagGAPQgEAOgIAHQgIAHgNAAQgOAAgNgJgAAUCKIAAjkIAeAAQAJgbAEgUIAVAEIgOArIA5AAIAADhIgSAAIAAgXIhHAAIAAAagAAmBhIBHAAIAAhMIhHAAgAAmACIBHAAIAAhKIhHAAgApDCKIgDgTIAXAAQALABAEgFQAFgEgBgIIAAhNIgxALIgDgVIA0gIIAAhGIgwAAIAAgRIAwAAIAAg4IATAAIAAA4IAqAAIAAARIgqAAIAABCIAugHIABASIgvAIIAABTQABAgghAAgAF3CJQABgGgEgKIgBgGIAtACQAaABgCgWIAAgvIiDAAIAAgTICDAAIAAg5IhuAAIAAgRIBuAAIAAg4IhvADIgDgTQBVgBCWgIIADATQgPAAggACIg4ACIAAA6IBoAAIAAARIhoAAIAAA5ICCAAIAAATIiCAAIAAAzQABASgKAJQgKAKgVAAgACwCHQgBgKgDgKIAwAAQASACAIgIQAJgIAAgRQADgbAAhcIABglIhQAAQgQAigJAOQgHgGgJgEQANgWAMgaQAKgaAKgdIATAEIgQArIBeAAIgFCwQAAAYgNAMQgNANgZAAgAt5CDIAAgSIEXAAIAAASgAtQBWIAAhuIDGAAIAABugAs9BGICfAAIAAggIifAAgAs9AXICfAAIAAgfIifAAgACjgKIAOgLIAHAKQAaAfAOAUIgQAMQgaglgTgZgAt8geQAkgMAfgPQAdgPAYgTIhvAAIAAgQIB8AAIAAgfIATAAIAAAfIB8AAIAAAQIhxAAQAzApBFAPIgJATQgqgNgdgRQgfgRgUgVIAAAyIgTAAIAAgxQguAqhNAdQgDgKgHgIgAhchuIAOgNQAZAUAXAXIgOAOQgjgigNgKgAljhUQgXgTgOgJIALgNIAuAhIgMAOg");

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AD4CNIAAgSIhkAAIAAASIgSAAIAAi7ICJAAIAAC7gACUBrIBkAAIAAgiIhkAAgACUA6IBkAAIAAglIhkAAgACUAGIBkAAIAAgjIhkAAgAA0CNIAAh0QgRAwgYAdIgKgTQAegjATg0IgpAAIAAgQIArAAIAAgoIATAAIAAAoIAmAAIAAAQIgmAAIAAAhIAIgIIAjAgIgMANIgfgfIAABqgAh1CNIAAkBIBfAAIAAAUIgeBQQARAQAJARQAJASgBATQAAAvgnACIgbAAIgBgJIgCgKIAXAAQAPABAGgIQAHgIgBgQQAAgRgJgRQgJgQgSgPIAhhWIg7AAIAADvgAipCAIAAgVIhfAAIAAAVIgSAAIAAjXIA4AAIAAgyIASAAIAAAyIA6AAIAADXgAjQBaIAnAAIAAhIIgnAAgAkIBaIAmAAIAAhIIgmAAgAjQAAIAnAAIAAhGIgnAAgAkIAAIAmAAIAAhGIgmAAgAAEhEQARgOANgSQAOgSAKgWIASAEIgOAZIBVAAIAAAQIhgAAQgVAdgOAMgADJhSIAMgJQAOALALAOIgNALgABeg8IgVgWIANgLIAYAaIgOALgACag9IgOgIQAOgQAMgSQAKgRAIgUIATAEIgMAZIBcAAIAAAQIhlAAQgLATgPARg");

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AHSCBQALgPAHgPQAGgPADgOQAEgNACgVQABgWAAgcIAAhsIDpAAIAADgQACASgKAIQgJAJgUAAIgjABIgEgVIAiABQALAAAGgEQAGgFAAgJIAAg1IhaAAIAABZIgTAAIAAhZIhXAAQgBAXgJAYQgIAYgPAYgAJwAdIBaAAIAAg4IhaAAgAIHAdIBWAAIAAg4IhVAAgAJwguIBaAAIAAg5IhaAAgAIIguIBVAAIAAg5IhVAAgAiEB/QAogYAUgiQAUgiAAgrQACgVACgpIhQAAIAAgTICKAAQgJgagIgTIAUgEIATAsIgRAFICFAAIAAATIiwAAQAAAcgDAaICMAAQgCAsgEA1QgBAagPANQgOANgeAAIgsAAIgFgWIAvAAQAUACALgIQAKgJABgTQACgRADgwIAAgLIh4AAQgCAtgVAkQgVAjgoAZgApYCOIAAhTQgUAYgfATQgeATgpAOIgLgSQAmgJAdgQQAdgPATgWIhcAAIALg+IBjAAIAAghIhnAAIAAgQIDhAAIAABAIhoAAIAAAgIB3AAIgEAvQAAAQgKAIQgKAJgUAAIglAAQAAgLgEgGIAmABQAZACAAgXIACgcIhjAAIAABXgAqwAoIBYAAIAAggIhSAAgApGgHIBVAAIAAghIhVAAgACmB/QAKgPAHgOQAGgPADgOQADgNABgWIACiDIB5AAIgNgnIAUgEIADAMQAIAUADALIBpAAIAAARIjjAAIAAA8QAAAfgCAYQgCAYgDAQQgEAQgHAQQgHAQgKARgADfB6IAAgQICGAAQAQgrAMgnQANglAJgiIASAFQgfBmgQAuIBHAAIAAAQgAmsB2IAAgSIEVAAIAAASgADugjIARgFQAXBJAKAoIgTAEQgKgngVhJgAE1gxIASgEIAaBwIgUAEgAmMAJIAAgSIDUAAIAAASgArdhIQATgOAOgRQAOgSAKgUIATADIgOAYIBUAAIAAAQIhAAAIAZAcIgPAJIgZgdIALgIIgaAAQgUAXgSAQQgDgGgLgHgAoZhaIAMgIIgeAAIgMARIgPAQIgCgCIgNgIQAPgPAMgQQALgRAHgSIAUADIgEAHQgCAHgHAKIBeAAIAAAQIhHAAIAbAcIgOAJQgOgQgOgNgAmahZIAAgUIDwAAIAAAUg");

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aj0B/QAQgTAJgeQAKgfABgqIABhJIgWAAIAAgRIAxAAQgCgMgLgcIgCgIIATgEIADAMQAIAUADAPIgSAFIAyAAIAAARIg7AAIgBAxIA1AAIgDB2QAAARgIAJQgJAIgRAAIgTAAIgEgTIARABQALABAGgFQAFgEABgKIADhkIgkAAIAAAEIgCAFQgBAugJAhQgJAhgSAWgADdB9QgNgOgMgcQgKAKgQAMQgPAMgWANIgNgRQAUgLASgNQARgNAPgOQgGgUgEgZQgEgYgBgeIgtAFIgCgSIAugGQgDgxAAgiIAUAAIABBRIBegLIABATIheALIAFAvQADAWAEAQQAOgQANgRQANgRALgTIARALQgQAXgPAUQgPAVgPAPQAIAZAKANQAKAMAKABQAGAAAEgDQAEgEADgIIAHgnIATAHQgEAZgGARQgEANgHAGQgJAHgNAAQgPAAgOgOgAkcCEQAShBAIgnQAHABAMAGIgaBogAh2B6IgBgFQAIABAVAAQAKAAAEgEQAFgEgBgJIAAg9Ig0AAIAAgQIA0AAIAAgTIAkgjIhIAAIAAgQIBdAAIAAASIgnAnIAAANIAwAAIAAAQIgwAAIAABBQAAAPgHAIQgIAHgRAAQgJACgUAAgAAHBwQAUgTAPgVQAQgUAKgWIgRgaQgYgkgMgQIAQgJIAuBCQAOgoAHg2IhTAAIAAgSIBmAAIAAATQgFAigHAcQgGAbgJAXIAnA9IgQAMIgig0QgTArgoAmgAkkgrIANgOIAoAiIgOAOgAiKgsQAQgVAMgXQAMgYAIgbIAUAEQgIAUgIATIBQAAIAAARIhYAAQgRAhgLAOgADyhVQgWgRgMgHIALgOQAiAVAOAMIgNAOgAkah3IAOgMQAWATAOANIgOAOg");

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AkiE5QAKgPAHgPQAHgPADgOQADgNACgVQACgWAAgdIAAhsIDpAAIAADhQABASgJAIQgKAJgUAAIgjABIgDgVIAiABQALAAAFgEQAGgFAAgJIAAg1IhZAAIAABZIgUAAIAAhZIhXAAQgBAXgIAYQgIAYgPAYgAiEDVIBZAAIAAg5IhZAAgAjtDVIBVAAIAAg5IhUAAgAiECJIBZAAIAAg5IhZAAgAjsCJIBUAAIAAg5IhUAAgAE1E3QAigsgDhhIAAhbIB5AAIgOgeIAVgGIAPAkIBtAAIAAARIjpAAIAABMQABA0gIAmQgJAmgSAZgAA4FFIAAiJQgQAwgXAgIgLgSQAQgWAMgZQAMgZAIgdIgqAAIAAgSIAsAAIAAgyIgnABIgBgGQAAgHgDgEIBigGIACAQQgVAEgTABIAAAzIAoAAIAAASIgoAAIAAAnIAIgHIAmAjIgNAOIghgjIAACCgApOE3QAKgPAGgOQAHgPADgOQACgNACgWIABiEIB5AAIgNgnIAUgEIAEAMQAIAUACALIBqAAIAAARIjkAAIAAA8QAAAggBAYQgCAYgEAQQgDAQgHAQQgHAQgLARgAGlFAIgCgIIgCgMIAkABQAKAAAFgEQAFgEAAgJIAAhBIhhAAIAAgRIBoAAIg6gjIAMgPIAsAbIA8glIiUAAIAAgQICzAAIAAASIhLAtIAFADIgJAKIBiAAIAAARIgXAzIgSgHIAVgsIhLAAIAABDQAAAQgIAJQgJAIgRABgABpE2IAAgRIBYAAIAAgrIhCAAIAAgPIBCAAIAAgsIhJAAIAAgQICkAAIAAAQIhIAAIAAAsIBCAAIAAAPIhCAAIAAArIBTAAIAAARgAoWEyIAAgQICHAAQAQgrAMgnQAMgmAJgiIATAFQgfBngQAuIBGAAIAAAQgAoHCUIASgFQAXBKAKAoIgTAEQgKgngWhKgAm/CGIARgEIAaBxIgUAEgACECPIAAhRICOAAIAABRgACYB+IBmAAIAAgvIhmAAgAE/g7QBNgKA7gaQA7gbApgpIhqAAQgMAJgNAHIAtAhIgPANIgvgkQgmATgYAJIgMgSQAtgPAlgVQAlgVAdgaIATAIIgbAWIBsAAIAAATQgqAug/AeQhAAehUAPgAAMg6QBBgNAXgLQgNgIgMgKQgNgKgMgMIAOgLQANAMANAJQANAKAMAHQAJgJAGgLQAFgLADgOIhgAAIAAh3IBmAAIAAggIh9AAIAAgQIEIAAIAAAQIh5AAIAAAgIBkAAIAACFIgTAAIAAgOIhVAAQgDARgGANQgGANgJAKQAQAFAwAIQAaADBEADIgJAUQg7gDgpgHQgpgHgXgKQgLAJgYAJQgYAJglAIgACfidIBUAAIAAgjIhSAAgAA8idIBQAAQACgOAAgVIhSAAgAChjQIBSAAIAAgjIhRAAgAA8jQIBSAAIAAgjIhSAAgAnvg6QAjgTATgcQATgcADglIg9AAIAAgSIA/AAIABg0IAUAAQAAAWgCAeIBYAAIAAASIhVAAQARBMBHAhIgNATQgjgUgVgbQgWgbgIgiQgFAigTAbQgSAcghAVgAj5gpIAAiBQgPATgSAQIgBgEIgHgPQAUgTASgYQASgXAPgcIARAKIgcArIAACagAh+hBIAnABQALABAGgEQAFgEAAgIIAAgoIiMAAIAAgQICMAAIAAgbIiAAAIAAgQIC2AAIAAAQIgjAAIAAAbIApAAIAAAQIgpAAIAAAoQABARgJAIQgJAJgTgBIgmABgAo4guIgDgTIAaABQAQABAIgIQAIgIgBgQQAAgagEgWQgLARgPAOQgPAPgTAMQgCgEgHgHIgDgFQAVgNARgPQARgPAMgSQgEgNgGgKQgUAOgcAPIgDgFIgHgMQASgIAegUQgIgLgYgZIAOgLQATASAOASQAPgOAOgSIAPALQgRAVgSAPQANASAFAaQAGAaAAAhQABAXgMAMQgLAMgYABgAi0hlIAOgMQATARAPARIgPALgAFCikIgHgQQBJgQA4gYQA4gZAoggIh9AAIgOAKIAvAgIgPANQgfgZgRgLQgbAQgTAJIgEgJIgGgIQAkgPAegTQAdgTAXgWIAVAFQgOAOgQANICCAAIAAARQgrAmg9AdQg9AdhQATgAl7jiIALgNIAnAbIgMAOQgXgUgPgIgAiyjMIAAhoICVAAIAABogAifjdIBxAAIAAgcIhxAAgAifkIIBxAAIAAgdIhxAAgAkej2QATgPARgTQARgSAPgXIASAKQgQAXgTAVQgTAUgWASQgEgJgGgIgAmVj/IAAgRIhPAAIAAARIgTAAIAAgRIhTAAIAAgSIBTAAIAAgfIATAAIAAAfIBPAAIAAgfIATAAIAAAfIBPAAIAAASIhPAAIAAARg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},20).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.7,-13.2,87.5,26.4);


(lib.表盘bgG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer 1
	this.instance = new lib.表盘11bg();
	this.instance.parent = this;

	this.instance_1 = new lib.表盘13bg();
	this.instance_1.parent = this;

	this.instance_2 = new lib.表盘18bg();
	this.instance_2.parent = this;

	this.instance_3 = new lib.表盘23bg();
	this.instance_3.parent = this;

	this.instance_4 = new lib.表盘26bg();
	this.instance_4.parent = this;

	this.instance_5 = new lib.表盘28bg();
	this.instance_5.parent = this;

	this.instance_6 = new lib.表盘33bg();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


(lib.表盘35_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘35();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘35_1, new cjs.Rectangle(-29.5,-29.5,59,59), null);


(lib.表盘34_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘34();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘34_1, new cjs.Rectangle(-29.5,-29.5,59,59), null);


(lib.表盘33_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘33();
	this.instance.parent = this;
	this.instance.setTransform(-29,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘33_1, new cjs.Rectangle(-29,-29,58,58), null);


(lib.表盘32_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘32();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘32_1, new cjs.Rectangle(-29.5,-29.5,59,59), null);


(lib.表盘31_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘31();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘31_1, new cjs.Rectangle(-29.5,-29.5,59,59), null);


(lib.表盘28_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘28();
	this.instance.parent = this;
	this.instance.setTransform(-29,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘28_1, new cjs.Rectangle(-29,-29,58,58), null);


(lib.表盘27_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘27();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘27_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘26_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘26();
	this.instance.parent = this;
	this.instance.setTransform(-29,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘26_1, new cjs.Rectangle(-29,-29,58,58), null);


(lib.表盘25_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘25();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘25_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘24_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘24();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘24_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘23_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘23();
	this.instance.parent = this;
	this.instance.setTransform(-29,-28.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘23_1, new cjs.Rectangle(-29,-28.5,58,57), null);


(lib.表盘22_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘22();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘22_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘21_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘21();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘21_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘19();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘19_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘18();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘18_1, new cjs.Rectangle(-29.5,-29,59,58), null);


(lib.表盘17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘17();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘17_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘16();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘16_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘15();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘15_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘14();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘14_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘13();
	this.instance.parent = this;
	this.instance.setTransform(-29.5,-29.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘13_1, new cjs.Rectangle(-29.5,-29.5,59,59), null);


(lib.表盘12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘12();
	this.instance.parent = this;
	this.instance.setTransform(-28,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘12_1, new cjs.Rectangle(-28,-28,56,56), null);


(lib.表盘11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘11();
	this.instance.parent = this;
	this.instance.setTransform(-29,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘11_1, new cjs.Rectangle(-29,-29,58,58), null);


(lib.表盘10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘10();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘10_1, new cjs.Rectangle(-32.5,-31,65,62), null);


(lib.倒计时数字 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// 数字0-9
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah5H9Qg1gRglgjQglgigSgwQgTgwAAg7IAAoXQAAg8ATgvQASgxAlghQAkgjA1gRQA2gTBEAAQBEAAA2ATQA1ARAlAjQAlAhASAxQATAwAAA7IAAIXQAAA7gTAwQgSAwglAiQgkAjg1ARQg2AThFAAQhDAAg2gTgAgmlSQgQAQAAAmIAAI5QAAAlAQAQQANANAZAAQAZAAANgNQAQgQABglIAAo5QgBgmgQgQQgNgMgZAAQgZAAgNAMg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdH/IAAr+IikAAIAAiSQBBgDAygYQAcgOATgTQAVgVAKgcIDCAAIAAP9g");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AkpIHIAAg/QADhQAShDQAPg8Adg1QAihCBaheQBohlAQgXQAagjANgkQAPgoAAguQAAgtgKgVQgOgfgnAAQgmAAgPAfQgKAVAAAtIAABnIjYAAIAAhRQAEhNASg2QASg4AigkQAjglA2gRQA2gSBMAAQBDAAAzAQQA1ARAjAiQAmAiARAzQAUA0AABDQAAAxgKArQgJAogRAjQgRAhgXAfIgwA2QiZCFg4BjIgXA5IFcAAIAADAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah4IAQg2gQglggQgmgigUgxQgUgzAAhCIAAhiIDfAAIAABrQAAAiAOAUQAPAYAiAAQAgAAAQgYQANgUAAgiIAAhJQAAgugFgaQgHgdgPgRQgPgQgcgHQgcgHgvAAIAAioIAoAAQAoAAAbgUQAfgXAAgkIAAhVQAAgggKgRQgOgVgeAAQgdAAgPASQgOASAAAnIAABBIjfAAQgEhNAMg4QAMg8AggnQAigqA4gVQA7gWBTAAQBCAAAxANQA1AOAkAdQAmAfATAxQAVA0AABHQgDBegRAmQgNAegVAXQgYAYgkARQAmAMAZAZQAXAWAOAiQANAdAFAnIAEBNQAABUgNA5QgOBAggApQghArg4AVQg5AWhVAAQhDAAg1gQg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgBH/IAAjBIkqAAIAAjXQAphXA8jWQAbhsAVjMIDvAAQgHBSgYBXQgWBSgkBWQghBRgsBPQgqBLgxBGICnAAIAAiKQAsg+AlhRQAnhUAQhHIBXAAIAAG0IBOAAIAAC6IhOAAIAADBg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah4H4Qg2gRglggQgmghgUgxQgUgzAAhCIAAhaIDfAAIAABjQAAAhAOAVQAPAYAiAAQAgAAAQgYQANgVAAghIAAjgQAAgjgNgSQgQgYggAAQgiAAgPAYQgOASAAAjIjIAAIAAovIILAAIAADAIlKAAIAACZIACAAQApgdBRgKQA+gBAvATQAsAQAeAiQAcAgAOAvQAOAtAAA4IAACQQAABSgPA8QgOBBghAqQgiAtg3AWQg5AYhSgBQhDAAg1gPg");

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah5H9Qg1gRglgjQglgigSgwQgTgwAAg7IAAoXQAAg8ATgvQASgxAlghQAkgjA1gRQA2gTBEAAQBAAAAxAOQAzAPAiAfQAkAgASAyQASAzABBFIjRAAQAAgpgNgVQgQgXghAAQggAAgQAXQgNAVAAApIAAB1IADACQAagjAdgNQAZgKAwAAQA+AAAsAUQAoAUAZAlQAWAjAMA0QAJAsACA+IAADKQAAA7gTAwQgSAwglAiQgkAjg1ARQg2AThFAAQhDAAg2gTgAgmgPQgQAPAAAmIAAD3QAAAlAQAQQANANAZAAQAZAAANgNQAQgQABglIAAj3QgBgmgQgPQgNgNgZAAQgZAAgNANg");

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ai1H/IAJhtQAIhSAThSQAShOAbhOQAihnBcjIIAvhhIlyAAIAAjAIJTAAIAACtIg5BkQgiBCgdBRQgdBNgWBUIgjCnQgOBSgGBNIgHByg");

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ah5H9Qg1gRglgjQglgigSgwQgTgwAAg7IAAhWQAAhRAOgoQAMggAXgYQAbgaApgQQgdgMgXgUQgTgSgOgXQgWgogCgvIAAhGQAAgrAEgcQAIgyAXglQAdguA2gZQAegPAmgHQAqgJAxAAQAyAAAqAJQAmAHAeAPQA2AZAdAuQAXAlAIAyQAEAcAAArIAABGQgBAugXAnQgOAYgVASQgXAUgfANQApAPAaAWQAYATAMAdQALAZAEAlIADCeQAAA7gTAwQgSAwglAiQgkAjg1ARQg2AThFAAQhDAAg2gTgAgmBCQgQAQAAAmIAAClQAAAlAQAQQANANAZAAQAZAAANgNQAQgQABglIAAilQgBgmgQgQQgNgNgZAAQgZAAgNANgAgmlSQgQAQAAAmIAABfQAAAmAQAQQANANAZAAQAZAAANgNQAQgRABglIAAhfQgBgmgQgQQgNgMgZAAQgZAAgNAMg");

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhwIBQgzgPgigeQgkghgSgxQgSgzgBhGIDRAAQAAAqANAVQAQAXAgAAQAhAAAQgXQANgVAAgqIAAhzIgDgDQgaAkgdAMQgZAKgwAAQg+AAgsgVQgogTgZgmQgWgigMg0QgJgsgCg+IAAjKQAAg8ATgvQASgxAlghQAkgjA1gRQA2gTBEAAQBEAAA2ATQA1ARAlAjQAlAhASAxQATAwAAA7IAAIXQAAA7gTAwQgSAwglAiQgkAjg1ARQg2AThFAAQg/AAgxgPgAgllSQgQAQgBAmIAAD3QABAlAQAQQANAMAYAAQAaAAANgMQAQgQAAglIAAj3QAAgmgQgQQgNgMgaAAQgYAAgNAMg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.6,-52.7,57.3,105.6);


(lib.倒数开始go = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AGhOcQhlgmhIhGQhIhHgnhjQgmhkAAh7IAAtNQAAiFAphpQAohjBLhEQBJhCBmgiQBlghB4AAQB6AABjAhQBmAiBJBCQBMBEAmBjQArBpAACFIAANNQAAB7gnBkQglBjhKBHQhHBGhmAmQhoAlh+AAQh+AAhoglgAIbo4QgPAiAABKIAAOYQAACqB7AAQB8AAAAiqIAAuYQAAiph8AAQhRAAgbA9gAvkOVQhLgpguhOQgrhHgVhlQgShaAAhxIAAtNQAAiFAphpQAohjBLhEQBIhCBngiQBlghB4AAQB0AABdAXQBoAXBIA0QBQA2ArBWQAtBcAAB+IAADQImYAAIAAi6QgBhIgggkQgggnhGAAQhMAAghA+QgYAtAAA+IAAOYQAACqB7AAQBIAAAggiQAigiAAhIIAAjwIiYAAIAAlXII3AAIAAQAIl4AAIAAiYIgEAAQg6BfhQArQhQAshxAAQhwAAhPgsg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.倒数开始go, new cjs.Rectangle(-120,-96.1,240,192.3), null);


(lib.倒数开始3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjYOWQhhgehCg4QhEg9gjhYQglhbAAh3IAAivIGQAAIAAC/QAAA+AZAjQAcArA9AAQA5AAAdgrQAYgjAAg+IAAiCQAAhTgLgvQgLg0gbgdQgbgdgzgOQgxgLhWgBIAAkuIBIAAQBIAAAwgkQA4goAAhCIAAiXQAAg6gSgeQgYgng2ABQg1AAgaAfQgaAigBBGIAAB0ImOAAQgIiLAVhjQAXhsA4hHQA+hKBkgmQBpgnCWAAQB2AABZAXQBeAZBBA1QBFA3AiBXQAlBdAACAQgHCpgdBEQgWA2gnApQgrArhBAeQBEAWAuAsQAqAoAYA9QAWA0AJBGIAICKQAACXgYBnQgZByg4BIQg8BOhkAlQhmAoiZAAQh5AAhfgcg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.倒数开始3, new cjs.Rectangle(-52,-94.6,104,189.2), null);


(lib.倒数开始2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AoVOjIAAhyQAGiOAfh5QAchsAyheQA/h4ChinQC5i2AfgqQAug/AYhAQAbhHAAhTQgBhRgSgmQgag2hGAAQhEAAgaA2QgSAmAABRIAAC4ImDAAIAAiQQAHiKAghhQAfhlA+hAQA+hCBhggQBiggCJAAQB3AABcAeQBfAfA/A8QBDA+AhBbQAiBcAAB5QgBBYgQBMQgQBIggBAQgdA6gqA3IhYBiQkRDuhlCyIgqBmIJyAAIAAFZg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.倒数开始2, new cjs.Rectangle(-53.3,-93.1,106.7,186.1), null);


(lib.倒数开始1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag1OUIAA1eIklAAIAAkFQBzgGBZgrQA0gYAhgjQAngmARgyIFcAAIAAcng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.倒数开始1, new cjs.Rectangle(-34.7,-91.6,69.5,183.1), null);


(lib.TopIcon7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgACJCaIg/ifQgagHgTgOQgSgPgFgRQgKghALgcIAOgVIg9AAIhxEmIA+AAIAYhDIBzAAIAZBDIBAAAgAAqiAQgQAQAAAXQAAAXAQARQARAQAXAAQAYAAARgQQAQgQAAgYQAAgXgQgQQgRgQgYAAQgXAAgRAQgAgxAmIAnhtIAnBtgABKg1IAAgcIgcAAIAAgTIAcAAIAAgdIATAAIAAAdIAbAAIAAATIgbAAIAAAcg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F47610").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgACJCaIg/ifQgagHgTgOQgSgPgFgRQgKghALgcIAOgVIg9AAIhxEmIA+AAIAYhDIBzAAIAZBDIBAAAgAAqiAQgQAQAAAXQAAAXAQARQARAQAXAAQAYAAARgQQAQgQAAgYQAAgXgQgQQgRgQgYAAQgXAAgRAQgAgxAmIAnhtIAnBtgABKg1IAAgcIgcAAIAAgTIAcAAIAAgdIATAAIAAAdIAbAAIAAATIgbAAIAAAcg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABNBNQBMBMAABrQAABshMBNQhNBMhsAAQhrAAhMhMgAB0CaIgOgjIjEAAIgOAjIDgAAgAhLg4IgTAqIAABwIDEAAIAAh3QgFgTgOgTQgdgngzAAQgxAAgdAqgACehlIgwAcQgEACAAAEQgBAEACADQACADAEABQADABAEgCIAwgdQAHgFgEgHQgEgFgEAAQgCAAgDACgAiehnQgDABgCAEQgCADAAADQABAEAEACIAwAdQADACAEgBQAEgBACgDQACgDgBgEQgBgEgEgCIgwgcQgCgCgDAAIgCAAgABAixIgZAxQgCADACAEQABADAEACQADACAEgCQADgBACgDIAZgyQABgDgBgEQgBgDgEgCIgFgBQgEAAgDAGgAhFi2QgEACgBADQgBAEACADIAYAyQACADAEABQADACAEgCQADgCABgDQACgEgCgDIgYgxQgDgGgFAAIgFABgAhJAjIAAgqQAAgGACgJQAFgSAOgQQANgOAQgFQAIgCAFAAIAbAAQAHALgHAKIgbAAQgJABgIAHQgSANAAAcIAAAqg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0D00").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABNBNQBMBMAABrQAABshMBNQhNBMhsAAQhrAAhMhMgAB0CaIgOgjIjEAAIgOAjIDgAAgAhLg4IgTAqIAABwIDEAAIAAh3QgFgTgOgTQgdgngzAAQgxAAgdAqgACehlIgwAcQgEACAAAEQgBAEACADQACADAEABQADABAEgCIAwgdQAHgFgEgHQgEgFgEAAQgCAAgDACgAiehnQgDABgCAEQgCADAAADQABAEAEACIAwAdQADACAEgBQAEgBACgDQACgDgBgEQgBgEgEgCIgwgcQgCgCgDAAIgCAAgABAixIgZAxQgCADACAEQABADAEACQADACAEgCQADgBACgDIAZgyQABgDgBgEQgBgDgEgCIgFgBQgEAAgDAGgAhFi2QgEACgBADQgBAEACADIAYAyQACADAEABQADACAEgCQADgCABgDQACgEgCgDIgYgxQgDgGgFAAIgFABgAhJAjIAAgqQAAgGACgJQAFgSAOgQQANgOAQgFQAIgCAFAAIAbAAQAHALgHAKIgbAAQgJABgIAHQgSANAAAcIAAAqg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAg/gjQgtBKAAAgQAAAmAaAbQAaAbAlAAQAkAAAagbQAagbAAgmQAAgggthKIgrhFQgWAfgWAmgABIh9QgeAxAAAVQAAAZASASQARARAZAAQAZAAARgRQASgSAAgZQAAgVgegxIgegtQgPAVgPAYgAiWiFQgYApAAARQAAAVAOAPQAOAOAUAAQAVAAAOgOQAOgPAAgVQAAgRgYgpIgZglQgMARgMAUg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#17B1BC").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAg/gjQgtBKAAAgQAAAmAaAbQAaAbAlAAQAkAAAagbQAagbAAgmQAAgggthKIgrhFQgWAfgWAmgABIh9QgeAxAAAVQAAAZASASQARARAZAAQAZAAARgRQASgSAAgZQAAgVgegxIgegtQgPAVgPAYgAiWiFQgYApAAARQAAAVAOAPQAOAOAUAAQAVAAAOgOQAOgPAAgVQAAgRgYgpIgZglQgMARgMAUg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAgkBTQgGAIgMAHQgMAGgJABQAOAbAbAPQAaAQAfAAQAuAAAhgfQAgggAAgsQAAgvgkgfQgYADgWgJIgRgJQg6BogNAQgAiCgcQgZAEgKASQgLASAJAWQAJAWAYAMQAYANAYgDQAYgEALgTIABgCIBNiDQAVAaAlADQASABAOgEQglgKgOgiQgIgUACgUQABgHgGgEQgEgCgEABQgFACgCADIhaCcQgKgTgWgNQgTgKgTAAIgKABgAA4BWQAFgFACgGIAvAZQgGANgLAKgAAABPQgJgJAAgOQAAgNAJgJQAJgKAOAAQAOAAAKAKQAKAJAAANQAAAOgKAJQgKAKgOAAQgOAAgJgKg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CB5879").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAgkBTQgGAIgMAHQgMAGgJABQAOAbAbAPQAaAQAfAAQAuAAAhgfQAgggAAgsQAAgvgkgfQgYADgWgJIgRgJQg6BogNAQgAiCgcQgZAEgKASQgLASAJAWQAJAWAYAMQAYANAYgDQAYgEALgTIABgCIBNiDQAVAaAlADQASABAOgEQglgKgOgiQgIgUACgUQABgHgGgEQgEgCgEABQgFACgCADIhaCcQgKgTgWgNQgTgKgTAAIgKABgAA4BWQAFgFACgGIAvAZQgGANgLAKgAAABPQgJgJAAgOQAAgNAJgJQAJgKAOAAQAOAAAKAKQAKAJAAANQAAAOgKAJQgKAKgOAAQgOAAgJgKg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAh7h5QgyAyAABGQAAAdAMAfQACAHAEAGQAUApAoAbIAMAHQAlAUAsAAQAqAAAlgUIANgHQAogbAUgpIAGgNQAMgfAAgdQAAhGgygyQgygyhGAAQhHAAgyAygAg/CCQAMgRAAgTQAAgZgSgSQgSgRgZAAQgPAAgPAIQgHgWAAgVQAAg8ArgrQArgqA9AAQA7AAArAqQArArAAA8QAAAVgHAWQgOgIgQAAQgZAAgSARQgSASAAAZQAAAUAMAQQgeANgdAAQgfAAgegNgAgrgmQAJAZAIAQIgBAHQAAAKAHAHQAIAHAKAAQAGAAAGgEIAAAAQALgIAAgMQAAgKgGgGQgHgGgIgBQgMgPgUgRIgSgPgABigKQgEAEAAAFQAAAEAEADQADAEAFAAQAFAAAEgEQAEgDAAgEQAAgFgEgEQgDgDgGAAQgFAAgDADgAh5gKQgDAEAAAFQAAAEADADQAEAEAFAAQAFAAAEgEQADgDAAgEQAAgFgDgEQgEgDgFAAQgFAAgEADgABWhCQgFACgBAFQgBAFACAEQADAFAFABQAFABAEgCQAEgDACgFQABgFgDgEQgCgEgFgCIgDAAQgDAAgDACgAhlhEQgFACgCAEQgCAEABAFQABAFAEADQAFACAFgBQAFgBACgFQADgEgCgFQgBgFgEgCQgDgCgEAAIgDAAgAAwhrQgEABgDAEQgCAFABAFQABAEAEADQAFACAFgBQAFgBACgFQADgEgBgFQgCgFgEgCIgGgCIgEABgAg/hqQgFACgBAFQgBAFACAEQADAFAFABQAFABAEgCQAEgCACgFQABgFgDgFQgCgEgFgBIgDgBIgGACgAgLh3QgEAEAAAFQAAAFAEADQADAEAGAAQAEAAADgEQAEgDAAgFQAAgFgEgEQgDgDgEAAQgFAAgEADgAA6BeQAAgUAOgOQAOgOAUAAQANAAANAHQgTAugtAZQgKgNAAgRgAiKA1QANgHANAAQAUAAAOAOQAPAOAAAUQAAARgLANQgsgYgUgvg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9EAB38").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAh7h5QgyAyAABGQAAAdAMAfQACAHAEAGQAUApAoAbIAMAHQAlAUAsAAQAqAAAlgUIANgHQAogbAUgpIAGgNQAMgfAAgdQAAhGgygyQgygyhGAAQhHAAgyAygAg/CCQAMgRAAgTQAAgZgSgSQgSgRgZAAQgPAAgPAIQgHgWAAgVQAAg8ArgrQArgqA9AAQA7AAArAqQArArAAA8QAAAVgHAWQgOgIgQAAQgZAAgSARQgSASAAAZQAAAUAMAQQgeANgdAAQgfAAgegNgAgrgmQAJAZAIAQIgBAHQAAAKAHAHQAIAHAKAAQAGAAAGgEIAAAAQALgIAAgMQAAgKgGgGQgHgGgIgBQgMgPgUgRIgSgPgABigKQgEAEAAAFQAAAEAEADQADAEAFAAQAFAAAEgEQAEgDAAgEQAAgFgEgEQgDgDgGAAQgFAAgDADgAh5gKQgDAEAAAFQAAAEADADQAEAEAFAAQAFAAAEgEQADgDAAgEQAAgFgDgEQgEgDgFAAQgFAAgEADgABWhCQgFACgBAFQgBAFACAEQADAFAFABQAFABAEgCQAEgDACgFQABgFgDgEQgCgEgFgCIgDAAQgDAAgDACgAhlhEQgFACgCAEQgCAEABAFQABAFAEADQAFACAFgBQAFgBACgFQADgEgCgFQgBgFgEgCQgDgCgEAAIgDAAgAAwhrQgEABgDAEQgCAFABAFQABAEAEADQAFACAFgBQAFgBACgFQADgEgBgFQgCgFgEgCIgGgCIgEABgAg/hqQgFACgBAFQgBAFACAEQADAFAFABQAFABAEgCQAEgCACgFQABgFgDgFQgCgEgFgBIgDgBIgGACgAgLh3QgEAEAAAFQAAAFAEADQADAEAGAAQAEAAADgEQAEgDAAgFQAAgFgEgEQgDgDgEAAQgFAAgEADgAA6BeQAAgUAOgOQAOgOAUAAQANAAANAHQgTAugtAZQgKgNAAgRgAiKA1QANgHANAAQAUAAAOAOQAPAOAAAUQAAARgLANQgsgYgUgvg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABNBNQBMBMAABrQAABshMBNQhNBMhsAAQhrAAhMhMgAiTA+IA2AAQABAoAbAcQAbAcAmAAQAlAAAbgcQAcgcABgoIAwAAIAAiaIhUAAIAAg3QgDgMgMAAQgMABgDALIAAA3IgLAAIAAhDQgGgMgJAAQgJAAgFAMIAABDIgLAAIAAg3QgFgLgKAAQgKgBgFAMIAAA3IgLAAIAAgrQgEgKgKgBQgKgBgGAMIAAArIg0AAgABbA2IAAhHQgEgVgKgCQgKgCgGAZIAABHIjHAAIAAiJIENAAIAACJgAguAQIAZAAIAAASIAXAAIAAgSIAYAAIAAgMIgYAAIAAgJIAYAAIAAgNIgUAAIAcgrIgXAAIgTAnIAAAAIgUgnIgZAAIAcArIgVAAIAAANIAZAAIAAAJIgZAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#29A9DC").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABNBNQBMBMAABrQAABshMBNQhNBMhsAAQhrAAhMhMgAiTA+IA2AAQABAoAbAcQAbAcAmAAQAlAAAbgcQAcgcABgoIAwAAIAAiaIhUAAIAAg3QgDgMgMAAQgMABgDALIAAA3IgLAAIAAhDQgGgMgJAAQgJAAgFAMIAABDIgLAAIAAg3QgFgLgKAAQgKgBgFAMIAAA3IgLAAIAAgrQgEgKgKgBQgKgBgGAMIAAArIg0AAgABbA2IAAhHQgEgVgKgCQgKgCgGAZIAABHIjHAAIAAiJIENAAIAACJgAguAQIAZAAIAAASIAXAAIAAgSIAYAAIAAgMIgYAAIAAgJIAYAAIAAgNIgUAAIAcgrIgXAAIgTAnIAAAAIgUgnIgZAAIAcArIgVAAIAAANIAZAAIAAAJIgZAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.TopIcon1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAhqCaQAuANA5AAQA3ABAvgOIAAjAIA4AaQAFACADgEIAQgWQAPgUAGgLQAFgIgFgBIhYgzQgCgDgHgDQgMgHgSAAIgZAAQAAANgGANQgNAaggAAQgNgBgNgHQgagNAAgfIgZAAQgeADgKAKIhYAzIgBADQgBAEADAFIAlAzQAGAFAHgGIAzgYg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1BB02").s().p("Ai3C5QhNhNAAhsQAAhrBNhMQBMhNBrAAQBsAABMBNQBNBMAABrQAABshNBNQhMBMhsAAQhrAAhMhMgAhqCaQAuANA5AAQA3ABAvgOIAAjAIA4AaQAFACADgEIAQgWQAPgUAGgLQAFgIgFgBIhYgzQgCgDgHgDQgMgHgSAAIgZAAQAAANgGANQgNAaggAAQgNgBgNgHQgagNAAgfIgZAAQgeADgKAKIhYAzIgBADQgBAEADAFIAlAzQAGAFAHgGIAzgYg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-26,52.2,52.2);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0,0,117,18), null);


(lib.cp2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.cp2();
	this.instance.parent = this;
	this.instance.setTransform(-225.5,-226.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.cp2_1, new cjs.Rectangle(-225.5,-226.5,451,453), null);


(lib.cp1_black = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A0tUuQololAAsJQAAsIIlolQIlolMIAAQMJAAIlIlQIlIlAAMIQAAMJolIlQolIlsJAAQsIAAololg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cp1_black, new cjs.Rectangle(-187.5,-187.5,375,375), null);


(lib.cp1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.cp1();
	this.instance.parent = this;
	this.instance.setTransform(-238,-398);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.cp1_1, new cjs.Rectangle(-238,-398,476,796), null);


(lib.bg_black_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bg_black();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_black_1, new cjs.Rectangle(0,0,640,1138), null);


(lib.a2_第二关 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a2_di2guan();
	this.instance.parent = this;
	this.instance.setTransform(-63.5,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a2_第二关, new cjs.Rectangle(-63.5,-19,127,38), null);


(lib.a2_第三关 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a2_di3guan();
	this.instance.parent = this;
	this.instance.setTransform(-63.5,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a2_第三关, new cjs.Rectangle(-63.5,-19,127,38), null);


(lib.a2_第一关 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a2_di1guan();
	this.instance.parent = this;
	this.instance.setTransform(-63.5,-18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a2_第一关, new cjs.Rectangle(-63.5,-18.5,127,37), null);


(lib.a1_txt_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_txt();
	this.instance.parent = this;
	this.instance.setTransform(-166.5,-14.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_txt_1, new cjs.Rectangle(-166.5,-14.5,333,29), null);


(lib.a1_slg_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_slg();
	this.instance.parent = this;
	this.instance.setTransform(-293,-97.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_slg_1, new cjs.Rectangle(-293,-97.5,586,195), null);


(lib.a1_jiantou_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_jiantou();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_jiantou_1, new cjs.Rectangle(0,0,35,102), null);


(lib.a1_dianxian = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_point();
	this.instance.parent = this;
	this.instance.setTransform(-5,-5);

	this.instance_1 = new lib.a1_line();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-310,-1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_dianxian, new cjs.Rectangle(-310,-5,620,10), null);


(lib.a1_bt2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_bt2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_bt2_1, new cjs.Rectangle(0,0,156,39), null);


(lib.a1_bt1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_bt1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_bt1_1, new cjs.Rectangle(0,0,156,39), null);


(lib.表盘point2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6));

	// Layer 1
	this.instance = new lib.表盘point1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6,0.6);
	this.instance.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 0, 0, 0, 0)];
	this.instance.cache(-8,-8,17,17);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-3.7,7.5,7.5);


(lib.表盘point1G = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.表盘point1();
	this.instance.parent = this;
	this.instance.setTransform(-40.5,-74.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.表盘point1G, new cjs.Rectangle(-85,-85,170,170), null);


(lib.表盘3个点 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"3个表盘切换":4});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21));

	// 表盘point2⭐️
	this.instance = new lib.表盘point2();
	this.instance.parent = this;
	this.instance.setTransform(-17,0.9,1.2,1.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4).wait(8).to({scaleX:1.2,scaleY:1.2},4,cjs.Ease.get(1)).wait(1));

	// 表盘point2
	this.instance_1 = new lib.表盘point2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-0.1);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},4,cjs.Ease.get(1)).to({scaleX:1.2,scaleY:1.2},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({scaleX:1.2,scaleY:1.2},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

	// 表盘point2
	this.instance_2 = new lib.表盘point2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.7,0.9);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},4,cjs.Ease.get(1)).wait(4).to({scaleX:1.2,scaleY:1.2},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.5,-3.8,42,9.3);


(lib.表盘大Gmc = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.表盘大G();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.8,0.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,alpha:1},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134.8,-134.8,269.6,269.6);


(lib.表盘txt2Gmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_7 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(7).call(this.frame_7).wait(1));

	// Layer 1
	this.instance = new lib.表盘txt2G();
	this.instance.parent = this;
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-195.5,-53,391,106);


(lib.表盘bgGmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_7 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(7).call(this.frame_7).wait(1));

	// Layer 1
	this.instance = new lib.表盘bgG();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,320,569);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-320,-569,640,1138);


(lib.表盘35mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘35_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29.5,59,59);


(lib.表盘34mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘34_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29.5,59,59);


(lib.表盘33mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 2
	this.instance = new lib.表盘33_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘33_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-29,58,58);


(lib.表盘32mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘32_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29.5,59,59);


(lib.表盘31mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘31_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29.5,59,59);


(lib.表盘28mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 3
	this.instance = new lib.表盘28_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘28_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-29,58,58);


(lib.表盘27mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘27_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘26mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 2
	this.instance = new lib.表盘26_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘26_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-29,58,58);


(lib.表盘25mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘25_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘24mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘24_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘23mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 3
	this.instance = new lib.表盘23_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘23_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-28.5,58,57);


(lib.表盘22mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘22_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘21mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘21_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘19mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘19_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘18mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 2
	this.instance = new lib.表盘18_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘18_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29,59,58);


(lib.表盘17mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘17_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘16mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘16_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘15mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘15_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘14mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘14_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘13mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 2
	this.instance = new lib.表盘13_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘13_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-29.5,59,59);


(lib.表盘12mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘12_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-28,56,56);


(lib.表盘11mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(20));

	// Layer 2
	this.instance = new lib.表盘11_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.15,1.15);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(11));

	// Layer 1
	this.instance_1 = new lib.表盘11_1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-29,58,58);


(lib.表盘10mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9));

	// Layer 1
	this.instance = new lib.表盘10_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.15,scaleY:1.15},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-31,65,62);


(lib.表盘1mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_15 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(15).call(this.frame_15).wait(27));

	// 表盘10
	this.instance = new lib.表盘10mc();
	this.instance.parent = this;
	this.instance.setTransform(-108,-68.4,1,1,-25);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({rotation:0,x:-65,y:-106.7,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-21.3,y:-122,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(3).to({_off:false,rotation:0,x:-65,y:-106.7,alpha:1},0).to({x:-85,y:-126.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘11⭐️
	this.instance_1 = new lib.表盘11mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-132.7,8.8,1,1,-25);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({rotation:0,x:-120,y:-47.2,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-93.3,y:-84.9,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(4).to({_off:false,rotation:0,x:-120,y:-47.2,alpha:1},0).to({x:-140,y:-57.2,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘12
	this.instance_2 = new lib.表盘12mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-110.6,76.3,1,1,-25);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({_off:false},0).to({rotation:0,x:-128.5,y:23.3,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-125.4,y:-21.5,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(4).to({_off:false,rotation:0,x:-128.5,y:23.3,alpha:1},0).to({x:-148.5,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘13⭐️
	this.instance_3 = new lib.表盘13mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-54.8,123.7,1,1,-25);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({_off:false},0).to({rotation:0,x:-98,y:89.8,alpha:1},5,cjs.Ease.get(1)).wait(11).to({rotation:20,x:-119.5,y:51.4,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(5).to({_off:false,rotation:0,x:-98,y:89.8,alpha:1},0).to({x:-118,y:99.8,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘14
	this.instance_4 = new lib.表盘14mc();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.1,132.7,1,1,-25);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({_off:false},0).to({rotation:0,x:-36.5,y:128.3,alpha:1},5,cjs.Ease.get(1)).wait(11).to({rotation:20,x:-74.9,y:108.6,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(6).to({_off:false,rotation:0,x:-36.5,y:128.3,alpha:1},0).to({x:-56.5,y:148.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘15
	this.instance_5 = new lib.表盘15mc();
	this.instance_5.parent = this;
	this.instance_5.setTransform(83.6,102.2,1,1,-25);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).to({rotation:0,x:36.5,y:128.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:-6.5,y:134.1,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:36.5,y:128.8,alpha:1},0).to({x:56.5,y:148.8,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘16
	this.instance_6 = new lib.表盘16mc();
	this.instance_6.parent = this;
	this.instance_6.setTransform(122.6,41.5,1,1,-25);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).to({rotation:0,x:97.6,y:90.3,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:64.1,y:118.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:97.6,y:90.3,alpha:1},0).to({x:117.6,y:100.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘17
	this.instance_7 = new lib.表盘17mc();
	this.instance_7.parent = this;
	this.instance_7.setTransform(122.6,-31.9,1,1,-25);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({_off:false},0).to({rotation:0,x:128.6,y:23.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:116,y:66.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(8).to({_off:false,rotation:0,x:128.6,y:23.8,alpha:1},0).to({x:148.6,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘18⭐️
	this.instance_8 = new lib.表盘18mc();
	this.instance_8.parent = this;
	this.instance_8.setTransform(84.1,-91.7,1,1,-25);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({_off:false},0).to({rotation:0,x:119,y:-46.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:131.1,y:-2.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(9).to({_off:false,rotation:0,x:119,y:-46.7,alpha:1},0).to({x:139,y:-56.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘19
	this.instance_9 = new lib.表盘19mc();
	this.instance_9.parent = this;
	this.instance_9.setTransform(15.7,-123.8,1,1,-25);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({rotation:0,x:70.5,y:-104.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:105.4,y:-73.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(10).to({_off:false,rotation:0,x:70.5,y:-104.7,alpha:1},0).to({x:90.5,y:-124.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.6,-161.1,74.5,74.5);


(lib.倒计时mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ：
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhrF6IAAjwIDXAAIAADwgAhriJIAAjwIDXAAIAADwg");
	this.shape.setTransform(315.8,68.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhrF6IAAjwIDXAAIAADwgAhriJIAAjwIDXAAIAADwg");
	this.shape_1.setTransform(150.3,68.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// 倒计时数字
	this.instance = new lib.倒计时数字();
	this.instance.parent = this;
	this.instance.setTransform(265.7,55);

	this.instance_1 = new lib.倒计时数字();
	this.instance_1.parent = this;
	this.instance_1.setTransform(199.7,55);

	this.instance_2 = new lib.倒计时数字();
	this.instance_2.parent = this;
	this.instance_2.setTransform(431.3,55);

	this.instance_3 = new lib.倒计时数字();
	this.instance_3.parent = this;
	this.instance_3.setTransform(365.2,55);

	this.instance_4 = new lib.倒计时数字();
	this.instance_4.parent = this;
	this.instance_4.setTransform(100.2,55);

	this.instance_5 = new lib.倒计时数字();
	this.instance_5.parent = this;
	this.instance_5.setTransform(34.1,55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.倒计时mc, new cjs.Rectangle(0,0,517.9,134), null);


(lib.倒数开始mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_90 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(90).call(this.frame_90).wait(1));

	// GO
	this.instance = new lib.倒数开始go();
	this.instance.parent = this;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).to({scaleX:1.4,scaleY:1.4,alpha:0},7,cjs.Ease.get(0.8)).to({_off:true},1).wait(4));

	// GO
	this.instance_1 = new lib.倒数开始go();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0.1,3,3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).to({scaleX:1,scaleY:1,y:0,alpha:1},5,cjs.Ease.get(-0.8)).wait(7).to({alpha:0},4,cjs.Ease.get(-1)).wait(1));

	// 1
	this.instance_2 = new lib.倒数开始1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-11,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(54).to({_off:false},0).to({scaleX:1.4,scaleY:1.4,alpha:0},7,cjs.Ease.get(0.8)).to({_off:true},1).wait(29));

	// 1
	this.instance_3 = new lib.倒数开始1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-11,0.1,3,3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(49).to({_off:false},0).to({scaleX:1,scaleY:1,y:0,alpha:1},5,cjs.Ease.get(-0.8)).wait(16).to({alpha:0},4,cjs.Ease.get(-1)).to({_off:true},1).wait(16));

	// 2
	this.instance_4 = new lib.倒数开始2();
	this.instance_4.parent = this;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({scaleX:1.4,scaleY:1.4,alpha:0},7,cjs.Ease.get(0.8)).to({_off:true},1).wait(54));

	// 2
	this.instance_5 = new lib.倒数开始2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,0.1,3,3);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(24).to({_off:false},0).to({scaleX:1,scaleY:1,y:0,alpha:1},5,cjs.Ease.get(-0.8)).wait(16).to({alpha:0},4,cjs.Ease.get(-1)).to({_off:true},1).wait(41));

	// 3
	this.instance_6 = new lib.倒数开始3();
	this.instance_6.parent = this;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(5).to({_off:false},0).to({scaleX:1.4,scaleY:1.4,y:0.1,alpha:0},7,cjs.Ease.get(0.8)).to({_off:true},1).wait(78));

	// 3
	this.instance_7 = new lib.倒数开始3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,0.1,3,3);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({scaleX:1,scaleY:1,y:0,alpha:1},5,cjs.Ease.get(-0.8)).wait(15).to({alpha:0},4,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-156,-283.7,312,567.6);


(lib.TopIconG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// TopIcon7
	this.instance = new lib.TopIcon7();
	this.instance.parent = this;
	this.instance.setTransform(567.6,26.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:547.6,alpha:1},10,cjs.Ease.get(1)).wait(3));

	// TopIcon6
	this.instance_1 = new lib.TopIcon6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(480.4,26.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({_off:false},0).to({x:460.4,alpha:1},10,cjs.Ease.get(1)).wait(5));

	// TopIcon5
	this.instance_2 = new lib.TopIcon5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(393.9,26.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(8).to({_off:false},0).to({x:373.9,alpha:1},10,cjs.Ease.get(1)).wait(7));

	// TopIcon4
	this.instance_3 = new lib.TopIcon4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(306.8,26.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({_off:false},0).to({x:286.8,alpha:1},10,cjs.Ease.get(1)).wait(9));

	// TopIcon3
	this.instance_4 = new lib.TopIcon3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(219.7,26.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).to({x:199.7,alpha:1},10,cjs.Ease.get(1)).wait(11));

	// TopIcon2
	this.instance_5 = new lib.TopIcon2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(133.2,26.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2).to({_off:false},0).to({x:113.2,alpha:1},10,cjs.Ease.get(1)).wait(13));

	// TopIcon1
	this.instance_6 = new lib.TopIcon1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(46.1,26.1);
	this.instance_6.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:26.1,alpha:1},10,cjs.Ease.get(1)).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(20,0,52.2,52.2);


(lib.cp2_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.cp2_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.cp2_mc, new cjs.Rectangle(-225.5,-226.5,451,453), null);


(lib.a1_jiantou_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_jiantou_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-6,x:-8.5,y:-7},7).to({rotation:0,x:0,y:0},7).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,35,102);


(lib.表盘point1Gmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50));

	// Layer 1
	this.instance = new lib.表盘point1G();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,rotation:-302.6},49).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-80.7,12.5,12.5);


(lib.表盘3mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_15 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(15).call(this.frame_15).wait(27));

	// 表盘35
	this.instance = new lib.表盘35mc();
	this.instance.parent = this;
	this.instance.setTransform(17.1,132.7,1,1,-25);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).to({rotation:0,x:-36.5,y:128.3,alpha:1},5,cjs.Ease.get(1)).wait(11).to({rotation:20,x:-74.9,y:108.6,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(6).to({_off:false,rotation:0,x:-36.5,y:128.3,alpha:1},0).to({x:-56.5,y:148.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘34
	this.instance_1 = new lib.表盘34mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83.6,102.2,1,1,-25);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).to({rotation:0,x:36.5,y:128.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:-6.5,y:134.1,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:36.5,y:128.8,alpha:1},0).to({x:56.5,y:148.8,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘33⭐️
	this.instance_2 = new lib.表盘33mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(122.6,41.5,1,1,-25);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({_off:false},0).to({rotation:0,x:97.6,y:90.3,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:64.1,y:118.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:97.6,y:90.3,alpha:1},0).to({x:117.6,y:100.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘32
	this.instance_3 = new lib.表盘32mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(122.6,-31.9,1,1,-25);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({_off:false},0).to({rotation:0,x:128.6,y:23.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:116,y:66.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(8).to({_off:false,rotation:0,x:128.6,y:23.8,alpha:1},0).to({x:148.6,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘31
	this.instance_4 = new lib.表盘31mc();
	this.instance_4.parent = this;
	this.instance_4.setTransform(84.1,-91.7,1,1,-25);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).to({rotation:0,x:119,y:-46.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:131.1,y:-2.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(9).to({_off:false,rotation:0,x:119,y:-46.7,alpha:1},0).to({x:139,y:-56.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘10
	this.instance_5 = new lib.表盘10mc();
	this.instance_5.parent = this;
	this.instance_5.setTransform(15.7,-123.8,1,1,-25);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({rotation:0,x:70.5,y:-104.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:105.4,y:-73.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(10).to({_off:false,rotation:0,x:70.5,y:-104.7,alpha:1},0).to({x:90.5,y:-124.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.9,-165.7,85.1,83.7);


(lib.表盘2mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_15 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(15).call(this.frame_15).wait(27));

	// 表盘10
	this.instance = new lib.表盘10mc();
	this.instance.parent = this;
	this.instance.setTransform(-108,-68.4,1,1,-25);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({rotation:0,x:-65,y:-106.7,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-21.3,y:-122,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(3).to({_off:false,rotation:0,x:-65,y:-106.7,alpha:1},0).to({x:-85,y:-126.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘21
	this.instance_1 = new lib.表盘21mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-132.7,8.8,1,1,-25);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({rotation:0,x:-120,y:-47.2,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-93.3,y:-84.9,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(4).to({_off:false,rotation:0,x:-120,y:-47.2,alpha:1},0).to({x:-140,y:-57.2,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘22
	this.instance_2 = new lib.表盘22mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-110.6,76.3,1,1,-25);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({_off:false},0).to({rotation:0,x:-128.5,y:23.3,alpha:1},6,cjs.Ease.get(1)).wait(10).to({rotation:20,x:-125.4,y:-21.5,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(4).to({_off:false,rotation:0,x:-128.5,y:23.3,alpha:1},0).to({x:-148.5,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘23⭐️
	this.instance_3 = new lib.表盘23mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-54.8,123.7,1,1,-25);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({_off:false},0).to({rotation:0,x:-98,y:89.8,alpha:1},5,cjs.Ease.get(1)).wait(11).to({rotation:20,x:-119.5,y:51.4,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(5).to({_off:false,rotation:0,x:-98,y:89.8,alpha:1},0).to({x:-118,y:99.8,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘24
	this.instance_4 = new lib.表盘24mc();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.1,132.7,1,1,-25);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({_off:false},0).to({rotation:0,x:-36.5,y:128.3,alpha:1},5,cjs.Ease.get(1)).wait(11).to({rotation:20,x:-74.9,y:108.6,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(6).to({_off:false,rotation:0,x:-36.5,y:128.3,alpha:1},0).to({x:-56.5,y:148.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘25
	this.instance_5 = new lib.表盘25mc();
	this.instance_5.parent = this;
	this.instance_5.setTransform(83.6,102.2,1,1,-25);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).to({rotation:0,x:36.5,y:128.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:-6.5,y:134.1,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:36.5,y:128.8,alpha:1},0).to({x:56.5,y:148.8,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘26⭐️
	this.instance_6 = new lib.表盘26mc();
	this.instance_6.parent = this;
	this.instance_6.setTransform(122.6,41.5,1,1,-25);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).to({rotation:0,x:97.6,y:90.3,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:64.1,y:118.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(7).to({_off:false,rotation:0,x:97.6,y:90.3,alpha:1},0).to({x:117.6,y:100.3,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘27
	this.instance_7 = new lib.表盘27mc();
	this.instance_7.parent = this;
	this.instance_7.setTransform(122.6,-31.9,1,1,-25);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({_off:false},0).to({rotation:0,x:128.6,y:23.8,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:116,y:66.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(8).to({_off:false,rotation:0,x:128.6,y:23.8,alpha:1},0).to({x:148.6,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘28⭐️
	this.instance_8 = new lib.表盘28mc();
	this.instance_8.parent = this;
	this.instance_8.setTransform(84.1,-91.7,1,1,-25);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({_off:false},0).to({rotation:0,x:119,y:-46.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:131.1,y:-2.7,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(9).to({_off:false,rotation:0,x:119,y:-46.7,alpha:1},0).to({x:139,y:-56.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

	// 表盘10
	this.instance_9 = new lib.表盘10mc();
	this.instance_9.parent = this;
	this.instance_9.setTransform(15.7,-123.8,1,1,-25);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({rotation:0,x:70.5,y:-104.7,alpha:1},4,cjs.Ease.get(1)).wait(12).to({rotation:20,x:105.4,y:-73.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(10).to({_off:false,rotation:0,x:70.5,y:-104.7,alpha:1},0).to({x:90.5,y:-124.7,alpha:0},7,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.9,-165.7,85.1,83.7);


(lib.a1_jiantoushou = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.a1_shou();
	this.instance.parent = this;
	this.instance.setTransform(-15.4,-24.6);

	this.instance_1 = new lib.a1_jiantou_mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14,83.6,1,1,0,180,0,17.5,51);

	this.instance_2 = new lib.a1_jiantou_mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-14,-83.5,1,1,0,0,0,17.5,51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.a1_jiantoushou, new cjs.Rectangle(-31.5,-134.5,63.1,269.1), null);


(lib.表盘123们 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// 表盘123
	this.instance = new lib.表盘1mc();
	this.instance.parent = this;
	this.instance.setTransform(-15.6,123.9);

	this.instance_1 = new lib.表盘2mc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-15.6,123.9);

	this.instance_2 = new lib.表盘3mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-15.6,123.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.2,-37.2,74.5,74.5);


(lib.GaerS3H5Game = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{a1:0,a2:1,第1关开始位置:24,level1Complete:119,第2关开始位置:124,第3关开始位置:219,showIcon:112});

	// timeline functions:
	this.frame_119 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(119).call(this.frame_119).wait(200));

	// logo
	this.instance = new lib.logo_1();
	this.instance.parent = this;
	this.instance.setTransform(81.5,32,1,1,0,0,0,58.5,9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},315).wait(4));

	// TopIcon⭐️👀
	this.instance_1 = new lib.TopIconG("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(316.7,96.1,1,1,0,0,0,286.8,26.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({_off:true},307).wait(4));

	// 倒计时⭐️
	this.instance_2 = new lib.倒计时mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(320.6,213.4,1,1,0,0,0,233.6,67);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(15).to({_off:false},0).to({y:233.4,alpha:1},7,cjs.Ease.get(1)).to({_off:true},293).wait(4));

	// a1_点线
	this.instance_3 = new lib.a1_dianxian();
	this.instance_3.parent = this;
	this.instance_3.setTransform(320,1084.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},315).wait(4));

	// a1_箭头手
	this.instance_4 = new lib.a1_jiantoushou();
	this.instance_4.parent = this;
	this.instance_4.setTransform(585.5,593.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},315).wait(4));

	// a1_slg
	this.instance_5 = new lib.a1_slg_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(320.1,164.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({scaleX:3,scaleY:3,y:124.1,alpha:0},7,cjs.Ease.get(-0.8)).to({_off:true},1).wait(310));

	// a1_bt2
	this.btn = new lib.a1_bt2_1();
	this.btn.parent = this;
	this.btn.setTransform(408,1005.8,1,1,0,0,0,78,19.5);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1).to({y:1025.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(310));

	// a1_bt1
	this.instance_6 = new lib.a1_bt1_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(235,1005.8,1,1,0,0,0,78,19.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({y:1025.8,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(310));

	// a1_txt
	this.instance_7 = new lib.a1_txt_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(322,951.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({y:971.6,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(307));

	// 倒数开始👀
	this.instance_8 = new lib.倒数开始mc("synched",0,false);
	this.instance_8.parent = this;
	this.instance_8.setTransform(319.4,588.7);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(24).to({_off:false},0).to({_off:true},91).wait(9).to({_off:false},0).to({_off:true},91).wait(4).to({_off:false},0).to({_off:true},96).wait(4));

	// 第一关
	this.instance_9 = new lib.a2_第一关();
	this.instance_9.parent = this;
	this.instance_9.setTransform(319.6,985.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(8).to({_off:false},0).to({y:1005.3,alpha:1},7,cjs.Ease.get(1)).wait(97).to({alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(199));

	// 第二关
	this.instance_10 = new lib.a2_第二关();
	this.instance_10.parent = this;
	this.instance_10.setTransform(319.6,985.3);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(124).to({_off:false},0).to({y:1005.3,alpha:1},7,cjs.Ease.get(1)).wait(76).to({alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(104));

	// 第三关
	this.instance_11 = new lib.a2_第三关();
	this.instance_11.parent = this;
	this.instance_11.setTransform(319.6,985.3);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(219).to({_off:false},0).to({y:1005.3,alpha:1},7,cjs.Ease.get(1)).wait(76).to({alpha:0},7,cjs.Ease.get(-1)).to({_off:true},1).wait(9));

	// cp2
	this.instance_12 = new lib.cp2_mc();
	this.instance_12.parent = this;
	this.instance_12.setTransform(318.9,587);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(302).to({_off:true},13).wait(4));

	// ✅表盘大⭐️
	this.contentImage = new lib.表盘大Gmc();
	this.contentImage.parent = this;
	this.contentImage.setTransform(316.6,588.2);
	this.contentImage._off = true;

	this.timeline.addTween(cjs.Tween.get(this.contentImage).wait(119).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},6).wait(4));

	// 3页3圆点⭐️
	this.instance_13 = new lib.表盘3个点();
	this.instance_13.parent = this;
	this.instance_13.setTransform(318.4,427.9);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(112).to({_off:false},0).to({_off:true},12).wait(83).to({_off:false},0).to({_off:true},12).wait(83).to({_off:false},0).to({_off:true},13).wait(4));

	// 指示 圆点⭐️
	this.instance_14 = new lib.表盘point1Gmc();
	this.instance_14.parent = this;
	this.instance_14.setTransform(317.6,587.9);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(119).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},6).wait(4));

	// 表盘txt1⭐️
	this.instance_15 = new lib.表盘txt1G();
	this.instance_15.parent = this;
	this.instance_15.setTransform(314.1,589.2);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(119).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},6).wait(4));

	// ✅表盘txt2⭐️
	this.instance_16 = new lib.表盘txt2Gmc();
	this.instance_16.parent = this;
	this.instance_16.setTransform(319.6,984.7);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(119).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},6).wait(4));

	// 小icon表盘们⭐️
	this.icon = new lib.表盘123们();
	this.icon.parent = this;
	this.icon.setTransform(333.3,500.4,1,1,0,0,0,0,43.3);
	this.icon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(112).to({_off:false},0).to({_off:true},12).wait(83).to({_off:false},0).to({_off:true},12).wait(83).to({_off:false},0).to({_off:true},13).wait(4));

	// cp1_black
	this.instance_17 = new lib.cp1_black();
	this.instance_17.parent = this;
	this.instance_17.setTransform(318.9,587);
	this.instance_17.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(109).to({alpha:1},5).wait(10).to({alpha:0.801},0).wait(80).to({alpha:1},5).wait(10).to({alpha:0.801},0).wait(80).to({alpha:1},5).to({_off:true},11).wait(4));

	// cp1
	this.instance_18 = new lib.cp1_1();
	this.instance_18.parent = this;
	this.instance_18.setTransform(318.9,578);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).to({_off:true},315).wait(4));

	// ✅表盘bg⭐️
	this.instance_19 = new lib.表盘bgGmc();
	this.instance_19.parent = this;
	this.instance_19.setTransform(320,569);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(119).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},5).wait(90).to({_off:false},0).to({_off:true},6).wait(4));

	// bg_black
	this.instance_20 = new lib.bg_black_1();
	this.instance_20.parent = this;
	this.instance_20.setTransform(320,569,1,1,0,0,0,320,569);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).to({_off:true},315).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,640,1138);


// stage content:
(lib.GearS3 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.gameView = new lib.GaerS3H5Game();
	this.gameView.parent = this;
	this.gameView.setTransform(320,569,1,1,0,0,0,320,569);

	this.timeline.addTween(cjs.Tween.get(this.gameView).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(320,569,640,1138);
// library properties:
lib.properties = {
	width: 640,
	height: 1138,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/a1_bt1.png?1481767425151", id:"a1_bt1"},
		{src:"images/a1_bt2.png?1481767425151", id:"a1_bt2"},
		{src:"images/a1_jiantou.png?1481767425151", id:"a1_jiantou"},
		{src:"images/a1_line.png?1481767425151", id:"a1_line"},
		{src:"images/a1_point.png?1481767425151", id:"a1_point"},
		{src:"images/a1_shou.png?1481767425151", id:"a1_shou"},
		{src:"images/a1_slg.png?1481767425151", id:"a1_slg"},
		{src:"images/a1_txt.png?1481767425151", id:"a1_txt"},
		{src:"images/a2_di1guan.png?1481767425151", id:"a2_di1guan"},
		{src:"images/a2_di2guan.png?1481767425151", id:"a2_di2guan"},
		{src:"images/a2_di3guan.png?1481767425151", id:"a2_di3guan"},
		{src:"images/bg_black.png?1481767425151", id:"bg_black"},
		{src:"images/cp1.png?1481767425151", id:"cp1"},
		{src:"images/cp2.png?1481767425151", id:"cp2"},
		{src:"images/logo.png?1481767425151", id:"logo"},
		{src:"images/表盘10.png?1481767425151", id:"表盘10"},
		{src:"images/表盘11.png?1481767425151", id:"表盘11"},
		{src:"images/表盘11bg.jpg?1481767425151", id:"表盘11bg"},
		{src:"images/表盘11txt2.png?1481767425151", id:"表盘11txt2"},
		{src:"images/表盘11大.png?1481767425151", id:"表盘11大"},
		{src:"images/表盘12.png?1481767425151", id:"表盘12"},
		{src:"images/表盘13.png?1481767425151", id:"表盘13"},
		{src:"images/表盘13bg.jpg?1481767425151", id:"表盘13bg"},
		{src:"images/表盘13txt2.png?1481767425151", id:"表盘13txt2"},
		{src:"images/表盘13大.png?1481767425151", id:"表盘13大"},
		{src:"images/表盘14.png?1481767425151", id:"表盘14"},
		{src:"images/表盘15.png?1481767425151", id:"表盘15"},
		{src:"images/表盘16.png?1481767425151", id:"表盘16"},
		{src:"images/表盘17.png?1481767425151", id:"表盘17"},
		{src:"images/表盘18.png?1481767425151", id:"表盘18"},
		{src:"images/表盘18bg.jpg?1481767425151", id:"表盘18bg"},
		{src:"images/表盘18txt2.png?1481767425151", id:"表盘18txt2"},
		{src:"images/表盘18大.png?1481767425151", id:"表盘18大"},
		{src:"images/表盘19.png?1481767425151", id:"表盘19"},
		{src:"images/表盘21.png?1481767425151", id:"表盘21"},
		{src:"images/表盘22.png?1481767425151", id:"表盘22"},
		{src:"images/表盘23.png?1481767425151", id:"表盘23"},
		{src:"images/表盘23bg.jpg?1481767425151", id:"表盘23bg"},
		{src:"images/表盘23txt2.png?1481767425151", id:"表盘23txt2"},
		{src:"images/表盘23大.png?1481767425151", id:"表盘23大"},
		{src:"images/表盘24.png?1481767425151", id:"表盘24"},
		{src:"images/表盘25.png?1481767425151", id:"表盘25"},
		{src:"images/表盘26.png?1481767425151", id:"表盘26"},
		{src:"images/表盘26bg.jpg?1481767425151", id:"表盘26bg"},
		{src:"images/表盘26txt2.png?1481767425151", id:"表盘26txt2"},
		{src:"images/表盘26大.png?1481767425151", id:"表盘26大"},
		{src:"images/表盘27.png?1481767425151", id:"表盘27"},
		{src:"images/表盘28.png?1481767425151", id:"表盘28"},
		{src:"images/表盘28bg.jpg?1481767425151", id:"表盘28bg"},
		{src:"images/表盘28txt2.png?1481767425151", id:"表盘28txt2"},
		{src:"images/表盘28大.png?1481767425151", id:"表盘28大"},
		{src:"images/表盘31.png?1481767425151", id:"表盘31"},
		{src:"images/表盘32.png?1481767425151", id:"表盘32"},
		{src:"images/表盘33.png?1481767425151", id:"表盘33"},
		{src:"images/表盘33bg.jpg?1481767425151", id:"表盘33bg"},
		{src:"images/表盘33txt2.png?1481767425151", id:"表盘33txt2"},
		{src:"images/表盘33大.png?1481767425151", id:"表盘33大"},
		{src:"images/表盘34.png?1481767425151", id:"表盘34"},
		{src:"images/表盘35.png?1481767425151", id:"表盘35"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;